# Trading API

A unified API for multiple trading platforms (Dhan, Fyers).

## Installation

```bash
pip install -r requirements.txt
```

## Usage

```python
from trading_api import TradingAPI

# Example usage
```

## License

MIT License