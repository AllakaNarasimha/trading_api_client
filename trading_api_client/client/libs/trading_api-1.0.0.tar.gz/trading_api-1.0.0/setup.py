"""
Setup configuration for trading_api package.
This enables the package to be installed via pip and used as a library in other projects.
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read the contents of README file
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8") if (this_directory / "README.md").exists() else ""

# Read requirements.txt
requirements = []
requirements_file = this_directory / "requirements.txt"
if requirements_file.exists():
    with open(requirements_file) as f:
        requirements = [line.strip() for line in f if line.strip() and not line.startswith("#")]

setup(
    name="trading-api",
    version="1.0.0",
    author="Your Name",
    author_email="your.email@example.com",
    description="A unified API for multiple trading platforms (Dhan, Fyers)",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/trading_api",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Office/Business :: Financial :: Point-Of-Sale",
        "Topic :: Office/Business :: Financial :: Investment",
    ],
    python_requires=">=3.8",
    install_requires=requirements,
    include_package_data=True,
    entry_points={
        "console_scripts": [
            "trading-api=trading_api.main:main",
        ],
    },
    keywords="trading api dhan fyers broker stock market",
    project_urls={
        "Bug Reports": "https://github.com/yourusername/trading_api/issues",
        "Source": "https://github.com/yourusername/trading_api",
        "Documentation": "https://github.com/yourusername/trading_api/wiki",
    },
)
