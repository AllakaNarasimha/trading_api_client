"""
Main entry point for the trading API application.
Can be run as: python -m trading_api or trading-api (after pip install -e .)
"""

import time
from typing import cast

from trading_api.implementations import DhanAPI, FyersAPI
from trading_api.utils import Config, dhan_master
from trading_api.interfaces.price_watcher import IPriceWatcher
from trading_api.interfaces.authentication import IAuthentication
from trading_api.interfaces.order_management import IOrderManagement
from trading_api.interfaces.fund_management import IFundManagement


# ========== Authentication Functions ==========

def check_dhan_authentication(config: Config) -> DhanAPI | None:
    """Check Dhan API authentication status."""
    print("[1] Authenticating with Dhan...")
    
    dhan_config = config.get_dhan_config()
    dhan_api = DhanAPI()
    print(f"Dhan API object type: {type(dhan_api)}")
    print(f"Dhan API authenticate method: {dhan_api.authenticate}")
    
    print("Calling authenticate method...")
    auth: IAuthentication = dhan_api
    result = auth.authenticate(dhan_config)
    print(f"Authentication result type: {type(result)}")
    print(f"Authentication result: {result}")
    if isinstance(result, list) and result[0] == "success":
        print("[OK] Dhan authenticated")
        return dhan_api
    else:
        print(f"[FAIL] Dhan authentication failed: {result[1] if isinstance(result, list) else result}")
        return None


def check_fyers_authentication(config: Config) -> IAuthentication | None:
    """Check Fyers API authentication status."""
    print("[2] Authenticating with Fyers...")

    fyers_config = config.get_fyers_config()

    auth: IAuthentication = FyersAPI()
    result = auth.authenticate(fyers_config)
    if result[0] == "success":
        print("[OK] Fyers authenticated")
        return auth
    else:
        print(f"[FAIL] Fyers authentication failed: {result[1]}")
        return None


# ========== API Verification Functions ==========

def verify_dhan_api(auth: IAuthentication, order: IOrderManagement, fund: IFundManagement, price: IPriceWatcher) -> None:
    """Verify Dhan API methods after authentication."""
    print("\n[VERIFY] Dhan API Methods")
    print("-" * 30)
    
    # IOrderManagement methods
    print("Order Management:")
    try:
        orders = order.get_all_orders()
        print(f"  ✓ get_all_orders: {len(orders) if orders else 0} orders retrieved")
    except Exception as e:
        print(f"  ✗ get_all_orders error: {e}")
    
    try:
        status = order.get_order_status("dummy_order_id")
        print(f"  ✓ get_order_status: {status.get('status', 'checked')}")
    except Exception as e:
        print(f"  ✗ get_order_status error: {e}")
    
    # IFundManagement methods
    print("Fund Management:")
    try:
        balance = fund.get_balance()
        print(f"  ✓ get_balance: {balance.get('message', 'retrieved')}")
    except Exception as e:
        print(f"  ✗ get_balance error: {e}")
    
    try:
        holdings = fund.get_holdings()
        print(f"  ✓ get_holdings: {len(holdings) if holdings else 0} holdings")
    except Exception as e:
        print(f"  ✗ get_holdings error: {e}")
    
    try:
        positions = fund.get_positions()
        print(f"  ✓ get_positions: {len(positions) if positions else 0} positions")
    except Exception as e:
        print(f"  ✗ get_positions error: {e}")
    
    master = dhan_master.DhanMaster()
    record = master.get_record({'SM_SYMBOL_NAME': 'GOLD', 'SEM_INSTRUMENT_NAME': 'FUTCOM'});
    security_id = record.get('SEM_SMST_SECURITY_ID') if record else None
    if security_id and security_id != 'N/A':
        try:
            margin = fund.get_margin_requirement(security_id, 1)
            print(f"  ✓ get_margin_requirement: {margin}")
        except Exception as e:
            print(f"  ✗ get_margin_requirement error: {e}")
    else:
        print("  ✗ get_margin_requirement: Invalid instrument name")
    
    # IPriceWatcher methods
    print("Price Watcher:")
    watcher = price  # Already an IPriceWatcher
    
    if security_id and security_id != 'N/A':
        try:
            price_data = watcher.get_price(security_id)
            print(f"  ✓ get_price: LTP {price_data.get('ltp', 'N/A')}")
        except Exception as e:
            print(f"  ✗ get_price error: {e}")
        
        try:
            quotes = watcher.get_quotes([security_id])
            print(f"  ✓ get_quotes: {len(quotes)} symbols")
        except Exception as e:
            print(f"  ✗ get_quotes error: {e}")
        
        try:
            period_start = int(time.time()) - 5 * 24 * 3600  # 5 days ago
            period_end = int(time.time())
            hist = watcher.get_historical_data(security_id, "D", "0", period_start, period_end)
            if hist:
                for i, record in enumerate(hist):
                    print(f"    Record {i+1}: Timestamp={record[0]}, Open={record[1]}, High={record[2]}, Low={record[3]}, Close={record[4]}, Volume={record[5]}")
            print(f"  ✓ get_historical_data: {len(hist) if hist else 0} records")
        except Exception as e:
            print(f"  ✗ get_historical_data error: {e}")
    else:
        print("  ✗ get_price: Invalid instrument name")
        print("  ✗ get_quotes: Invalid instrument name")
        print("  ✗ get_historical_data: Invalid instrument name")


def verify_fyers_api(auth: IAuthentication, order: IOrderManagement, fund: IFundManagement, price: IPriceWatcher) -> None:
    """Verify Fyers API methods after authentication."""
    print("\n[VERIFY] Fyers API Methods")
    print("-" * 30)
    
    # IOrderManagement methods
    print("Order Management:")
    try:
        orders = order.get_all_orders()
        print(f"  ✓ get_all_orders: {len(orders) if orders else 0} orders retrieved")
    except Exception as e:
        print(f"  ✗ get_all_orders error: {e}")
    
    try:
        status = order.get_order_status("dummy_order_id")
        print(f"  ✓ get_order_status: {status.get('status', 'checked')}")
    except Exception as e:
        print(f"  ✗ get_order_status error: {e}")
    
    # IFundManagement methods
    print("Fund Management:")
    try:
        balance = fund.get_balance()
        print(f"  ✓ get_balance: {balance.get('message', 'retrieved')}")
    except Exception as e:
        print(f"  ✗ get_balance error: {e}")
    
    try:
        holdings = fund.get_holdings()
        print(f"  ✓ get_holdings: {len(holdings) if holdings else 0} holdings")
    except Exception as e:
        print(f"  ✗ get_holdings error: {e}")
    
    try:
        positions = fund.get_positions()
        print(f"  ✓ get_positions: {len(positions) if positions else 0} positions")
    except Exception as e:
        print(f"  ✗ get_positions error: {e}")
    
    symbol = 'NSE:NIFTY50-INDEX'  # Default symbol for Fyers
    print(f"Using symbol for margin check: {symbol}")
    try:
        margin = fund.get_margin_requirement(symbol, 1)
        print(f"  ✓ get_margin_requirement: {margin}")
    except Exception as e:
        print(f"  ✗ get_margin_requirement error: {e}")
    
    # IPriceWatcher methods
    print("Price Watcher:")
    watcher = price  # Already an IPriceWatcher
    try:
        price_data = watcher.get_price(symbol=symbol)
        print(f"  ✓ get_price: LTP {price_data.get('ltp', 'N/A')}")
    except Exception as e:
        print(f"  ✗ get_price error: {e}")
    
    try:
        quotes = watcher.get_quotes([symbol])
        print(f"  ✓ get_quotes: {len(quotes)} symbols")
    except Exception as e:
        print(f"  ✗ get_quotes error: {e}")
    
    try:
        period_start = int(time.time()) - 2 * 24 * 3600  # 2 days ago
        period_end = int(time.time())
        hist = watcher.get_historical_data(symbol, "5S", "0", period_start, period_end) # 5S, 1, D
        if hist:
            for i, record in enumerate(hist):
                print(f"    Record {i+1}: Timestamp={record[0]}, Open={record[1]}, High={record[2]}, Low={record[3]}, Close={record[4]}, Volume={record[5]}")
        print(f"  ✓ get_historical_data: {len(hist) if hist else 0} records")
    except Exception as e:
        print(f"  ✗ get_historical_data error: {e}")
    
    # Test option chain functionality
    print("Option Chain:")
    # option_symbol = "NSE:TCS-EQ"  # Use TCS for option chain testing
    option_symbol = "BSE:SENSEX-INDEX"  # Use TCS for option chain testing
    try:
        option_chain = watcher.get_option_chain(symbol=option_symbol, strikecount=1, timestamp="")
        if option_chain.get('s') == 'ok':
            print(f"  ✓ get_option_chain: Retrieved option chain for {option_symbol}")
            data = option_chain.get('data', {})
            print(f"    Call OI: {data.get('callOi', 'N/A')}")
            print(f"    Put OI: {data.get('putOi', 'N/A')}")
            expiry_data = data.get('expiryData', [])
            print(f"    Expiry dates: {len(expiry_data)} available")
            if expiry_data:
                print(f"    First expiry: {expiry_data[0].get('date', 'N/A')} ({expiry_data[0].get('expiry', 'N/A')})")
            options_chain = data.get('optionsChain', [])
            print(f"    Option contracts: {len(options_chain)} retrieved")
            if options_chain:
                # Show first CE and PE contracts
                ce_contracts = [opt for opt in options_chain if opt.get('option_type') == 'CE']
                pe_contracts = [opt for opt in options_chain if opt.get('option_type') == 'PE']
                if ce_contracts:
                    ce = ce_contracts[0]
                    print(f"    Sample CE: Strike {ce.get('strike_price', 'N/A')}, LTP {ce.get('ltp', 'N/A')}, OI {ce.get('oi', 'N/A')}")
                if pe_contracts:
                    pe = pe_contracts[0]
                    print(f"    Sample PE: Strike {pe.get('strike_price', 'N/A')}, LTP {pe.get('ltp', 'N/A')}, OI {pe.get('oi', 'N/A')}")
        else:
            print(f"  ✗ get_option_chain: Failed - {option_chain.get('message', 'Unknown error')}")
    except Exception as e:
        print(f"  ✗ get_option_chain error: {e}")
    
    # Test LTP subscription
    print("LTP Subscription for multiple symbols:")
    
    # Define multiple symbols for subscription
    symbols = ['NSE:NIFTY25NOV24000CE', 'NSE:NIFTY25NOV24000PE', 'NSE:NIFTY25NOV2410000CE',
                'NSE:NIFTY50-INDEX' # depth not available for index
                ]
    
    def ltp_callback(symbol, message):
        """Callback for LTP updates."""
        print(f"  [LTP] {symbol}:")
        print(f"    ltp: {message.get('ltp')}")
        print(f"    vol_traded_today: {message.get('vol_traded_today')}")
        print(f"    last_traded_time: {message.get('last_traded_time')}")
        print(f"    exch_feed_time: {message.get('exch_feed_time')}")
        print(f"    bid_size: {message.get('bid_size')}")
        print(f"    ask_size: {message.get('ask_size')}")
        print(f"    bid_price: {message.get('bid_price')}")
        print(f"    ask_price: {message.get('ask_price')}")
        print(f"    last_traded_qty: {message.get('last_traded_qty')}")
        print(f"    tot_buy_qty: {message.get('tot_buy_qty')}")
        print(f"    tot_sell_qty: {message.get('tot_sell_qty')}")
        print(f"    avg_trade_price: {message.get('avg_trade_price')}")
        print(f"    low_price: {message.get('low_price')}")
        print(f"    high_price: {message.get('high_price')}")
        print(f"    lower_ckt: {message.get('lower_ckt')}")
        print(f"    upper_ckt: {message.get('upper_ckt')}")
        print(f"    open_price: {message.get('open_price')}")
        print(f"    prev_close_price: {message.get('prev_close_price')}")
        print(f"    type: {message.get('type')}")
        print(f"    symbol: {message.get('symbol')}")
        print(f"    ch: {message.get('ch')}")
        print(f"    chp: {message.get('chp')}")
    
    # Subscribe to multiple symbols
    for sym in symbols:
        try:
            success = watcher.subscribe_to_price(sym, ltp_callback)
            if success:
                print(f"  ✓ subscribe_to_price: Subscribed to {sym}")
            else:
                print(f"  ✗ subscribe_to_price: Failed to subscribe to {sym}")
        except Exception as e:
            print(f"  ✗ subscribe_to_price error for {sym}: {e}")
    
    time.sleep(10)  # Wait for updates from multiple symbols
    
    # Unsubscribe from all symbols
    for sym in symbols:
        try:
            watcher.unsubscribe_from_price(sym)
            print(f"  ✓ unsubscribe_from_price: Unsubscribed from {sym}")
        except Exception as e:
            print(f"  ✗ unsubscribe_from_price error for {sym}: {e}")
    
    # Test subscription to real-time depth updates for multiple symbols
    print("Depth Subscription for multiple symbols:")
    
    def price_depth_callback(ticker, message):
        """Callback function for depth updates."""
        print(f"  [DEPTH] {ticker}:")
        print(f"    send_ts: {message.sendtime}")
        print(f"    tbq: {message.tbq}")
        print(f"    tsq: {message.tsq}")
        print(f"    bidprice: {message.bidprice[:5]}")  # Show first 5 levels
        print(f"    askprice: {message.askprice[:5]}")
        print(f"    bidqty: {message.bidqty[:5]}")
        print(f"    askqty: {message.askqty[:5]}")
        print(f"    snapshot: {message.snapshot}")
        print(f"    sNo: {message.seqNo}")
        
        # Simple analysis
        if message.bidprice and message.askprice:
            spread = message.askprice[0] - message.bidprice[0]
            imbalance = (message.tbq - message.tsq) / (message.tbq + message.tsq) if (message.tbq + message.tsq) > 0 else 0
            print(f"    [ANALYSIS] Spread={spread:.2f}, Imbalance={imbalance:.3f}")
    
    # Subscribe to multiple symbols for depth
    for sym in symbols:
        try:
            success = watcher.subscribe_to_depth(sym, price_depth_callback)
            if success:
                print(f"  ✓ subscribe_to_depth: Subscribed to {sym}")
            else:
                print(f"  ✗ subscribe_to_depth: Failed to subscribe to {sym}")
        except Exception as e:
            print(f"  ✗ subscribe_to_depth error for {sym}: {e}")
    
    print("  Depth mode active... (Press Ctrl+C to stop)")
    # Keep the program running to receive updates
    try:
        while True:
            time.sleep(0.1)
    except KeyboardInterrupt:
        print("\nStopping depth monitoring...")
    
    # Unsubscribe from all symbols
    for sym in symbols:
        try:
            watcher.unsubscribe_from_depth(sym)
            print(f"  ✓ unsubscribe_from_depth: Unsubscribed from {sym}")
        except Exception as e:
            print(f"  ✗ unsubscribe_from_depth error for {sym}: {e}")


# ========== Main Application ==========

def main() -> None:
    """Load config and authenticate with both APIs."""
    
    print("=" * 50)
    print("Trading API")
    print("=" * 50)

    config_file = 'config.xml'
    config = Config()
    
    if not config.load_from_xml(config_file):
        print(f"[FAIL] Failed to load configuration from {config_file}")
        return
    
    print(f"[OK] Configuration loaded from {config_file}\n")

    dhan_api =  None # check_dhan_authentication(config)
    print()
    fyers_api = check_fyers_authentication(config)
    
    print("\n" + "=" * 50)
    print("Authentication Summary")
    print("=" * 50)
    print(f"Dhan:  {'[OK] Connected' if dhan_api else '[FAIL] Failed'}")
    print(f"Fyers: {'[OK] Connected' if fyers_api else '[FAIL] Failed'}")
    print("=" * 50)
    
    # Verify API methods if authenticated
    if dhan_api:
        verify_dhan_api(dhan_api, dhan_api, dhan_api, dhan_api)
    
    if fyers_api:
        verify_fyers_api(cast(IAuthentication, fyers_api), cast(IOrderManagement, fyers_api), cast(IFundManagement, fyers_api), cast(IPriceWatcher, fyers_api))


if __name__ == '__main__':
    main()
