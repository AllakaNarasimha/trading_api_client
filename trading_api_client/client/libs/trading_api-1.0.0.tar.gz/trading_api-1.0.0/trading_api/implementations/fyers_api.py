"""
Fyers API implementation for trading operations using Fyers API v3.
"""

import logging
import os
import subprocess
import sys
import time
import urllib3
import webbrowser
import json
import hashlib
from typing import Any, Callable, Dict, List, Optional, Tuple, Union, cast

import certifi

from trading_api.utils import nse_market_status
from trading_api.utils.curl_token_exchange import exchange_auth_code_with_curl
from trading_api.utils.expiry_instrument_fetcher import InstrumentExpiryFetcher
from trading_api.utils.instrument_reader import InstrumentReader, UrlType
from trading_api.utils.oauth_handler import FyersOAuthCallbackHandler, OAuthCallbackServer
from trading_api.utils.token_manager import TokenManager
from trading_api.utils.fyers_ws_manager import FyersWSManager

from ..interfaces.authentication import IAuthentication
from ..interfaces.fund_management import IFundManagement
from ..interfaces.order_management import IOrderManagement
from ..interfaces.price_watcher import IPriceWatcher


def retry_install(pip_args: List[str], max_retries: int = 5, delay: int = 2) -> bool:
    """Retry pip install command with given args up to max_retries times."""
    for attempt in range(max_retries):
        try:
            print(f"Running pip {' '.join(pip_args)}, attempt {attempt + 1}/{max_retries}")
            subprocess.check_call([sys.executable, "-m", "pip"] + pip_args)
            print(f"Successfully ran pip {' '.join(pip_args)}")
            return True
        except Exception as e:
            print(f"Attempt {attempt + 1} failed: {e}")
            if attempt < max_retries - 1:
                print(f"Waiting {delay} seconds before retry...")
                time.sleep(delay)
    print(f"Failed to run pip {' '.join(pip_args)} after {max_retries} attempts")
    return False

def check_pip_upgrade_available() -> bool:
    """Check if pip upgrade is available."""
    try:
        result = subprocess.run([sys.executable, "-m", "pip", "list", "--outdated"], capture_output=True, text=True)
        if result.returncode == 0:
            output = result.stdout
            if "pip" in output:
                print("Pip upgrade is available.")
                return True
            else:
                print("Pip is up to date.")
                return False
        else:
            print(f"Failed to check pip outdated: {result.stderr}")
            return False
    except Exception as e:
        print(f"Error checking pip upgrade: {e}")
        return False

def isFyersAvailable() -> bool:
    try:
        from fyers_apiv3 import fyersModel
        from fyers_apiv3.FyersWebsocket import data_ws
        from fyers_apiv3.FyersWebsocket.tbt_ws import FyersTbtSocket, SubscriptionModes
        print("Successfully imported fyers-apiv3 after installation")
        return True
    except ImportError as e:
        print(f"Failed to import fyers-apiv3: {e}")
        return False

def retryFyersInstallation():
    global FYERS_AVAILABLE
    if retry_install(["install", "fyers-apiv3"]):
        FYERS_AVAILABLE = isFyersAvailable()
    return FYERS_AVAILABLE

FYERS_AVAILABLE = False

try:
    from fyers_apiv3 import fyersModel
    from fyers_apiv3.FyersWebsocket import data_ws
    from fyers_apiv3.FyersWebsocket.tbt_ws import FyersTbtSocket, SubscriptionModes
    FYERS_AVAILABLE = True
except ImportError:
    print("fyers-apiv3 library not found, attempting to install...")
    FYERS_AVAILABLE = False
    retryFyersInstallation()

# Logs directory path
logs_dir = os.path.join(os.getcwd(), 'logs')
print (f"Fyers logs directory: {logs_dir}")
os.makedirs(logs_dir, exist_ok=True)


# Setup logging for Fyers API
def setup_fyers_logging():
    """Setup logging configuration for Fyers API."""
    # Configure logging
    log_file = os.path.join(logs_dir, 'fyers_api.log')
    
    # Create logger for FyersAPI
    logger = logging.getLogger('FyersAPI')
    logger.setLevel(logging.DEBUG)
    
    # Remove any existing handlers
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)
    
    # Create file handler
    file_handler = logging.FileHandler(log_file)
    file_handler.setLevel(logging.DEBUG)
    
    # Create console handler (optional, for development)
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    
    # Create formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s'
    )
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)
    
    # Add handlers to logger
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    
    return logger


# Global logger instance
fyers_logger = setup_fyers_logging()


def ensure_ssl_certificates():
    """Ensure SSL certificates are properly configured."""
    try:
        certifi_path = certifi.where()
        
        # Verify certifi can find certificates
        if not certifi_path or not os.path.exists(certifi_path):
            fyers_logger.warning("certifi certificate bundle not found")
            fyers_logger.info("Installing/updating certifi...")
            if not retry_install(["install", "--upgrade", "certifi"]):
                fyers_logger.warning("Failed to install certifi")
        
        # On Windows, also install python-certifi-win32 for SSL certificate support
        if sys.platform.startswith('win'):
            try:
                # Check if python-certifi-win32 is already installed
                import python_certifi_win32  # type: ignore
                fyers_logger.info("python-certifi-win32 is already installed")
            except ImportError:
                fyers_logger.info("Installing python-certifi-win32 for Windows SSL support")
                if not retry_install(["install", "python-certifi-win32"]):
                    fyers_logger.warning("Failed to install python-certifi-win32")
            except Exception:
                pass  # Optional package, not critical
        
        fyers_logger.info(f"SSL certificates configured: {certifi.where()}")
        return True
    except Exception as e:
        fyers_logger.warning(f"Failed to ensure SSL certificates: {e}")
        return False

# Configure SSL certificates for proper HTTPS verification
try:
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    
    # Configure requests session with SSL verification
    os.environ['SSL_CERT_FILE'] = certifi.where()
    
    # For Windows systems, use requests with verify=False for Fyers API (API is secure)
    # This is a workaround for certificate chain issues on Windows
    if sys.platform.startswith('win'):
        _FYERS_VERIFY_SSL = False  # Fyers API uses valid certificates, chain issue is local
    else:
        _FYERS_VERIFY_SSL = True
except Exception as e:
    fyers_logger.warning(f"Failed to configure SSL: {e}")
    _FYERS_VERIFY_SSL = False


class FyersSession:
    """Wrapper for Fyers SessionModel to manage authenticated API calls."""
    
    def __init__(self, client_id: str, redirect_uri: str, response_type: str, state: str, 
                 secret_key: str, grant_type: str):
        """Initialize Fyers session with OAuth credentials."""
        if not FYERS_AVAILABLE:
            retryFyersInstallation()
            if not FYERS_AVAILABLE:
                raise ImportError("fyers-apiv3 library not installed")
        
        self.session = fyersModel.SessionModel(
            client_id=client_id,
            redirect_uri=redirect_uri,
            response_type=response_type,
            state=state,
            secret_key=secret_key,
            grant_type=grant_type,
        )

class FyersAPI(IAuthentication, IOrderManagement, IFundManagement, IPriceWatcher):
    """Fyers trading API implementation using Fyers API v3."""

    def __init__(self):
        """Initialize Fyers API client."""
        # Ensure SSL certificates are properly configured
        ensure_ssl_certificates()

        if not hasattr(self, "instrument_reader"):
            self._init_instrument_reader()
        
        self._base_url = "https://api.fyers.in/api/v3"
        self._token = None
        self._access_token = None
        self._refresh_token = None
        self._is_authenticated = False
        self._session: Optional[FyersSession] = None
        self._fyers_model = None  # FyersModel for trading operations
        self._app_id: Optional[str] = None
        self._app_secret: Optional[str] = None
        self._redirect_uri: Optional[str] = None
        self._token_manager = TokenManager()
        
        if not FYERS_AVAILABLE:
            retryFyersInstallation()
            if not FYERS_AVAILABLE:
                raise ImportError("fyers-apiv3 library not installed")
        
        # WebSocket manager for auto-reconnect and idle monitoring  
        self._ws_manager: Optional[FyersWSManager] = None
    
    def _init_instrument_reader(self) -> None:
        """Initialize instrument reader for market data."""
        self.InstrumentReader = InstrumentReader
        self.UrlType = UrlType
        self.instrument_reader = self.InstrumentReader("market_data")
        self.instruments_cm = self.instrument_reader.get_csv_data(self.UrlType.CM)
        self.instruments_fo = self.instrument_reader.get_csv_data(self.UrlType.FO)
        self.inst_fetcher = InstrumentExpiryFetcher(self.instruments_fo)

    def _get_funds_profile(self) -> Optional[Dict[str, Any]]:
        """Get funds profile from Fyers API with validation."""
        if not self._fyers_model:
            return None
        if self._is_authenticated is False:
            try:
                funds = self._fyers_model.funds()
                if funds and funds.get('code') == 200 and funds.get('s') == 'ok':
                    self.funds = funds
                    self._is_authenticated = True
                    return funds
                return None
            except Exception:
                return None
        if self._is_authenticated and self.funds is not None:
            self._is_authenticated = True
            return self.funds
        return None

    # ========== IAuthentication Interface Methods ==========
    def authenticate(self, credentials: Dict[str, Any]) -> List[Any]:
        """Authenticate with Fyers API v3 using OAuth flow.
        
        Returns:
            ["success", apiclient] if successful, ["error", errormessage] if failed
        """
        try:
            if not FYERS_AVAILABLE:
                retryFyersInstallation()
                if not FYERS_AVAILABLE:
                    raise ImportError("fyers-apiv3 library not installed")                    
            
            self._app_id = credentials.get('app_id')
            self._app_secret = credentials.get('app_secret')
            self._redirect_uri = credentials.get('callback_url', 'http://localhost:8000')
            
            # Method 1: Try to use cached token first
            cached_token_data = self._token_manager.load_token('fyers')
            if cached_token_data and 'access_token' in cached_token_data:
                self._token = cached_token_data['access_token']
                self._access_token = cached_token_data['access_token']
                try:
                    # Ensure required credentials are available
                    if not self._app_id or not self._app_secret or not self._redirect_uri:
                        return ["error", "Missing required credentials for cached token authentication"]
                    
                    # Type assertions for mypy
                    app_id = cast(str, self._app_id)
                    app_secret = cast(str, self._app_secret)
                    redirect_uri = cast(str, self._redirect_uri)
                    
                    self._session = FyersSession(
                        client_id=app_id,
                        redirect_uri=redirect_uri,
                        response_type=credentials.get('response_type', 'code'),
                        state=credentials.get('state', 'state123'),
                        secret_key=app_secret,
                        grant_type=credentials.get('grant_type', 'authorization_code')
                    )
                    self._session.session.set_token(self._access_token)
                    self._fyers_model = fyersModel.FyersModel(client_id=app_id, token=self._access_token, log_path=logs_dir)
                    
                    # Validate the token
                    if self._get_funds_profile():
                        return ["success", self._fyers_model]                   

                except Exception:
                    fyers_logger.warning("Cached token expired, proceeding with fresh authentication")
                    self._token_manager.delete_token('fyers')
            
            # Method 2: Try direct token from credentials
            access_token = credentials.get('access_token')
            refresh_token = credentials.get('refresh_token')
            if access_token:
                # Ensure required credentials are available
                if not self._app_id or not self._app_secret or not self._redirect_uri:
                    return ["error", "Missing required credentials for direct token authentication"]
                
                # Type assertions for mypy
                app_id = cast(str, self._app_id)
                app_secret = cast(str, self._app_secret)
                redirect_uri = cast(str, self._redirect_uri)
                
                self._token = access_token
                self._access_token = access_token
                self._session = FyersSession(
                    client_id=app_id,
                    redirect_uri=redirect_uri,
                    response_type=credentials.get('response_type', 'code'),
                    state=credentials.get('state', 'state123'),
                    secret_key=app_secret,
                    grant_type=credentials.get('grant_type', 'authorization_code')
                )
                self._session.session.set_token(access_token)
                self._fyers_model = fyersModel.FyersModel(client_id=app_id, token=access_token, log_path=logs_dir)
                
                # Validate the token
                if not self._get_funds_profile():
                    return ["error", "Token validation failed"]
                
                # Save token for future use
                self._token_manager.save_token('fyers', {
                    'access_token': access_token,
                    'refresh_token' : refresh_token
                })

                fyers_logger.info("Successfully authenticated with Fyers API (cached token)")
                self._is_authenticated = True
                return ["success", self._fyers_model]
            
            # Method 3: OAuth flow
            if not self._app_id or not self._app_secret:
                fyers_logger.error("app_id and app_secret required for OAuth flow")
                return ["error", "app_id and app_secret required for OAuth flow"]
            
            # Ensure app_id and app_secret are not None before proceeding
            if self._app_id is None or self._app_secret is None or self._redirect_uri is None:
                fyers_logger.error("Required credentials are missing")
                return ["error", "Required credentials are missing"]
            
            result = self._oauth_login()
            if result:
                return ["success", self._fyers_model]
            else:
                return ["error", "OAuth authentication failed"]
        except Exception as e:
            fyers_logger.error(f"Fyers authentication error: {e}")
            return ["error", str(e)]

    def _oauth_login(self) -> bool:
        """Initiate OAuth login flow using SessionModel."""
        assert self._app_id is not None
        assert self._app_secret is not None
        assert self._redirect_uri is not None
        try:
            # Initialize SessionModel with OAuth credentials
            self._session = FyersSession(
                client_id=self._app_id,
                redirect_uri=self._redirect_uri,
                response_type='code',   
                state='state',             
                secret_key=self._app_secret,
                grant_type='authorization_code'
            )
            
            # Generate authorization URL via SessionModel
            auth_url = self._session.session.generate_authcode()
            fyers_logger.info(f"Opening authorization URL: {auth_url}")
            
            # Try to open in Google Chrome incognito first, fallback to default browser
            opened = False
            if sys.platform.startswith('win'):
                chrome_paths = [
                    "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
                    "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe"
                ]
                for path in chrome_paths:
                    if os.path.exists(path):
                        try:
                            subprocess.Popen([path, '--incognito', auth_url])
                            fyers_logger.info("Opened in Google Chrome incognito")
                            opened = True
                            break
                        except Exception:
                            pass
            if not opened:
                webbrowser.open(auth_url)
                fyers_logger.info("Opened in default browser")
            
            callback_server = OAuthCallbackServer(FyersOAuthCallbackHandler)
            callback_data = callback_server.listen_for_callback()
            
            if not callback_data:
                fyers_logger.error("Failed to receive authorization response")
                return False
            
            # Handle different callback data formats
            if 'access_token' in callback_data:
                # Direct access token received
                self._token = callback_data['access_token']
                self._access_token = callback_data['access_token']
                self._refresh_token = callback_data.get('refresh_token')
                self._session.session.set_token(self._access_token)
                self._fyers_model = fyersModel.FyersModel(client_id=self._app_id, token=self._access_token, log_path=logs_dir)
                
                # Validate the token
                if not self._get_funds_profile():
                    fyers_logger.error("Token validation failed")
                    return False                
                
                # Save token for future use
                self._token_manager.save_token('fyers', {
                    'access_token': self._access_token,
                    'refresh_token': self._refresh_token
                })
                self._is_authenticated = True
                fyers_logger.info("Successfully authenticated with Fyers API v3")
                return True
            elif 'auth_code' in callback_data or 'code' in callback_data:
                code = callback_data.get('auth_code') or callback_data.get('code')
                result = self.generate_access_token_from_auth_code(code)
                if not result:
                    fyers_logger.error("Failed to exchange authorization code for tokens")
                    return False
                
                access_token, refresh_token = result
                
                self._session.session.set_token(access_token)
                self._fyers_model = fyersModel.FyersModel(client_id=self._app_id, token=access_token, log_path=logs_dir)
                
                # Validate the token
                if self._get_funds_profile() is None:
                    fyers_logger.error("Token validation failed")
                    return False   

                fyers_logger.info("Successfully authenticated with Fyers API v3")
                return True
            else:
                fyers_logger.error("No valid authorization data received")
                return False
            
        except Exception as e:
            fyers_logger.error(f"OAuth login error: {e}")
            return False

    def _refresh_access_token(self, refresh_token: str) -> Optional[Tuple[str, Optional[str]]]:
        """Refresh access token using refresh token."""
        try:
            # Curl command for token refresh
            curl_command = [
                "curl",
                "--location",
                "--request", "POST",
                "https://api-t1.fyers.in/api/v3/token",  # Token endpoint
                "--header", "Content-Type: application/json",
                "--ssl-no-revoke",  # Bypass SSL revocation check on Windows
                "--data-raw", json.dumps({
                    "grant_type": "refresh_token",
                    "appIdHash": hashlib.sha256(f"{self._app_id}:{self._app_secret}".encode()).hexdigest(),
                    "refresh_token": refresh_token
                })
            ]

            print(f"[INFO] Refreshing access token...")
            print(f"[DEBUG] Using app_id: {self._app_id}")

            # Run curl command
            result = subprocess.run(
                curl_command,
                capture_output=True,
                text=True,
                timeout=60
            )

            if result.returncode != 0:
                print(f"[FAIL] Curl command failed with exit code {result.returncode}")
                print(f"[DEBUG] Error: {result.stderr}")
                return None

            print(f"[DEBUG] Raw response: {result.stdout}")
            print(f"[DEBUG] Raw stderr: {result.stderr}")

            # Parse JSON response
            try:
                response_data = json.loads(result.stdout)
                if 'access_token' in response_data:
                    access_token = response_data['access_token']
                    refresh_token_new = response_data.get('refresh_token')
                    print(f"[OK] Access token refreshed: {access_token[:20]}...")
                    return access_token, refresh_token_new
                else:
                    print(f"[FAIL] No access_token in response: {response_data}")
                    return None
            except json.JSONDecodeError:
                # Check if it's an HTML error page
                if '<html>' in result.stdout.lower():
                    print(f"[FAIL] Server returned HTML error page (likely 503 or maintenance): {result.stdout.strip()}")
                else:
                    print(f"[FAIL] Failed to parse JSON response: {result.stdout}")
                return None

        except subprocess.TimeoutExpired:
            print("[FAIL] Request timed out")
            return None
        except Exception as e:
            print(f"[FAIL] Token refresh error: {e}")
            return None

    def generate_access_token_from_auth_code(self, auth_code: str) -> Optional[Tuple[str, Optional[str]]]:
        """Handle authorization code exchange for access and refresh tokens."""
        try:
            self._session.session.set_token(auth_code)
            response = self._session.session.generate_token()

            print(response)
            
            if response.get('s') == 'error':
                access_token = self._exchange_auth_code(auth_code)
                if not access_token:
                    return None
            else:
                access_token = response.get('access_token')
                if not access_token:
                    return None
            
            refresh_token = response.get('refresh_token')

            # Save token for future use
            self._token_manager.save_token('fyers', {
                'access_token': access_token,
                'refresh_token': refresh_token
            })

            self._access_token = access_token
            self._refresh_token = refresh_token
            self._is_authenticated = True
            
            return access_token, refresh_token
        except Exception as e:
            fyers_logger.error(f"Error handling auth code: {e}")
            return None

    def get_token(self) -> str:
        """Get authentication token."""
        return self._token or ""

    def refresh_token(self) -> bool:
        """Refresh authentication token using refresh token."""
        try:
            if not self._refresh_token:
                fyers_logger.warning("No refresh token available")
                return False
            
            # Use the refresh token to get a new access token
            result = self._refresh_access_token(self._refresh_token)
            if result:
                new_access_token, new_refresh_token = result
                self._access_token = new_access_token
                self._refresh_token = new_refresh_token
                self._token = new_access_token
                
                # Update Fyers model with new token
                self._fyers_model = fyersModel.FyersModel(client_id=self._app_id, token=new_access_token, log_path=logs_dir)
                
                # Save the new tokens
                self._token_manager.save_token('fyers', {
                    'access_token': new_access_token
                })
                if new_refresh_token:
                    self._token_manager.save_token('fyers', {
                        'refresh_token': new_refresh_token
                    })
                
                fyers_logger.info("Successfully refreshed access token")
                return True
            else:
                fyers_logger.error("Failed to refresh access token")
                return False
        except Exception as e:
            fyers_logger.error(f"Fyers token refresh error: {e}")
            return False

    def is_authenticated(self) -> bool:
        """Check authentication status."""
        return self._is_authenticated
    
    def _init_ws_manager(self) -> None:
        """Initialize WebSocket manager with current access token."""
        if self._access_token and not self._ws_manager:
            self._ws_manager = FyersWSManager(
                access_token=self._access_token,
                log_path=logs_dir
            )
            fyers_logger.info("WebSocket manager initialized")

    def _ensure_authenticated(self) -> bool:
        """Ensure the client is authenticated."""
        if self._is_authenticated and self._fyers_model:
            # Validate the current token
            if self._get_funds_profile() is None:
                fyers_logger.info("Token validation failed, attempting to refresh token...")
                # Try to refresh the token first
                if self.refresh_token():
                    fyers_logger.info("Token refreshed successfully")
                    return True
                else:
                    fyers_logger.info("Token refresh failed, re-authenticating...")
                    self._is_authenticated = False
                    self._token = None
                    self._access_token = None
                    self._refresh_token = None
                    self._fyers_model = None
                    self._token_manager.delete_token('fyers')
        
        # If not authenticated or validation/refresh failed, try to authenticate
        if not self._is_authenticated:
            if self._app_id and self._app_secret:
                result = self.authenticate({
                    'app_id': self._app_id,
                    'app_secret': self._app_secret,
                    'callback_url': self._redirect_uri or 'http://localhost:8000'
                })
                if isinstance(result, list) and result[0] == "success":
                    return True
            fyers_logger.error("Re-authentication failed")
            return False
        
        return self._is_authenticated

    # ========== IOrderManagement Interface Methods ==========
    def place_order(self, order_details: Dict[str, Any]) -> Dict[str, Any]:
        """Place order on Fyers."""
        try:
            if not self._ensure_authenticated() or not self._fyers_model:
                return {'error': 'Not authenticated'}
            
            if not FYERS_AVAILABLE:
                retryFyersInstallation()
                if not FYERS_AVAILABLE:
                    return {'error': 'fyers-apiv3 library not available'}
            
            # Prepare order data as dictionary
            order_data = {
                "symbol": order_details.get('symbol', ''),
                "qty": order_details.get('quantity', 1),
                "type": self._map_order_type(order_details.get('order_type', 'LIMIT')),
                "side": self._map_side(order_details.get('side', 'BUY')),
                "productType": order_details.get('product_type', 'CNC'),
                "limitPrice": order_details.get('price', 0),
                "stopPrice": order_details.get('stop_price', 0),
                "validity": order_details.get('time_in_force', 'DAY'),
                "disclosedQty": order_details.get('disclosed_qty', 0),
                "offlineOrder": False
            }
            
            response = self._fyers_model.place_order(data=order_data)
            
            if response.get('s') == 'error':
                return {'error': response.get('message', 'Order placement failed')}
            
            return {
                'order_id': response.get('id', ''),
                'status': response.get('s', 'pending'),
                'symbol': order_details.get('symbol'),
                'qty': order_details.get('quantity'),
                'message': response.get('message', 'Order placed successfully')
            }
        except Exception as e:
            return {'error': str(e)}

    def modify_order(self, order_id: str, modification_details: Dict[str, Any]) -> Dict[str, Any]:
        """Modify order on Fyers."""
        try:
            if not self._ensure_authenticated() or not self._fyers_model:
                return {'error': 'Not authenticated'}
            
            # Prepare modification data
            modify_data = {
                "id": order_id,
                "type": modification_details.get('type'),
                "limitPrice": modification_details.get('price', 0),
                "stopPrice": modification_details.get('stop_price', 0),
                "qty": modification_details.get('quantity', 0)
            }
            
            response = self._fyers_model.modify_order(data=modify_data)
            
            if response.get('s') == 'error':
                return {'error': response.get('message', 'Order modification failed')}
            
            return {
                'order_id': order_id,
                'status': response.get('s', 'modified'),
                'message': response.get('message', 'Order modified successfully')
            }
        except Exception as e:
            return {'error': str(e)}

    def cancel_order(self, order_id: str) -> bool:
        """Cancel order on Fyers."""
        try:
            if not self._ensure_authenticated() or not self._fyers_model:
                return False
            
            cancel_data = {"id": order_id}
            response = self._fyers_model.cancel_order(data=cancel_data)
            if response.get('s') == 'error':
                return False
            return response.get('s') == 'ok'
        except Exception as e:
            fyers_logger.error(f"Fyers cancel order error: {e}")
            return False

    def get_order_status(self, order_id: str) -> Dict[str, Any]:
        """Get order status from Fyers."""
        try:
            if not self._ensure_authenticated() or not self._fyers_model:
                return {'error': 'Not authenticated'}
            
            response = self._fyers_model.orderbook()
            if response.get('s') == 'error':
                return {'error': response.get('message', 'Failed to get order status')}
            orders = response.get('orderBook', [])
            order = next((o for o in orders if o.get('id') == order_id), None)
            
            if not order:
                return {'error': 'Order not found'}
            
            return {
                'order_id': order_id,
                'status': order.get('status', 'unknown'),
                'quantity': order.get('qty'),
                'price': order.get('limitPrice'),
                'filled': order.get('filledQty', 0)
            }
        except Exception as e:
            return {'error': str(e)}

    def get_all_orders(self) -> List[Dict[str, Any]]:
        """Get all orders from Fyers."""
        try:
            if not self._ensure_authenticated() or not self._fyers_model:
                return []
            
            response = self._fyers_model.orderbook()
            if response.get('s') == 'error':
                return []
            orders = response.get('orderBook', []) if response else []
            return orders
        except Exception as e:
            fyers_logger.error(f"Fyers get all orders error: {e}")
            return []

    # ========== IFundManagement Interface Methods ==========
    def get_balance(self) -> Dict[str, Any]:
        """Get account balance from Fyers."""
        try:
            if not self._ensure_authenticated() or not self._fyers_model:
                return {'error': 'Not authenticated'}
            
            funds = self._get_funds_profile()
            
            if not funds:
                return {'error': 'Failed to fetch funds data'}
            
            fund_limit = funds.get('fund_limit', [])
            
            # Extract balance data from the list
            balance_data = {}
            for item in fund_limit:
                title = item.get('title', '')
                equity_amount = item.get('equityAmount', 0)
                commodity_amount = item.get('commodityAmount', 0)
                balance_data[title] = {
                    'equity': equity_amount,
                    'commodity': commodity_amount
                }
            
            # Map to standard fields
            available = balance_data.get('Available Balance', {}).get('equity', 0)
            used = balance_data.get('Utilized Amount', {}).get('equity', 0)
            total = balance_data.get('Total Balance', {}).get('equity', 0)
            
            return {
                'available': available,
                'used': used,
                'total': total,
                'all_data': balance_data,
                'message': 'Balance fetched successfully'
            }
        except Exception as e:
            return {'error': str(e)}

    def get_holdings(self) -> Dict[str, Any]:
        """Get holdings from Fyers."""
        try:
            if not self._ensure_authenticated() or not self._fyers_model:
                return {'error': 'Not authenticated'}
            
            response = self._fyers_model.holdings()
            if response.get('s') == 'error':
                return {'error': response.get('message', 'Failed to get holdings')}
            return response if response else {}
        except Exception as e:
            return {'error': str(e)}

    def get_positions(self) -> Dict[str, Any]:
        """Get positions from Fyers."""
        try:
            if not self._ensure_authenticated() or not self._fyers_model:
                return {'error': 'Not authenticated'}
            
            response = self._fyers_model.positions()
            if response.get('s') == 'error':
                return {'error': response.get('message', 'Failed to get positions')}
            return response if response else {}
        except Exception as e:
            return {'error': str(e)}
    
    def get_market_status(self) -> Dict[str, Any]:
        """Get NSE market status (no authentication required)."""
        try:
            return nse_market_status.get_market_status()
        except Exception as e:
            fyers_logger.error(f"Error fetching market status: {e}")
            return {
                'error': str(e),
                'equity': {'is_open': False, 'message': 'Unable to fetch market status'},
                'derivatives': {'is_open': False, 'message': 'Unable to fetch market status'}
            }

    def get_margin_requirement(self, symbol: str, quantity: int) -> Dict[str, Any]:
        """Get margin requirement from Fyers."""
        try:
            if not self._ensure_authenticated() or not self._fyers_model:
                return {'error': 'Not authenticated'}
            
            # Fyers API v3 does not have direct margin calculation
            # Estimate margin based on current price (assuming 10% margin)
            price_data = self.get_price(symbol)
            if 'error' in price_data:
                return {'error': 'Unable to fetch price for margin calculation'}
            
            ltp = price_data.get('ltp', 0)
            if ltp == 0:
                return {'error': 'Invalid price for margin calculation'}
            
            # Estimate margin requirement (10% of order value)
            margin_required = quantity * ltp * 0.1
            return {
                'margin_required': margin_required,
                'estimated': True,
                'assumptions': '10% margin on order value',
                'ltp': ltp,
                'quantity': quantity
            }
        except Exception as e:
            return {'error': str(e)}

    def get_price(self, symbol: str) -> Dict[str, Any]:
        """Get price from Fyers."""
        try:
            if not self._ensure_authenticated() or not self._fyers_model:
                return {'error': 'Not authenticated'}           
            
            quote_response = self._fyers_model.quotes(
                data={"symbols": symbol}
            )

            # Check for error response
            if isinstance(quote_response, dict) and quote_response.get('s') == 'error':
                return {'error': quote_response.get('message', 'Authentication failed')}
            
            # Handle the response which is a dictionary
            if isinstance(quote_response, dict) and 'd' in quote_response and quote_response['d']:
                data = quote_response['d'][0].get('v', {})
            else:
                data = {}
                
            return {
                'symbol': symbol,
                'ltp': data.get('lp', 0),
                'bid': data.get('bid', 0),
                'ask': data.get('ask', 0),
                'open': data.get('open_price', 0),
                'high': data.get('high_price', 0),
                'low': data.get('low_price', 0),
                'close': data.get('prev_close_price', 0),
                'change': data.get('ch', 0),
                'change_percent': data.get('chp', 0),
                'volume': data.get('volume', 0),
                'atp': data.get('atp', 0),
                'spread': data.get('spread', 0),
                'exchange': data.get('exchange', ''),
                'description': data.get('description', ''),
                'short_name': data.get('short_name', ''),
                'message': 'Price fetched successfully'
            }
        except Exception as e:
            return {'error': str(e)}

    def get_quotes(self, symbols: List[str]) -> Dict[str, Dict[str, Any]]:
        """Get quotes for multiple symbols from Fyers."""
        try:
            if not self._ensure_authenticated() or not self._fyers_model:
                return {}
            
            quotes_response = self._fyers_model.quotes(data={"symbols": ",".join(symbols)})
            
            # Cast response to dict for type checking
            quotes_response = cast(Dict[str, Any], quotes_response)
            
            if quotes_response.get('s') == 'error':
                return {}
            
            # Handle the response which could be a dictionary or nested structure
            if not isinstance(quotes_response, dict):
                return {}
                
            quotes = {}
            data_list = quotes_response.get('d', [])
            for symbol in symbols:
                item = next((item for item in data_list if item.get('n') == symbol), None)
                if item and 'v' in item:
                    data = item['v']
                else:
                    data = {}
                
                quotes[symbol] = {
                    'ltp': data.get('lp', 0),
                    'bid': data.get('bid', 0),
                    'ask': data.get('ask', 0),
                    'open': data.get('open_price', 0),
                    'high': data.get('high_price', 0),
                    'low': data.get('low_price', 0),
                    'close': data.get('prev_close_price', 0),
                    'change': data.get('ch', 0),
                    'change_percent': data.get('chp', 0),
                    'volume': data.get('volume', 0),
                    'atp': data.get('atp', 0),
                    'spread': data.get('spread', 0),
                    'exchange': data.get('exchange', ''),
                    'description': data.get('description', ''),
                    'short_name': data.get('short_name', '')
                }
            return quotes
        except Exception as e:
            return {}

    # ========== IPriceWatcher Interface Methods ==========
    def subscribe_to_price(self, symbol: str, callback: Callable) -> Union[bool, str]:
        """Subscribe to real-time LTP price updates from Fyers using WebSocket Manager."""
        try:
            if not self._ensure_authenticated():
                return "Not authenticated"
            
            if not FYERS_AVAILABLE:
                retryFyersInstallation()
                if not FYERS_AVAILABLE:
                    return "fyers-apiv3 library not available"    
            
            if not self._access_token:
                return "No access token available"
            
            # Initialize WS manager if needed
            self._init_ws_manager()
            
            if not self._ws_manager:
                fyers_logger.error("Failed to initialize WebSocket manager")
                return "Failed to initialize WebSocket manager"
            
            # Use WS manager for subscription
            return self._ws_manager.subscribe_to_price(symbol, callback)
        except Exception as e:
            fyers_logger.error(f"Fyers LTP subscription error: {e}")
            return f"LTP subscription error: {e}"

    def unsubscribe_from_price(self, symbol: str) -> Union[bool, str]:
        """Unsubscribe from LTP price updates from Fyers."""
        try:
            if not self._ensure_authenticated():
                return "Not authenticated"
            
            if not self._ws_manager:
                return "WebSocket manager not initialized"
            
            return self._ws_manager.unsubscribe_from_price(symbol)
        except Exception as e:
            fyers_logger.error(f"Fyers LTP unsubscription error: {e}")
            return f"LTP unsubscription error: {e}"

    def subscribe_to_depth(self, symbol: str, callback: Callable) -> Union[bool, str]:
        """Subscribe to real-time depth updates from Fyers using WebSocket Manager."""
        try:
            if not self._ensure_authenticated():
                return "Not authenticated"
            
            if not FYERS_AVAILABLE:
                retryFyersInstallation()
                if not FYERS_AVAILABLE:
                    return "fyers-apiv3 library not available"
            
            if not self._access_token:
                return "No access token available"
            
            # Initialize WS manager if needed
            self._init_ws_manager()
            
            if not self._ws_manager:
                fyers_logger.error("Failed to initialize WebSocket manager")
                return "Failed to initialize WebSocket manager"
            
            # Use WS manager for subscription
            return self._ws_manager.subscribe_to_depth(symbol, callback)
        except Exception as e:
            fyers_logger.error(f"Fyers depth subscription error: {e}")
            return f"Depth subscription error: {e}"

    def unsubscribe_from_depth(self, symbol: str) -> Union[bool, str]:
        """Unsubscribe from depth updates from Fyers."""
        try:
            if not self._ensure_authenticated():
                return "Not authenticated"
            
            if not self._ws_manager:
                return "WebSocket manager not initialized"
            
            return self._ws_manager.unsubscribe_from_depth(symbol)
        except Exception as e:
            fyers_logger.error(f"Fyers depth unsubscription error: {e}")
            return f"Depth unsubscription error: {e}"

    def get_historical_data(self, symbol: str, resolution: str, date_format: str, period_start: int, period_end: int, cont_flag: str = "1") -> Union[List[List[Any]], str]:
        """Get historical data from Fyers."""
        try:
            if not self._ensure_authenticated() or not self._fyers_model:
                return "Fyers not authenticated"
            
            # Use FyersModel.history() method for historical data
            data = self._fyers_model.history(
                data={
                    "symbol": symbol,
                    "resolution": resolution,
                    "date_format": date_format,
                    "range_from": str(period_start),
                    "range_to": str(period_end),
                    "cont_flag": cont_flag
                }
            )
            
            # Cast response to dict for type checking
            data = cast(Dict[str, Any], data)
            
            if data.get('s') == 'error':
                return f"Fyers historical data error: {data.get('s', 'Unknown error')}"
                
            return data.get('candles', []) if data and isinstance(data, dict) else []
        except Exception as e:
            fyers_logger.error(f"Fyers historical data error: {e}")
            return f"Fyers historical data error: {e}"

    def get_option_chain(self, symbol: str, strikecount: int = 1, timestamp: str = "") -> Dict[str, Any]:
        """Get option chain data from Fyers."""
        try:
            if not self._ensure_authenticated() or not self._fyers_model:
                return {'error': 'Not authenticated', 'code': 401, 's': 'error', 'message': 'Not authenticated'}
            
            # Prepare option chain request data
            data = {
                "symbol": symbol,
                "strikecount": strikecount,
                "timestamp": timestamp
            }
            
            # Call Fyers API optionchain method
            response = self._fyers_model.optionchain(data=data)
            
            # Cast response to dict for type checking
            response = cast(Dict[str, Any], response)
            
            # Check for error response
            if response.get('s') == 'error':
                fyers_logger.error(f"Option chain fetch error: {response.get('message', 'Unknown error')}")
                return response
            
            # Return successful response
            return response
        except Exception as e:
            fyers_logger.error(f"Fyers option chain error: {e}")
            return {
                'error': str(e),
                'code': 500,
                's': 'error',
                'message': str(e)
            }    

    def get_trading_holidays(self, market_type: str = "CM") -> List[str]:
        """Get NSE trading holidays (no authentication required)."""
        try:
            return nse_market_status.get_holidays(market_type)
        except Exception as e:
            fyers_logger.error(f"Error fetching trading holidays: {e}")
            return []

    def get_trading_hours(self, market_type: str = "equity") -> Dict[str, Dict[str, str]]:
        """Get NSE trading hours (no authentication required)."""
        try:
            return nse_market_status.get_trading_hours(market_type)
        except Exception as e:
            fyers_logger.error(f"Error fetching trading hours: {e}")
            return {}

    def is_market_open(self, market_type: str = "equity") -> Dict[str, Any]:
        """Check if NSE market is currently open (no authentication required)."""
        try:
            return nse_market_status.is_market_open(market_type)
        except Exception as e:
            fyers_logger.error(f"Error checking market open status: {e}")
            return {
                'is_open': False,
                'error': str(e),
                'message': 'Unable to check market status'
            }

    # ========== Utility Methods ==========
    @staticmethod
    def _map_order_type(order_type: str) -> str:
        """Map order type to Fyers API v3 format."""
        mapping = {
            'LIMIT': '1',
            'MARKET': '2',
            'STOP': '3',
            'STOP_LIMIT': '4'
        }
        return mapping.get(order_type, '1')

    @staticmethod
    def _map_side(side: str) -> str:
        """Map order side to Fyers API v3 format."""
        return '1' if side.upper() == 'BUY' else '-1'
