"""
Dhan API implementation for trading operations using DhanHQ API v2.
"""

import webbrowser
import requests
from typing import Dict, Any, List, Callable, Optional, Union

# Use relative imports within the package
from ..interfaces.authentication import IAuthentication
from ..interfaces.order_management import IOrderManagement
from ..interfaces.fund_management import IFundManagement
from ..interfaces.price_watcher import IPriceWatcher
from ..utils.oauth_handler import OAuthCallbackServer, DhanOAuthCallbackHandler
from ..utils.token_manager import TokenManager
from ..utils import nse_market_status

try:
    from dhanhq import dhanhq
    DHAN_AVAILABLE = True
except ImportError:
    DHAN_AVAILABLE = False


class DhanAPI(IAuthentication, IOrderManagement, IFundManagement, IPriceWatcher):
    """Dhan trading API implementation using DhanHQ API v2."""

    def __init__(self):
        """Initialize Dhan API client."""
        self._base_url = "https://api.dhan.co/v2"
        self._auth_url = "https://auth.dhan.co"
        self._client_id: Optional[str] = None
        self._access_token: Optional[str] = None
        self._app_id: Optional[str] = None
        self._app_secret: Optional[str] = None
        self._dhan_client: Optional[Any] = None
        self._is_authenticated = False
        self._subscriptions: Dict[str, Callable] = {}
        self._redirect_uri: Optional[str] = None
        self._token_manager = TokenManager()
        
        if not DHAN_AVAILABLE:
            print("Warning: dhanhq library not installed. Install with: pip install dhanhq")

    def authenticate(self, credentials: Dict[str, Any]) -> List[Union[str, Any]]:
        """Authenticate with DhanHQ API v2."""
        print("AUTHENTICATE START")
        try:
            if not DHAN_AVAILABLE:
                return ["error", "dhanhq library not installed"]
            
            self._client_id = credentials.get('client_id')
            self._app_id = credentials.get('app_id')
            self._app_secret = credentials.get('app_secret')
            self._redirect_uri = credentials.get('callback_url', 'http://localhost:8000')
            
            # Try cached token
            cached_token_data = self._token_manager.load_token('dhan')
            if cached_token_data and 'access_token' in cached_token_data:
                self._access_token = cached_token_data['access_token']
                self._client_id = cached_token_data.get('client_id', self._client_id)
                self._dhan_client = dhanhq(self._client_id, self._access_token)
                
                # Validate the cached token
                if self._validate_token():
                    self._is_authenticated = True
                    print("AUTHENTICATE SUCCESS")
                    return ["success", self._dhan_client]
                else:
                    print("AUTHENTICATE TOKEN INVALID")
            
            # Method 2: Try direct token from credentials
            access_token = credentials.get('access_token')
            if access_token:
                result = self._authenticate_with_token(access_token)
                if result:
                    return ["success", self._dhan_client]
                else:
                    return ["error", "Direct token authentication failed"]
            
            # Method 3: OAuth flow
            if self._app_id and self._app_secret:
                result = self._authenticate_with_oauth()
                if result:
                    return ["success", self._dhan_client]
                else:
                    return ["error", "OAuth authentication failed"]
            
            return ["error", "No valid authentication method"]
                
        except Exception as e:
            print(f"AUTHENTICATE ERROR: {e}")
            return ["error", str(e)]

    def _authenticate_with_token(self, access_token: Optional[str] = None) -> bool:
        """Direct authentication using pre-generated access token."""
        try:
            if access_token:
                self._access_token = access_token
            
            print("Attempting direct token authentication...")
            self._dhan_client = dhanhq(self._client_id, self._access_token)
            self._is_authenticated = True
            
            self._token_manager.save_token('dhan', {
                'access_token': self._access_token,
                'client_id': self._client_id
            })
            print("[OK] Successfully authenticated with Dhan API (direct token)")
            return True
        except Exception as e:
            print(f"Direct token authentication error: {e}")
            return False

    def _authenticate_with_oauth(self) -> bool:
        """OAuth-like authentication flow using app credentials."""
        try:
            print("Initiating DhanHQ OAuth flow...")
            
            consent_app_id = self._generate_consent()
            if not consent_app_id:
                print("Error: Failed to generate consent")
                return False
            
            token_id = self._browser_login(consent_app_id)
            if not token_id:
                print("Error: Failed to receive token ID")
                return False
            
            self._access_token = self._consume_consent(token_id)
            if not self._access_token:
                print("Error: Failed to consume consent")
                return False
            
            print("Attempting OAuth token authentication...")
            self._dhan_client = dhanhq(self._client_id, self._access_token)
            self._is_authenticated = True
            
            self._token_manager.save_token('dhan', {
                'access_token': self._access_token,
                'client_id': self._client_id
            })
            
            print("[OK] Successfully authenticated with Dhan API (OAuth flow)")
            return True
        except Exception as e:
            print(f"OAuth authentication error: {e}")
            return False

    def _generate_consent(self) -> Optional[str]:
        """Step 1: Generate consent from Dhan auth server."""
        try:
            url = f"{self._auth_url}/app/generate-consent"
            if self._client_id:
                url += f"?client_id={self._client_id}"
            headers = {
                'app_id': self._app_id,
                'app_secret': self._app_secret
            }
            
            response = requests.post(url, headers=headers, timeout=10)
            if response.status_code == 200:
                data = response.json()
                consent_app_id = data.get('consentAppId')
                if consent_app_id:
                    print(f"[OK] Consent generated: {consent_app_id[:20]}...")
                    return consent_app_id
        except Exception as e:
            print(f"Generate consent error: {e}")
        
        return None

    def _browser_login(self, consent_app_id: str) -> Optional[str]:
        """Step 2: Open browser for user login and retrieve token ID."""
        try:
            login_url = f"{self._auth_url}/login/consentApp-login?consentAppId={consent_app_id}"
            print(f"\nOpening login URL: {login_url}")
            webbrowser.open(login_url)
            
            callback_server = OAuthCallbackServer(DhanOAuthCallbackHandler)
            callback_data = callback_server.listen_for_callback()
            
            if callback_data and 'tokenId' in callback_data:
                print(f"[OK] Received token ID from callback")
                return callback_data['tokenId']
        except Exception as e:
            print(f"Browser login error: {e}")
        
        return None

    def _consume_consent(self, token_id: str) -> Optional[str]:
        """Step 3: Exchange token ID for access token."""
        try:
            url = f"{self._auth_url}/app/consumeApp-consent"
            headers = {
                'app_id': self._app_id,
                'app_secret': self._app_secret,
                'tokenId': token_id
            }
            
            response = requests.post(url, headers=headers, timeout=10)
            if response.status_code == 200:
                data = response.json()
                access_token = data.get('accessToken')
                if access_token:
                    print(f"[OK] Access token obtained: {access_token[:20]}...")
                    return access_token
        except Exception as e:
            print(f"Consume consent error: {e}")
        
        return None

    def _ensure_authenticated(self) -> bool:
        """
        Ensure the client is authenticated, re-authenticating if necessary.
        
        This method is called before API operations to ensure valid authentication.
        It follows this flow:
        1. Check if already authenticated
        2. If not, or if token is invalid, attempt re-authentication
        3. Try token refresh first, then full OAuth flow if refresh fails
        """
        try:
            # If not authenticated at all, need full authentication
            if not self._is_authenticated:
                print("[INFO] Not authenticated, initiating full authentication...")
                if self._app_id and self._app_secret:
                    return self._authenticate_with_oauth()
                else:
                    print("[ERROR] No app credentials available for authentication")
                    return False
            
            # If authenticated, validate the current token
            if not self._validate_token():
                print("[INFO] Token validation failed, attempting refresh...")
                
                # Try to refresh the token first
                if self._renew_token():
                    # Re-validate after refresh
                    if self._validate_token():
                        print("[OK] Token refreshed successfully")
                        return True
                    else:
                        print("[INFO] Token refresh validation failed, trying full authentication...")
                else:
                    print("[INFO] Token refresh failed, trying full authentication...")
                
                # If refresh fails, do full OAuth authentication
                if self._app_id and self._app_secret:
                    print("[INFO] Initiating full OAuth re-authentication...")
                    return self._authenticate_with_oauth()
                else:
                    print("[ERROR] No app credentials available for re-authentication")
                    self._is_authenticated = False
                    return False
            
            # Token is valid
            return True
            
        except Exception as e:
            print(f"[ERROR] Authentication check failed: {e}")
            self._is_authenticated = False
            return False

    def _validate_token(self) -> bool:
        """Validate the access token by making a test API call."""
        try:
            if not self._dhan_client:
                return False
            # Use get_fund_limits as a lightweight API call to validate token
            limits = self._dhan_client.get_fund_limits()
            if limits and isinstance(limits, dict) and limits.get('status') == 'failure':
                return False
            return limits is not None
        except Exception as e:
            print(f"Token validation error: {e}")
            return False

    def _renew_token(self) -> bool:
        """Renew access token (valid for another 24 hours)."""
        try:
            url = f"{self._base_url}/RenewToken"
            headers = {
                'Authorization': f'Bearer {self._access_token}'
            }
            
            response = requests.post(url, headers=headers, timeout=10)
            if response.status_code == 200:
                data = response.json()
                new_token = data.get('accessToken')
                if new_token:
                    self._access_token = new_token
                    print("[OK] Token renewed successfully")
                    return True
        except Exception as e:
            print(f"Token renewal error: {e}")
        
        return False

    def get_token(self) -> str:
        """Get authentication token."""
        return self._access_token or ""

    def refresh_token(self) -> bool:
        """Refresh authentication token."""
        try:
            if not self._is_authenticated:
                return False
            return self._renew_token()
        except Exception as e:
            print(f"Dhan token refresh error: {e}")
            return False

    def is_authenticated(self) -> bool:
        """Check authentication status."""
        return self._is_authenticated

    def place_order(self, order_details: Dict[str, Any]) -> Dict[str, Any]:
        """Place order on Dhan."""
        try:
            # Ensure authentication before API call
            if not self._ensure_authenticated():
                return {'error': 'Authentication failed'}
            
            if not DHAN_AVAILABLE:
                return {'error': 'dhanhq library not available'}
            
            if not self._dhan_client:
                return {'error': 'Dhan client not initialized'}
            
            symbol = order_details.get('symbol', '')
            quantity = order_details.get('quantity', 1)
            price = order_details.get('price', 0)
            order_type = order_details.get('order_type', 'LIMIT')
            side = order_details.get('side', 'BUY')
            
            response = self._dhan_client.place_order(
                symbol=symbol,
                quantity=quantity,
                price=price,
                order_type=order_type,
                side=side
            )
            
            return {
                'order_id': response.get('orderId'),
                'status': 'pending',
                'message': 'Order placed successfully'
            }
        except Exception as e:
            return {'error': str(e)}

    def modify_order(self, order_id: str, modification_details: Dict[str, Any]) -> Dict[str, Any]:
        """Modify order on Dhan."""
        try:
            if not self._ensure_authenticated():
                return {'error': 'Authentication failed'}
            
            if not self._dhan_client:
                return {'error': 'Dhan client not initialized'}
            
            response = self._dhan_client.modify_order(
                order_id=order_id,
                order_details=modification_details
            )
            
            return {
                'order_id': order_id,
                'status': 'modified',
                'message': 'Order modified successfully'
            }
        except Exception as e:
            return {'error': str(e)}

    def cancel_order(self, order_id: str) -> bool:
        """Cancel order on Dhan."""
        try:
            if not self._ensure_authenticated():
                return False
            
            if not self._dhan_client:
                return False
            
            self._dhan_client.cancel_order(order_id=order_id)
            return True
        except Exception as e:
            print(f"Dhan cancel order error: {e}")
            return False

    def get_order_status(self, order_id: str) -> Dict[str, Any]:
        """Get order status from Dhan."""
        try:
            if not self._ensure_authenticated():
                return {'error': 'Authentication failed'}
            
            if not self._dhan_client:
                return {'error': 'Dhan client not initialized'}
            
            order = self._dhan_client.get_order_by_id(order_id=order_id)
            return {
                'order_id': order_id,
                'status': order.get('status', 'unknown'),
                'quantity': order.get('quantity'),
                'price': order.get('price')
            }
        except Exception as e:
            return {'error': str(e)}

    def get_all_orders(self) -> List[Dict[str, Any]]:
        """Get all orders from Dhan."""
        try:
            if not self._ensure_authenticated():
                return []
            
            if not self._dhan_client:
                return []
            
            orders = self._dhan_client.get_order_list()
            return orders if orders else []
        except Exception as e:
            print(f"Dhan get all orders error: {e}")
            return []

    def get_balance(self) -> Dict[str, Any]:
        """Get account balance from Dhan."""
        try:
            # Ensure authentication before API call
            if not self._ensure_authenticated():
                return {'error': 'Authentication failed'}
            
            if not self._dhan_client:
                return {'error': 'Dhan client not initialized'}
            
            limits = self._dhan_client.get_fund_limits()
            return {
                'available': limits.get('availabelBalance', 0),
                'used': limits.get('utilizedAmount', 0),
                'total': limits.get('net', 0),
                'message': 'Balance fetched successfully'
            }
        except Exception as e:
            return {'error': str(e)}

    def get_holdings(self) -> Dict[str, Any]:
        """Get holdings from Dhan."""
        try:
            if not self._ensure_authenticated():
                return {'error': 'Authentication failed'}
            
            if not self._dhan_client:
                return {'error': 'Dhan client not initialized'}
            
            holdings = self._dhan_client.get_holdings()
            return holdings if holdings else {}
        except Exception as e:
            return {'error': str(e)}

    def get_positions(self) -> Dict[str, Any]:
        """Get positions from Dhan."""
        try:
            if not self._ensure_authenticated():
                return {'error': 'Authentication failed'}
            
            if not self._dhan_client:
                return {'error': 'Dhan client not initialized'}
            
            positions = self._dhan_client.get_positions()
            return positions if positions else {}
        except Exception as e:
            return {'error': str(e)}

    def get_margin_requirement(self, symbol: Any, quantity: int) -> Dict[str, Any]:
        """Get margin requirement from Dhan."""
        try:
            if not self._ensure_authenticated():
                return {'error': 'Authentication failed'}
            
            if not self._dhan_client:
                return {'error': 'Dhan client not initialized'}
            
            # Estimate margin based on current price (assuming 10% margin)
            price_data = self.get_price(symbol)
            if 'error' in price_data:
                return {'error': 'Unable to fetch price for margin calculation'}
            
            ltp = price_data.get('ltp', 0)
            if ltp == 0:
                return {'error': 'Invalid price for margin calculation'}
            
            # Estimate margin requirement (10% of order value)
            margin_required = quantity * ltp * 0.1
            return {
                'margin_required': margin_required,
                'estimated': True,
                'assumptions': '10% margin on order value',
                'ltp': ltp,
                'quantity': quantity
            }
        except Exception as e:
            return {'error': str(e)}

    def get_price(self, symbol: str) -> Dict[str, Any]:
        """Get price from Dhan."""
        try:
            if not self._ensure_authenticated():
                return {'error': 'Authentication failed'}
            
            if not self._dhan_client:
                return {'error': 'Dhan client not initialized'}
            
            securities = {'MCX': [int(symbol)]}
                
            
            quote = self._dhan_client.quote_data(securities)
            return {
                'symbol': symbol,
                'ltp': quote.get('ltp', 0),
                'bid': quote.get('bid', 0),
                'ask': quote.get('ask', 0),
                'message': 'Price fetched successfully'
            }
        except Exception as e:
            return {'error': str(e)}

    def get_quotes(self, symbols: List[str]) -> Dict[str, Dict[str, Any]]:
        """Get quotes for multiple symbols from Dhan."""
        try:
            if not self._ensure_authenticated():
                return {}
            
            if not self._dhan_client:
                return {}
            
            quotes = {}
            for symbol in symbols:
                try:
                    exchange, sym = symbol.split(':', 1)
                    securities = {exchange: [int(sym)]}
                    quote = self._dhan_client.quote_data(securities=securities)
                    quotes[symbol] = {
                        'ltp': quote.get('ltp', 0),
                        'bid': quote.get('bid', 0),
                        'ask': quote.get('ask', 0),
                        'volume': quote.get('volume', 0)
                    }
                except Exception:
                    quotes[symbol] = {'error': 'Failed to fetch'}
            
            return quotes
        except Exception as e:
            return {}

    def subscribe_to_price(self, symbol: str, callback: Callable) -> bool:
        """Subscribe to price updates from Dhan."""
        try:
            if not self._ensure_authenticated():
                return False
            
            self._subscriptions[symbol] = callback
            return True
        except Exception as e:
            print(f"Dhan subscription error: {e}")
            return False

    def unsubscribe_from_price(self, symbol: str) -> bool:
        """Unsubscribe from price updates from Dhan."""
        try:
            if not self._ensure_authenticated():
                return False
            
            if symbol in self._subscriptions:
                del self._subscriptions[symbol]
            return True
        except Exception as e:
            print(f"Dhan unsubscription error: {e}")
            return False

    def get_historical_data(self, symbol: str, resolution: str, date_format: str, period_start: int, period_end: int, cont_flag: str = "1") -> List[List[Any]]:
        """Get historical data from Dhan."""
        try:
            if not self._ensure_authenticated():
                return []
            
            if not self._dhan_client:
                return []
            
            exchange, sym = symbol.split(':', 1)
            securities = {exchange: [sym]}
            data = self._dhan_client.ohlc_data(securities=securities)
            
            return data if data else []
        except Exception as e:
            print(f"Dhan historical data error: {e}")
            return []

    def get_market_status(self) -> Dict[str, Any]:
        """Get NSE market status (no authentication required)."""
        try:
            return nse_market_status.get_market_status()
        except Exception as e:
            print(f"Error fetching market status: {e}")
            return {
                'error': str(e),
                'equity': {'is_open': False, 'message': 'Unable to fetch market status'},
                'derivatives': {'is_open': False, 'message': 'Unable to fetch market status'}
            }

    def get_trading_holidays(self, market_type: str = "CM") -> List[str]:
        """Get NSE trading holidays (no authentication required)."""
        try:
            return nse_market_status.get_holidays(market_type)
        except Exception as e:
            print(f"Error fetching trading holidays: {e}")
            return []

    def get_trading_hours(self, market_type: str = "equity") -> Dict[str, Dict[str, str]]:
        """Get NSE trading hours (no authentication required)."""
        try:
            return nse_market_status.get_trading_hours(market_type)
        except Exception as e:
            print(f"Error fetching trading hours: {e}")
            return {}

    def is_market_open(self, market_type: str = "equity") -> Dict[str, Any]:
        """Check if NSE market is currently open (no authentication required)."""
        try:
            return nse_market_status.is_market_open(market_type)
        except Exception as e:
            print(f"Error checking market open status: {e}")
            return {
                'is_open': False,
                'error': str(e),
                'message': 'Unable to check market status'
            }
