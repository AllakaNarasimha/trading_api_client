"""
Token manager for storing and retrieving authentication tokens locally.
Saves tokens to local files for reuse in subsequent sessions.
Falls back to config.xml if token not found in .tokens folder.
"""

import os
import json
import xml.etree.ElementTree as ET
from typing import Dict, Any, Optional
from pathlib import Path


class TokenManager:
    """Manages authentication tokens with local file persistence."""

    def __init__(self, token_dir: str = ".tokens", config_file: str = "config.xml"):
        """
        Initialize token manager.

        Args:
            token_dir: Directory to store token files
            config_file: Path to config.xml for fallback token retrieval
        """
        self.token_dir = Path(token_dir)
        self.token_dir.mkdir(exist_ok=True)
        self.config_file = Path(config_file)

    def save_token(self, broker_name: str, token_data: Dict[str, Any]) -> bool:
        """
        Save authentication token to local file.

        Args:
            broker_name: Name of the broker (dhan, fyers)
            token_data: Token data to save (must include 'access_token')

        Returns:
            bool: True if successful, False otherwise
        """
        try:
            token_file = self.token_dir / f"{broker_name}_token.json"
            with open(token_file, 'w') as f:
                json.dump(token_data, f, indent=2)
            print(f"[OK] Token saved for {broker_name}: {token_file}")
            return True
        except Exception as e:
            print(f"Error saving token for {broker_name}: {e}")
            return False

    def load_token(self, broker_name: str) -> Optional[Dict[str, Any]]:
        """
        Load authentication token from local file or config.xml.
        Checks .tokens folder first, then falls back to config.xml.

        Args:
            broker_name: Name of the broker (dhan, fyers)

        Returns:
            Dict: Token data if exists, None otherwise
        """
        # First, try to load from .tokens folder
        try:
            token_file = self.token_dir / f"{broker_name}_token.json"
            if token_file.exists():
                with open(token_file, 'r') as f:
                    token_data = json.load(f)
                print(f"[OK] Token loaded for {broker_name} from cache (.tokens folder)")
                return token_data
        except Exception as e:
            print(f"Error loading token from cache for {broker_name}: {e}")
        
        # If not found in .tokens folder, try config.xml
        token_data = self._load_token_from_config(broker_name)
        if token_data:
            print(f"[OK] Token loaded for {broker_name} from config.xml")
            return token_data
        
        return None

    def _load_token_from_config(self, broker_name: str) -> Optional[Dict[str, Any]]:
        """
        Load authentication token from config.xml as fallback.

        Args:
            broker_name: Name of the broker (dhan, fyers)

        Returns:
            Dict: Token data if found in config.xml, None otherwise
        """
        try:
            if not self.config_file.exists():
                return None
            
            tree = ET.parse(str(self.config_file))
            root = tree.getroot()
            
            api_element = root.find(broker_name)
            if api_element is None:
                return None
            
            access_token = api_element.findtext('access_token', '').strip()
            
            # Only return if access_token is not empty
            if access_token:
                token_data = {'access_token': access_token}
                
                # Also extract other useful config if available
                client_id = api_element.findtext('client_id', '').strip()
                app_id = api_element.findtext('app_id', '').strip()
                
                if client_id:
                    token_data['client_id'] = client_id
                if app_id:
                    token_data['app_id'] = app_id
                
                return token_data
        except Exception as e:
            print(f"Error loading token from config.xml for {broker_name}: {e}")
        
        return None

    def delete_token(self, broker_name: str) -> bool:
        """
        Delete saved token for a broker.

        Args:
            broker_name: Name of the broker (dhan, fyers)

        Returns:
            bool: True if successful, False otherwise
        """
        try:
            token_file = self.token_dir / f"{broker_name}_token.json"
            if token_file.exists():
                os.remove(token_file)
                print(f"[OK] Token deleted for {broker_name}")
                return True
        except Exception as e:
            print(f"Error deleting token for {broker_name}: {e}")
        
        return False

    def clear_all_tokens(self) -> bool:
        """
        Delete all saved tokens.

        Returns:
            bool: True if successful, False otherwise
        """
        try:
            for token_file in self.token_dir.glob("*_token.json"):
                os.remove(token_file)
            print("[OK] All tokens cleared")
            return True
        except Exception as e:
            print(f"Error clearing tokens: {e}")
            return False

    def token_exists(self, broker_name: str) -> bool:
        """
        Check if a token exists for a broker.

        Args:
            broker_name: Name of the broker (dhan, fyers)

        Returns:
            bool: True if token file exists, False otherwise
        """
        token_file = self.token_dir / f"{broker_name}_token.json"
        return token_file.exists()
