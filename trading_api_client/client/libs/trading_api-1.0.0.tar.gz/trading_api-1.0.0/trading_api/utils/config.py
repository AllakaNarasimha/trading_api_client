"""
Configuration module for trading API.
Handles configuration settings from XML files.
"""

import xml.etree.ElementTree as ET
from typing import Dict, Any, Optional


class Config:
    """Configuration management class."""

    def __init__(self):
        """Initialize config with default values."""
        self._config_data: Dict[str, Any] = {}

    def load_from_xml(self, xml_file_path: str) -> bool:
        """
        Load configuration from XML file.

        Args:
            xml_file_path: Path to the XML configuration file

        Returns:
            bool: True if loading is successful, False otherwise
        """
        try:
            tree = ET.parse(xml_file_path)
            root = tree.getroot()
            
            # Parse API settings
            self._config_data['dhan'] = self._parse_api_config(root, 'dhan')
            self._config_data['fyers'] = self._parse_api_config(root, 'fyers')
            
            # Parse general settings
            settings = root.find('settings')
            if settings is not None:
                self._config_data['request_timeout'] = int(
                    settings.findtext('request_timeout', '30')
                )
                self._config_data['log_level'] = settings.findtext('log_level', 'INFO')
                self._config_data['log_file'] = settings.findtext('log_file', 'trading_api.log')
                self._config_data['price_update_interval'] = int(
                    settings.findtext('price_update_interval', '1')
                )
                self._config_data['database_url'] = settings.findtext('database_url', '')
            
            return True
        except Exception as e:
            print(f"Error loading XML configuration: {e}")
            return False

    @staticmethod
    def _parse_api_config(root: ET.Element, api_name: str) -> Dict[str, Any]:
        """Parse API configuration from XML element."""
        api_element = root.find(api_name)
        
        if api_name == 'fyers':
            config = {
                'app_id': '',
                'app_secret': '',
                'access_token': '',
                'base_url': '',
                'callback_url': '',
            }
            if api_element is not None:
                config['app_id'] = api_element.findtext('app_id', '')
                config['app_secret'] = api_element.findtext('app_secret', '')
                config['access_token'] = api_element.findtext('access_token', '')
                config['base_url'] = api_element.findtext('base_url', '')
                config['callback_url'] = api_element.findtext('callback_url', 'http://localhost:8000')
        else:
            config = {
                'client_id': '',
                'access_token': '',
                'app_id': '',
                'app_secret': '',
                'base_url': '',
                'callback_url': '',
            }
            if api_element is not None:
                config['client_id'] = api_element.findtext('client_id', '')
                config['access_token'] = api_element.findtext('access_token', '')
                config['app_id'] = api_element.findtext('app_id', '')
                config['app_secret'] = api_element.findtext('app_secret', '')
                config['base_url'] = api_element.findtext('base_url', '')
                config['callback_url'] = api_element.findtext('callback_url', 'http://localhost:8000')
        
        return config

    def get_dhan_config(self) -> Dict[str, Any]:
        """Get Dhan API configuration."""
        return self._config_data.get('dhan', {
            'api_key': '',
            'client_id': '',
            'base_url': '',
        })

    def get_fyers_config(self) -> Dict[str, Any]:
        """Get Fyers API configuration."""
        return self._config_data.get('fyers', {
            'api_key': '',
            'client_id': '',
            'base_url': '',
        })

    def get_api_config(self, api_name: str) -> Dict[str, Any]:
        """
        Get configuration for a specific API.

        Args:
            api_name: Name of the API (dhan, fyers, etc.)

        Returns:
            Dict: API configuration
        """
        return self._config_data.get(api_name, {})

    def get_setting(self, setting_name: str, default: Any = None) -> Any:
        """
        Get a specific setting by name.

        Args:
            setting_name: Name of the setting
            default: Default value if setting not found

        Returns:
            Any: Setting value or default
        """
        return self._config_data.get(setting_name, default)

    def get_all_config(self) -> Dict[str, Any]:
        """Get all configuration settings."""
        return self._config_data.copy()

    def set_config(self, key: str, value: Any) -> None:
        """
        Set a configuration value programmatically.

        Args:
            key: Configuration key
            value: Configuration value
        """
        self._config_data[key] = value
