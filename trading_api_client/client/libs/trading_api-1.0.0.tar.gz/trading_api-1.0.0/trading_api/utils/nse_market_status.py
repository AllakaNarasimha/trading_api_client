"""
NSE Market Status utility - No login required
Provides market status, trading hours, and holiday information from NSE public APIs
"""

import requests
import pandas as pd
from datetime import datetime, time, timedelta
from typing import Dict, List, Optional, Any
import logging

# Setup logging
logger = logging.getLogger(__name__)

# NSE Public API URLs - No authentication required
NSE_HOLIDAY_URL = "https://www.nseindia.com/api/holiday-master?type=trading"
NSE_MARKET_STATUS_URL = "https://www.nseindia.com/api/marketStatus"
NSE_HOLIDAYS_CM_URL = "https://www.nseindia.com/api/holiday-master?type=trading&mkt=CM"
NSE_HOLIDAYS_FO_URL = "https://www.nseindia.com/api/holiday-master?type=trading&mkt=FO"

# Default headers to mimic browser request
DEFAULT_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "Accept": "application/json",
    "Referer": "https://www.nseindia.com"
}

# NSE Market timings (IST)
NSE_MARKET_TIMINGS = {
    "equity": {
        "pre_open": {"start": "09:00", "end": "09:15"},
        "regular": {"start": "09:15", "end": "15:30"},
        "post_close": {"start": "15:40", "end": "16:00"}
    },
    "derivatives": {
        "pre_open": {"start": "08:55", "end": "09:15"},
        "regular": {"start": "09:15", "end": "15:30"},
        "post_close": {"start": "15:35", "end": "16:00"}
    }
}


class NSEMarketStatus:
    """Fetch NSE market status and holiday information without authentication"""
    
    def __init__(self):
        """Initialize NSE Market Status checker"""
        self._holidays_cache: Optional[Dict[str, List[str]]] = None
        self._cache_time: Optional[datetime] = None
        self._cache_duration = timedelta(hours=24)
    
    def get_holidays(self, market_type: str = "CM") -> List[str]:
        """Get NSE trading holidays for a specific market"""
        try:
            if self._holidays_cache and self._is_cache_valid():
                if market_type in self._holidays_cache:
                    return self._holidays_cache[market_type]
            
            holidays = []
            
            if market_type in ["CM", "ALL"]:
                cm_holidays = self._fetch_holidays("CM")
                holidays.extend(cm_holidays)
            
            if market_type in ["FO", "ALL"]:
                fo_holidays = self._fetch_holidays("FO")
                holidays.extend(fo_holidays)
            
            if not self._holidays_cache:
                self._holidays_cache = {}
            self._holidays_cache[market_type] = list(set(holidays))
            self._cache_time = datetime.now()
            
            return sorted(self._holidays_cache[market_type])
        except Exception as e:
            logger.error(f"Error fetching holidays: {e}")
            return self._get_fallback_holidays()
    
    def _fetch_holidays(self, market_type: str) -> List[str]:
        """Fetch holidays from NSE API for specific market"""
        try:
            if market_type == "CM":
                url = NSE_HOLIDAYS_CM_URL
            elif market_type == "FO":
                url = NSE_HOLIDAYS_FO_URL
            else:
                url = NSE_HOLIDAY_URL
            
            response = requests.get(url, headers=DEFAULT_HEADERS, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            holidays = []
            
            for key in ["CM", "FO"]:
                if key in data:
                    for holiday in data[key]:
                        try:
                            holiday_date = holiday.get('tradingDate') or holiday.get('dt')
                            if holiday_date:
                                dt = pd.to_datetime(holiday_date, format='%d-%b-%Y')
                                holidays.append(dt.strftime('%Y-%m-%d'))
                        except Exception as e:
                            logger.debug(f"Error parsing holiday date: {e}")
            
            return holidays
        except Exception as e:
            logger.warning(f"Failed to fetch {market_type} holidays from NSE: {e}")
            return []
    
    def is_holiday(self, date_obj: Optional[datetime] = None, market_type: str = "CM") -> bool:
        """Check if a date is a trading holiday"""
        if date_obj is None:
            date_obj = datetime.now()
        
        date_str = date_obj.strftime('%Y-%m-%d')
        holidays = self.get_holidays(market_type)
        
        return date_str in holidays
    
    def is_market_open(self, market_type: str = "equity", 
                      check_time: Optional[datetime] = None) -> Dict[str, Any]:
        """Check if NSE market is currently open"""
        if check_time is None:
            check_time = datetime.now()
        
        if self.is_holiday(check_time, "CM"):
            return {
                "is_open": False,
                "session": "closed",
                "reason": "holiday",
                "message": "NSE is closed - Today is a trading holiday"
            }
        
        if check_time.weekday() >= 5:
            return {
                "is_open": False,
                "session": "closed",
                "reason": "weekend",
                "message": "NSE is closed - Market closed on weekends"
            }
        
        timings = NSE_MARKET_TIMINGS.get(market_type, NSE_MARKET_TIMINGS["equity"])
        current_time = check_time.time()
        
        result = {
            "market_type": market_type,
            "check_time": check_time.strftime("%H:%M:%S"),
            "date": check_time.strftime("%Y-%m-%d")
        }
        
        if self._is_time_in_range(current_time, timings["pre_open"]):
            result.update({
                "is_open": False,
                "session": "pre_open",
                "market_open_time": timings["regular"]["start"],
                "message": f"Pre-open session active. Market opens at {timings['regular']['start']}"
            })
        elif self._is_time_in_range(current_time, timings["regular"]):
            result.update({
                "is_open": True,
                "session": "regular",
                "market_open_time": timings["regular"]["start"],
                "market_close_time": timings["regular"]["end"],
                "message": f"Market is OPEN - Regular trading session active"
            })
        elif self._is_time_in_range(current_time, timings["post_close"]):
            result.update({
                "is_open": False,
                "session": "post_close",
                "message": f"Post-close session active. Market closed at {timings['regular']['end']}"
            })
        else:
            result.update({
                "is_open": False,
                "session": "closed",
                "market_open_time": timings["regular"]["start"],
                "message": "NSE is closed - Market hours: 09:15-15:30"
            })
        
        return result
    
    def get_market_status(self) -> Dict[str, Any]:
        """Get comprehensive NSE market status"""
        return {
            "equity": self.is_market_open("equity"),
            "derivatives": self.is_market_open("derivatives"),
            "timestamp": datetime.now().isoformat(),
            "timezone": "IST (UTC+5:30)"
        }
    
    def get_trading_hours(self, market_type: str = "equity") -> Dict[str, Dict[str, str]]:
        """Get trading hours for a market type"""
        return NSE_MARKET_TIMINGS.get(market_type, NSE_MARKET_TIMINGS["equity"])
    
    def get_next_trading_day(self, start_date: Optional[datetime] = None) -> datetime:
        """Get next trading day (skip weekends and holidays)"""
        if start_date is None:
            start_date = datetime.now()
        
        next_day = start_date + timedelta(days=1)
        
        while next_day.weekday() >= 5 or self.is_holiday(next_day, "CM"):
            next_day += timedelta(days=1)
        
        return next_day
    
    def get_last_trading_day(self, end_date: Optional[datetime] = None) -> datetime:
        """Get last trading day (skip weekends and holidays)"""
        if end_date is None:
            end_date = datetime.now()
        
        prev_day = end_date - timedelta(days=1)
        
        while prev_day.weekday() >= 5 or self.is_holiday(prev_day, "CM"):
            prev_day -= timedelta(days=1)
        
        return prev_day
    
    def get_trading_days_between(self, start_date: datetime, end_date: datetime) -> List[datetime]:
        """Get list of trading days between two dates"""
        trading_days = []
        current = start_date
        
        while current <= end_date:
            if current.weekday() < 5 and not self.is_holiday(current, "CM"):
                trading_days.append(current)
            current += timedelta(days=1)
        
        return trading_days
    
    @staticmethod
    def _is_time_in_range(check_time: time, time_range: Dict[str, str]) -> bool:
        """Check if time falls within a range"""
        start = datetime.strptime(time_range["start"], "%H:%M").time()
        end = datetime.strptime(time_range["end"], "%H:%M").time()
        return start <= check_time <= end
    
    def _is_cache_valid(self) -> bool:
        """Check if cache is still valid"""
        if self._cache_time is None:
            return False
        return datetime.now() - self._cache_time < self._cache_duration
    
    @staticmethod
    def _get_fallback_holidays() -> List[str]:
        """Return fallback holidays for 2025"""
        return [
            "2025-01-26", "2025-03-08", "2025-03-10", "2025-03-25",
            "2025-03-29", "2025-04-17", "2025-04-21", "2025-05-23",
            "2025-07-17", "2025-08-15", "2025-08-27", "2025-09-16",
            "2025-10-02", "2025-10-22", "2025-11-01", "2025-11-15",
            "2025-12-25"
        ]


# Global instance
_nse_market_status = NSEMarketStatus()


def get_holidays(market_type: str = "CM") -> List[str]:
    """Get NSE trading holidays"""
    return _nse_market_status.get_holidays(market_type)


def is_holiday(date_obj: Optional[datetime] = None, market_type: str = "CM") -> bool:
    """Check if date is a trading holiday"""
    return _nse_market_status.is_holiday(date_obj, market_type)


def is_market_open(market_type: str = "equity") -> Dict[str, Any]:
    """Check if NSE market is currently open"""
    return _nse_market_status.is_market_open(market_type)


def get_market_status() -> Dict[str, Any]:
    """Get comprehensive NSE market status"""
    return _nse_market_status.get_market_status()


def get_trading_hours(market_type: str = "equity") -> Dict[str, Dict[str, str]]:
    """Get trading hours for a market type"""
    return _nse_market_status.get_trading_hours(market_type)


def get_next_trading_day(start_date: Optional[datetime] = None) -> datetime:
    """Get next trading day"""
    return _nse_market_status.get_next_trading_day(start_date)


def get_last_trading_day(end_date: Optional[datetime] = None) -> datetime:
    """Get last trading day"""
    return _nse_market_status.get_last_trading_day(end_date)


def get_trading_days_between(start_date: datetime, end_date: datetime) -> List[datetime]:
    """Get list of trading days between two dates"""
    return _nse_market_status.get_trading_days_between(start_date, end_date)


if __name__ == "__main__":
    print("=" * 60)
    print("NSE Market Status Utility Test")
    print("=" * 60)
    
    print("\n[1] Trading Holidays (CM):")
    holidays = get_holidays("CM")
    print(f"  Total holidays: {len(holidays)}")
    print(f"  First 5: {holidays[:5]}")
    
    print("\n[2] Current Market Status:")
    status = get_market_status()
    print(f"  Equity: {status['equity']}")
    print(f"  Derivatives: {status['derivatives']}")
    
    print("\n[3] Trading Hours (Equity):")
    hours = get_trading_hours("equity")
    for session, times in hours.items():
        print(f"  {session}: {times['start']} - {times['end']}")
    
    print("\n[4] Next Trading Day:")
    next_day = get_next_trading_day()
    print(f"  {next_day.strftime('%Y-%m-%d %A')}")
