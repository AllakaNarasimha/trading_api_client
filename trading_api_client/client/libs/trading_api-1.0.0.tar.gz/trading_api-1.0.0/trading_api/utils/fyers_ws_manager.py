"""
Fyers WebSocket Manager for auto-reconnection and idle timeout monitoring.
"""

import logging
import threading
import time
from datetime import datetime, time as dt_time
from typing import Any, Callable, Dict, Optional, Set, Union

import pytz

from . import nse_market_status

try:
    from fyers_apiv3.FyersWebsocket import data_ws
    from fyers_apiv3.FyersWebsocket.tbt_ws import FyersTbtSocket, SubscriptionModes
    FYERS_AVAILABLE = True
except ImportError:
    FYERS_AVAILABLE = False


# ===============================
# WEBSOCKET CONFIG
# ===============================
IDLE_TIMEOUT = 30          # seconds - websocket idle timeout
CRITICAL_PERIOD_TIMEOUT = 30  # seconds - timeout during critical market open (9:13-9:17)
CHECK_INTERVAL = 5         # seconds - idle check interval
BASE_RETRY_DELAY = 2       # seconds - initial retry delay
MAX_RETRY_DELAY = 60       # seconds - maximum retry delay
IST = pytz.timezone("Asia/Kolkata")


logger = logging.getLogger('FyersAPI')


class FyersWSManager:
    """Manager for Fyers WebSocket connections with auto-reconnect and idle monitoring."""
    
    def __init__(self, access_token: str, log_path: str = "logs/"):
        """Initialize WebSocket manager.
        
        Args:
            access_token: Fyers API access token
            log_path: Path for log files
        """
        self.access_token = access_token
        self.log_path = log_path
        
        # Depth WebSocket (TbtSocket)
        self.depth_ws: Optional[FyersTbtSocket] = None
        self.depth_subscriptions: Dict[str, Callable] = {}
        self.depth_symbols: Set[str] = set()
        self.depth_ws_thread: Optional[threading.Thread] = None
        self.depth_last_message_time = time.time()
        self.depth_retry_delay = BASE_RETRY_DELAY
        self.depth_lock = threading.Lock()
        self.depth_channel = '1'
        self.depth_mode = SubscriptionModes.DEPTH if FYERS_AVAILABLE else None
        
        # Price WebSocket (DataSocket)
        self.price_ws: Optional[data_ws.FyersDataSocket] = None
        self.price_subscriptions: Dict[str, Callable] = {}
        self.price_ws_thread: Optional[threading.Thread] = None
        self.price_last_message_time = time.time()
        self.price_retry_delay = BASE_RETRY_DELAY
        self.price_lock = threading.Lock()
        
        # Watchdog
        self.watchdog_thread: Optional[threading.Thread] = None
        self.watchdog_running = False
    
    
    def get_market_status(self) -> Dict[str, Any]:
        """Get NSE market status (no authentication required)."""
        try:
            return nse_market_status.get_market_status()
        except Exception as e:
            return {
                'error': str(e),
                'equity': {'is_open': False, 'message': 'Unable to fetch market status'},
                'derivatives': {'is_open': False, 'message': 'Unable to fetch market status'}
            }
    
    def is_market_open_time(self) -> bool:
        """Check if current time is within market hours (9:15 AM - 3:30 PM IST)."""
        try:
            market_status = self.get_market_status()
            logger.info(f"Market status: {market_status}")
            if 'error' not in market_status:
                now = datetime.now(IST).time()
                return dt_time(9, 15) <= now <= dt_time(15, 30)
        except Exception as e:
            logger.warning(f"Error checking market hours: {e}")
            return True  # Default to True if check fails
    
    def is_critical_market_period(self) -> bool:
        """Check if current time is within critical market open period (9:13 AM - 9:17 AM IST).
        Only applies on non-holiday trading days.
        """
        try:
            # Check if today is a holiday
            today = datetime.now(IST)
            if nse_market_status.is_holiday(today, "CM"):
                logger.debug(f"Today is a holiday ? Critical period check skipped")
                return False
            
            # Check if current time is in critical period
            now = today.time()
            is_critical = dt_time(9, 13) <= now <= dt_time(9, 17)
            
            if is_critical:
                logger.debug(f"Current time {now.strftime('%H:%M:%S')} is in critical period (9:13-9:17)")
            
            return is_critical
        except Exception as e:
            logger.warning(f"Error checking critical period: {e}")
            return False
    
    def get_effective_timeout(self) -> int:
        """Get the effective idle timeout based on current time period."""
        if self.is_critical_market_period():
            logger.debug(f"Critical market period active ? Using {CRITICAL_PERIOD_TIMEOUT}s timeout")
            return CRITICAL_PERIOD_TIMEOUT
        return IDLE_TIMEOUT


    # ========== Depth WebSocket Methods ==========
    def subscribe_to_depth(self, symbol: str, callback: Callable) -> Union[bool, str]:
        """Subscribe to real-time depth updates."""
        try:
            if not FYERS_AVAILABLE:
                return "fyers-apiv3 library not available"
            
            self.depth_symbols.add(symbol)
            self.depth_subscriptions[symbol] = callback
            
            if not self.depth_ws:
                self._start_depth_ws()
            else:
                # Re-subscribe with updated symbols
                self.depth_ws.subscribe(
                    symbol_tickers=self.depth_symbols,
                    channelNo=self.depth_channel,
                    mode=self.depth_mode
                )
                self.depth_ws.switchChannel(
                    resume_channels={self.depth_channel},
                    pause_channels=set()
                )
            
            self._start_watchdog()
            return True
        except Exception as e:
            logger.error(f"Error subscribing to depth: {e}")
            return f"Error subscribing to depth: {e}"
    
    def unsubscribe_from_depth(self, symbol: str) -> Union[bool, str]:
        """Unsubscribe from depth updates."""
        try:
            self.depth_symbols.discard(symbol)
            self.depth_subscriptions.pop(symbol, None)
            
            if self.depth_ws and self.depth_symbols:
                self.depth_ws.subscribe(
                    symbol_tickers=self.depth_symbols,
                    channelNo=self.depth_channel,
                    mode=self.depth_mode
                )
                self.depth_ws.switchChannel(
                    resume_channels={self.depth_channel},
                    pause_channels=set()
                )
            elif self.depth_ws and not self.depth_symbols:
                self._stop_depth_ws()
            
            return True
        except Exception as e:
            logger.error(f"Error unsubscribing from depth: {e}")
            return f"Error unsubscribing from depth: {e}"
    
    def _start_depth_ws(self) -> None:
        """Start depth WebSocket connection."""
        try:
            self.depth_ws = FyersTbtSocket(
                access_token=self.access_token,
                write_to_file=False,
                log_path=self.log_path,
                on_open=self._on_depth_open,
                on_close=self._on_depth_close,
                on_error=self._on_depth_error,
                on_depth_update=self._on_depth_update,
                on_error_message=self._on_depth_error_message
            )
            self.depth_ws.connect()
            self.depth_ws_thread = threading.Thread(target=self.depth_ws.keep_running)
            self.depth_ws_thread.daemon = True
            self.depth_ws_thread.start()
            logger.info("Depth WebSocket started")
        except Exception as e:
            logger.error(f"Error starting depth WebSocket: {e}")
    
    def _stop_depth_ws(self) -> None:
        """Stop depth WebSocket connection."""
        try:
            if self.depth_ws:
                self.depth_ws.close()
                self.depth_ws = None
            if self.depth_ws_thread:
                self.depth_ws_thread.join(timeout=1)
                self.depth_ws_thread = None
            logger.info("Depth WebSocket stopped")
        except Exception as e:
            logger.error(f"Error stopping depth WebSocket: {e}")
    
    def _restart_depth_ws(self) -> None:
        """Restart depth WebSocket with exponential backoff."""
        with self.depth_lock:
            if not self.is_market_open_time():
                logger.info("Market closed ? Skipping depth WebSocket reconnect")
                return
            
            if not self.depth_symbols:
                logger.info("No depth subscriptions ? Skipping reconnect")
                return
            
            logger.info(f"Reconnecting depth WebSocket in {self.depth_retry_delay}s...")
            self._stop_depth_ws()
            time.sleep(self.depth_retry_delay)
            
            try:
                self._start_depth_ws()
                logger.info("Depth WebSocket reconnected successfully")
                self.depth_retry_delay = min(self.depth_retry_delay * 2, MAX_RETRY_DELAY)
            except Exception as e:
                logger.error(f"Error restarting depth WebSocket: {e}")
                self.depth_retry_delay = min(self.depth_retry_delay * 2, MAX_RETRY_DELAY)
    
    # Depth WebSocket Callbacks
    def _on_depth_open(self) -> None:
        """Callback for depth WebSocket open."""
        logger.info("Depth WebSocket opened")
        self.depth_last_message_time = time.time()
        
        if self.depth_symbols:
            try:
                self.depth_ws.subscribe(
                    symbol_tickers=self.depth_symbols,
                    channelNo=self.depth_channel,
                    mode=self.depth_mode
                )
                self.depth_ws.switchChannel(
                    resume_channels={self.depth_channel},
                    pause_channels=set()
                )
                logger.info(f"Re-subscribed depth symbols: {self.depth_symbols}")
            except Exception as e:
                logger.error(f"Error re-subscribing depth symbols: {e}")
    
    def _on_depth_close(self, message: str) -> None:
        """Callback for depth WebSocket close."""
        logger.info(f"Depth WebSocket closed: {message}")
        self._restart_depth_ws()
    
    def _on_depth_error(self, message: str) -> None:
        """Callback for depth WebSocket error."""
        logger.error(f"Depth WebSocket error: {message}")
        self._restart_depth_ws()
    
    def _on_depth_update(self, ticker: str, message: Dict[str, Any]) -> None:
        """Callback for depth updates."""
        self.depth_last_message_time = time.time()
        self.depth_retry_delay = BASE_RETRY_DELAY  # Reset backoff on success
        
        if ticker in self.depth_subscriptions:
            callback = self.depth_subscriptions[ticker]
            callback(ticker, message)
    
    def _on_depth_error_message(self, message: str) -> None:
        """Callback for depth error messages."""
        logger.error(f"Depth error message: {message}")
    
    # ========== Price WebSocket Methods ==========
    def subscribe_to_price(self, symbol: str, callback: Callable) -> Union[bool, str]:
        """Subscribe to real-time price updates."""
        try:
            if not FYERS_AVAILABLE:
                return "fyers-apiv3 library not available"
            
            self.price_subscriptions[symbol] = callback
            
            if not self.price_ws:
                error = self._start_price_ws()
                if error:
                    return error
            else:
                # Re-subscribe with updated symbols
                symbols_list = list(self.price_subscriptions.keys())
                self.price_ws.subscribe(symbols=symbols_list, data_type="SymbolUpdate")
            
            self._start_watchdog()
            return True
        except Exception as e:
            logger.error(f"Error subscribing to price: {e}")
            return f"Error subscribing to price: {e}"
    
    def unsubscribe_from_price(self, symbol: str) -> Union[bool, str]:
        """Unsubscribe from price updates."""
        try:
            self.price_subscriptions.pop(symbol, None)
            
            if self.price_ws and self.price_subscriptions:
                symbols_list = list(self.price_subscriptions.keys())
                self.price_ws.subscribe(symbols=symbols_list, data_type="SymbolUpdate")
            elif self.price_ws and not self.price_subscriptions:
                self._stop_price_ws()
            
            return True
        except Exception as e:
            logger.error(f"Error unsubscribing from price: {e}")
            return f"Error unsubscribing from price: {e}"
    
    def _start_price_ws(self) -> Optional[str]:
        """Start price WebSocket connection."""
        try:
            self.price_ws = data_ws.FyersDataSocket(
                access_token=self.access_token,
                log_path=self.log_path,
                litemode=False,
                write_to_file=False,
                reconnect=True,
                on_message=self._on_price_message,
                on_error=self._on_price_error,
                on_close=self._on_price_close,
                on_connect=self._on_price_connect
            )
            self.price_ws.connect()
            self.price_ws_thread = threading.Thread(target=self.price_ws.keep_running)
            self.price_ws_thread.daemon = True
            self.price_ws_thread.start()
            logger.info("Price WebSocket started")
            return None
        except Exception as e:
            logger.error(f"Error starting price WebSocket: {e}")
            return f"Error starting price WebSocket: {e}"
    
    def _stop_price_ws(self) -> None:
        """Stop price WebSocket connection."""
        try:
            if self.price_ws:
                self.price_ws.close()
                self.price_ws = None
            if self.price_ws_thread:
                self.price_ws_thread.join(timeout=1)
                self.price_ws_thread = None
            logger.info("Price WebSocket stopped")
        except Exception as e:
            logger.error(f"Error stopping price WebSocket: {e}")
    
    def _restart_price_ws(self) -> None:
        """Restart price WebSocket with exponential backoff."""
        with self.price_lock:
            if not self.is_market_open_time():
                logger.info("Market closed ? Skipping price WebSocket reconnect")
                return
            
            if not self.price_subscriptions:
                logger.info("No price subscriptions ? Skipping reconnect")
                return
            
            logger.info(f"Reconnecting price WebSocket in {self.price_retry_delay}s...")
            self._stop_price_ws()
            time.sleep(self.price_retry_delay)
            
            result = self._start_price_ws()
            if result:
                logger.error(f"Failed to restart price WebSocket: {result}")
                self.price_retry_delay = min(self.price_retry_delay * 2, MAX_RETRY_DELAY)
            else:
                logger.info("Price WebSocket reconnected successfully")
                self.price_retry_delay = BASE_RETRY_DELAY
    
    # Price WebSocket Callbacks
    def _on_price_connect(self) -> None:
        """Callback for price WebSocket connect."""
        logger.info("Price WebSocket connected")
        self.price_last_message_time = time.time()
        
        if self.price_subscriptions:
            try:
                symbols_list = list(self.price_subscriptions.keys())
                self.price_ws.subscribe(symbols=symbols_list, data_type="SymbolUpdate")
                logger.info(f"Re-subscribed price symbols: {symbols_list}")
            except Exception as e:
                logger.error(f"Error re-subscribing price symbols: {e}")
    
    def _on_price_close(self, message: str) -> None:
        """Callback for price WebSocket close."""
        logger.info(f"Price WebSocket closed: {message}")
        self._restart_price_ws()
    
    def _on_price_error(self, message: str) -> None:
        """Callback for price WebSocket error."""
        logger.error(f"Price WebSocket error: {message}")
        self._restart_price_ws()
    
    def _on_price_message(self, message: Dict[str, Any]) -> None:
        """Callback for price WebSocket messages."""
        try:
            self.price_last_message_time = time.time()
            self.price_retry_delay = BASE_RETRY_DELAY  # Reset backoff on success
            logger.info(f"Price message received: {message}")
            symbol = message.get('symbol')
            if symbol and symbol in self.price_subscriptions:
                callback = self.price_subscriptions[symbol]
                callback(symbol, message)
        except Exception as e:
            logger.error(f"Price message error: {e}")
    
    # ========== Watchdog Methods ==========
    def _start_watchdog(self) -> None:
        """Start the WebSocket idle watchdog thread."""
        if not self.watchdog_running:
            self.watchdog_running = True
            self.watchdog_thread = threading.Thread(target=self._idle_watchdog, daemon=True)
            self.watchdog_thread.start()
            logger.info("WebSocket idle watchdog started")
    
    def _idle_watchdog(self) -> None:
        """Monitor WebSocket connections for idle timeout and trigger reconnect."""
        while self.watchdog_running:
            try:
                current_time = time.time()
                effective_timeout = self.get_effective_timeout()
                
                # Check depth WebSocket
                if self.depth_ws and self.depth_symbols:
                    idle_time = current_time - self.depth_last_message_time
                    if idle_time > effective_timeout and self.is_market_open_time():
                        is_critical = self.is_critical_market_period()
                        period_info = "[CRITICAL PERIOD 9:13-9:17]" if is_critical else ""
                        logger.warning(f"{period_info} Depth WebSocket idle for {idle_time:.1f}s (timeout: {effective_timeout}s) ? Restarting")
                        self._restart_depth_ws()
                
                # Check price WebSocket
                if self.price_ws and self.price_subscriptions:
                    idle_time = current_time - self.price_last_message_time
                    if idle_time > effective_timeout and self.is_market_open_time():
                        is_critical = self.is_critical_market_period()
                        period_info = "[CRITICAL PERIOD 9:13-9:17]" if is_critical else ""
                        logger.warning(f"{period_info} Price WebSocket idle for {idle_time:.1f}s (timeout: {effective_timeout}s) ? Restarting")
                        self._restart_price_ws()
                
                time.sleep(CHECK_INTERVAL)
            except Exception as e:
                logger.error(f"Watchdog error: {e}")
                time.sleep(CHECK_INTERVAL)
    
    def stop_watchdog(self) -> None:
        """Stop the WebSocket idle watchdog thread."""
        self.watchdog_running = False
        if self.watchdog_thread:
            self.watchdog_thread.join(timeout=1)
            self.watchdog_thread = None
            logger.info("WebSocket idle watchdog stopped")
    
    def cleanup(self) -> None:
        """Cleanup all WebSocket connections and threads."""
        self.stop_watchdog()
        self._stop_depth_ws()
        self._stop_price_ws()
        logger.info("FyersWSManager cleanup complete")
