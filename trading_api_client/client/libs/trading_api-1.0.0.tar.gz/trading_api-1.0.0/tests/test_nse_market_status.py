"""
Quick test: NSE Market Status Integration
"""

def test_nse_market_status():
    """Test NSE market status functionality"""
    from trading_api.utils import nse_market_status
    from datetime import datetime
    
    print("\n" + "=" * 60)
    print("NSE Market Status Integration Test")
    print("=" * 60)
    
    # Test 1: Get holidays
    print("\n[TEST 1] Get Trading Holidays")
    try:
        holidays = nse_market_status.get_holidays("CM")
        assert isinstance(holidays, list), "Holidays should be a list"
        assert len(holidays) > 0, "Should have at least one holiday"
        print(f"  [PASS] Retrieved {len(holidays)} holidays")
    except Exception as e:
        print(f"  [FAIL] {e}")
        return False
    
    # Test 2: Check holiday
    print("\n[TEST 2] Is Holiday Check")
    try:
        test_date = datetime(2025, 1, 26)  # Republic Day
        is_hol = nse_market_status.is_holiday(test_date, "CM")
        print(f"  [PASS] 2025-01-26 is holiday: {is_hol}")
    except Exception as e:
        print(f"  [FAIL] {e}")
        return False
    
    # Test 3: Market status
    print("\n[TEST 3] Is Market Open Check")
    try:
        status = nse_market_status.is_market_open("equity")
        assert isinstance(status, dict), "Status should be a dict"
        assert 'is_open' in status, "Status should have is_open key"
        assert 'session' in status, "Status should have session key"
        print(f"  [PASS] Market status retrieved")
        print(f"     is_open: {status['is_open']}")
        print(f"     session: {status['session']}")
    except Exception as e:
        print(f"  [FAIL] {e}")
        return False
    
    # Test 4: Trading hours
    print("\n[TEST 4] Get Trading Hours")
    try:
        hours = nse_market_status.get_trading_hours("equity")
        assert isinstance(hours, dict), "Hours should be a dict"
        assert 'regular' in hours, "Should have regular session"
        assert 'start' in hours['regular'], "Should have start time"
        print(f"  [PASS] Trading hours retrieved")
        print(f"     Equity Regular: {hours['regular']['start']} - {hours['regular']['end']}")
    except Exception as e:
        print(f"  [FAIL] {e}")
        return False
    
    # Test 5: Next trading day
    print("\n[TEST 5] Get Next Trading Day")
    try:
        next_day = nse_market_status.get_next_trading_day()
        assert isinstance(next_day, datetime), "Should return datetime"
        print(f"  [PASS] Next trading day is {next_day.strftime('%Y-%m-%d %A')}")
    except Exception as e:
        print(f"  [FAIL] {e}")
        return False
    
    # Test 6: Trading days between
    print("\n[TEST 6] Get Trading Days Between")
    try:
        start = datetime.now()
        end = datetime(2025, 12, 31)
        trading_days = nse_market_status.get_trading_days_between(start, end)
        assert isinstance(trading_days, list), "Should return list"
        assert len(trading_days) > 0, "Should have at least one trading day"
        print(f"  [PASS] Found {len(trading_days)} trading days")
    except Exception as e:
        print(f"  [FAIL] {e}")
        return False
    
    # Test 7: Market status (comprehensive)
    print("\n[TEST 7] Get Comprehensive Market Status")
    try:
        market_status = nse_market_status.get_market_status()
        assert isinstance(market_status, dict), "Should return dict"
        assert 'equity' in market_status, "Should have equity status"
        assert 'derivatives' in market_status, "Should have derivatives status"
        print(f"  [PASS] Market status retrieved")
    except Exception as e:
        print(f"  [FAIL] {e}")
        return False
    
    print("\n" + "=" * 60)
    print("ALL TESTS PASSED - NSE Market Status is Fully Functional!")
    print("=" * 60)
    return True


def test_api_integration():
    """Test that market status methods are accessible via APIs"""
    
    print("\n" + "=" * 60)
    print("API Implementation Integration Test")
    print("=" * 60)
    
    # Test Fyers API - just test the methods exist and are callable
    print("\n[TEST 1] FyersAPI Market Status Methods (via nse_market_status)")
    try:
        from trading_api.implementations.fyers_api import FyersAPI
        
        # Create a minimal FyersAPI instance (don't call authenticate)
        # Just check the methods exist
        methods = ['get_trading_holidays', 'is_market_open', 'get_trading_hours', 'get_market_status']
        
        for method in methods:
            # Check the method exists in the class definition
            assert hasattr(FyersAPI, method), f"FyersAPI should have {method} method"
        
        print(f"  [PASS] FyersAPI has all required market status methods")
        print(f"     - get_trading_holidays")
        print(f"     - is_market_open")
        print(f"     - get_trading_hours")
        print(f"     - get_market_status")
        
    except Exception as e:
        print(f"  [FAIL] {e}")
        return False
    
    # Test that nse_market_status is properly exported
    print("\n[TEST 2] NSE Market Status Module Export")
    try:
        from trading_api.utils import nse_market_status
        
        # Verify all public functions exist
        public_funcs = [
            'get_holidays',
            'is_holiday', 
            'is_market_open',
            'get_market_status',
            'get_trading_hours',
            'get_next_trading_day',
            'get_last_trading_day',
            'get_trading_days_between'
        ]
        
        for func in public_funcs:
            assert hasattr(nse_market_status, func), f"Should have {func}"
        
        print(f"  [PASS] nse_market_status module properly exported with {len(public_funcs)} functions")
        
    except Exception as e:
        print(f"  [FAIL] {e}")
        return False
    
    # Test that methods work without authentication
    print("\n[TEST 3] Methods Work Without Authentication")
    try:
        # Just import and use nse_market_status directly
        from trading_api.utils import nse_market_status
        
        # Call market status methods (these should work without auth)
        holidays = nse_market_status.get_holidays("CM")
        print(f"  [PASS] get_trading_holidays(): {len(holidays)} holidays retrieved")
        
        status = nse_market_status.is_market_open("equity")
        print(f"  [PASS] is_market_open(): Session = {status.get('session')}")
        
        hours = nse_market_status.get_trading_hours("equity")
        print(f"  [PASS] get_trading_hours(): {len(hours)} sessions")
        
        market_status = nse_market_status.get_market_status()
        print(f"  [PASS] get_market_status(): Retrieved market data")
        
    except Exception as e:
        print(f"  [FAIL] {e}")
        return False
    
    print("\n" + "=" * 60)
    print("ALL INTEGRATION TESTS PASSED!")
    print("=" * 60)
    return True


if __name__ == "__main__":
    success = True
    success = test_nse_market_status() and success
    success = test_api_integration() and success
    
    if success:
        print("\n" + "=" * 60)
        print("SUCCESS: NSE Market Status Feature Ready to Use!")
        print("=" * 60)
