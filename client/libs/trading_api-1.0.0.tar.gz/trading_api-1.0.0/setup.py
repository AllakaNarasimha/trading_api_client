"""
Setup configuration for trading_api package.
This enables the package to be installed via pip and used as a library in other projects.
"""

from setuptools import setup, find_packages
from setuptools.command.build_py import build_py
from setuptools.command.develop import develop
from setuptools.command.install import install
from pathlib import Path
import subprocess
import sys

# Read the contents of README file
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8") if (this_directory / "README.md").exists() else ""


def run_update_requirements():
    """Run update_requirements.py as a prebuild event."""
    update_script = this_directory / "update_requirements.py"
    if update_script.exists():
        print("\n" + "=" * 60)
        print("Running prebuild: Updating requirements to latest versions...")
        print("=" * 60)
        try:
            result = subprocess.run(
                [sys.executable, str(update_script)],
                cwd=str(this_directory),
                check=True,
                capture_output=False
            )
            print("=" * 60)
            print("Prebuild completed successfully!")
            print("=" * 60 + "\n")
        except subprocess.CalledProcessError as e:
            print(f"Warning: update_requirements.py failed with error: {e}")
            print("Continuing with build...\n")
    else:
        print(f"Warning: {update_script} not found. Skipping prebuild.")


def read_requirements():
    """Read requirements from requirements.txt file."""
    requirements = []
    requirements_file = this_directory / "requirements.txt"
    if requirements_file.exists():
        with open(requirements_file) as f:
            requirements = [line.strip() for line in f if line.strip() and not line.startswith("#")]
    return requirements


class CustomBuildPy(build_py):
    """Custom build command."""
    def run(self):
        build_py.run(self)


class CustomDevelop(develop):
    """Custom develop command."""
    def run(self):
        develop.run(self)


class CustomInstall(install):
    """Custom install command."""
    def run(self):
        install.run(self)


# Run update_requirements.py to ensure requirements.txt has latest versions
run_update_requirements()

# Read requirements.txt (now with updated versions)
requirements = read_requirements()

setup(
    name="trading-api",
    version="1.0.0",
    author="Your Name",
    author_email="your.email@example.com",
    description="A unified API for multiple trading platforms (Dhan, Fyers)",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/trading_api",
    packages=find_packages(),
    cmdclass={
        'build_py': CustomBuildPy,
        'develop': CustomDevelop,
        'install': CustomInstall,
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Office/Business :: Financial :: Point-Of-Sale",
        "Topic :: Office/Business :: Financial :: Investment",
    ],
    python_requires=">=3.8",
    install_requires=requirements,
    include_package_data=True,
    entry_points={
        "console_scripts": [
            "trading-api=trading_api.main:main",
        ],
    },
    keywords="trading api dhan fyers broker stock market",
    project_urls={
        "Bug Reports": "https://github.com/yourusername/trading_api/issues",
        "Source": "https://github.com/yourusername/trading_api",
        "Documentation": "https://github.com/yourusername/trading_api/wiki",
    },
)
