"""
Configuration module for trading API.
Handles configuration settings from XML files.
"""

import os
import xml.etree.ElementTree as ET
import logging
from typing import Dict, Any


class Config:
    """Configuration management class."""

    def __init__(self):
        """Initialize config with default values."""
        try:
            config_dir_file = 'config.dir'
            with open(config_dir_file, 'r') as f:
                config_dir = f.read().strip()
            config_file = os.path.join(config_dir, 'config.xml')
        except FileNotFoundError:
            # Default to config.xml in the same directory as this script
            config_file = 'config.xml'
        except Exception as e:
            print(f"Error reading config.dir: {e}")
            config_file = 'config.xml'

        self._config_file = config_file
        self._config_data: Dict[str, Any] = {}

    def load_from_xml(self) -> bool:
        """
        Load configuration from XML file.

                Returns:
            bool: True if loading is successful, False otherwise
        """
        try:
            print(f"Loading configuration from: {self._config_file}")
            tree = ET.parse(self._config_file)
            root = tree.getroot()
            
            # Parse API settings
            self._config_data['dhan'] = self._parse_api_config(root, 'dhan')
            self._config_data['fyers'] = self._parse_api_config(root, 'fyers')
            
            # Parse general settings
            settings = root.find('settings')
            if settings is not None:
                self._config_data['request_timeout'] = int(
                    settings.findtext('request_timeout', '30')
                )
                self._config_data['log_level'] = settings.findtext('log_level', 'INFO')
                self._config_data['log_file'] = settings.findtext('log_file', 'trading_api.log')
                self._config_data['price_update_interval'] = int(
                    settings.findtext('price_update_interval', '1')
                )
                self._config_data['database_url'] = settings.findtext('database_url', '')
            
            # Parse retry configuration
            retry = root.find('retry')
            if retry is not None:
                self._config_data['cutoff_time'] = retry.findtext('cutoff_time', '15:40')
                self._config_data['market_open_time'] = retry.findtext('market_open_time', '09:15')
                self._config_data['market_close_time'] = retry.findtext('market_close_time', '15:30')
                self._config_data['initial_retry_count'] = int(
                    retry.findtext('initial_retry_count', '3')
                )
                self._config_data['persistent_retry_interval'] = int(
                    retry.findtext('persistent_retry_interval', '1')
                )
            else:
                # Set defaults if retry section doesn't exist
                self._config_data['cutoff_time'] = '15:40'
                self._config_data['market_open_time'] = '09:15'
                self._config_data['market_close_time'] = '15:30'
                self._config_data['initial_retry_count'] = 3
                self._config_data['persistent_retry_interval'] = 1
            
            return True
        except Exception as e:
            print(f"Error loading XML configuration: {e}")
            return False

    @staticmethod
    def _parse_api_config(root: ET.Element, api_name: str) -> Dict[str, Any]:
        """Parse API configuration from XML element."""
        api_element = root.find(api_name)
        
        if api_name == 'fyers':
            config = {
                'app_id': '',
                'app_secret': '',
                'access_token': '',
                'refresh_token': '',
                'base_url': '',
                'callback_url': '',
            }
            if api_element is not None:
                config['app_id'] = api_element.findtext('app_id', '')
                config['app_secret'] = api_element.findtext('app_secret', '')
                config['access_token'] = api_element.findtext('access_token', '')
                config['refresh_token'] = api_element.findtext('refresh_token', '')
                config['base_url'] = api_element.findtext('base_url', '')
                config['callback_url'] = api_element.findtext('callback_url', 'http://localhost:8000')
        else:
            config = {
                'client_id': '',
                'access_token': '',
                'refresh_token': '',
                'app_id': '',
                'app_secret': '',
                'base_url': '',
                'callback_url': '',
            }
            if api_element is not None:
                config['client_id'] = api_element.findtext('client_id', '')
                config['access_token'] = api_element.findtext('access_token', '')
                config['app_id'] = api_element.findtext('app_id', '')
                config['app_secret'] = api_element.findtext('app_secret', '')
                config['base_url'] = api_element.findtext('base_url', '')
                config['callback_url'] = api_element.findtext('callback_url', 'http://localhost:8000')
        
        return config

    def get_dhan_config(self) -> Dict[str, Any]:
        """Get Dhan API configuration."""
        return self._config_data.get('dhan', {
            'api_key': '',
            'client_id': '',
            'base_url': '',
        })

    def get_fyers_config(self) -> Dict[str, Any]:
        """Get Fyers API configuration."""
        return self._config_data.get('fyers', {
            'api_key': '',
            'client_id': '',
            'base_url': '',
        })

    def get_api_config(self, api_name: str) -> Dict[str, Any]:
        """
        Get configuration for a specific API.

        Args:
            api_name: Name of the API (dhan, fyers, etc.)

        Returns:
            Dict: API configuration
        """
        return self._config_data.get(api_name, {})

    def get_setting(self, setting_name: str, default: Any = None) -> Any:
        """
        Get a specific setting by name.

        Args:
            setting_name: Name of the setting
            default: Default value if setting not found

        Returns:
            Any: Setting value or default
        """
        return self._config_data.get(setting_name, default)

    def get_all_config(self) -> Dict[str, Any]:
        """Get all configuration settings."""
        return self._config_data.copy()

    @staticmethod
    def parse_time(time_str: str) -> tuple:
        """
        Parse time string in HH:MM format to (hour, minute) tuple.
        
        Args:
            time_str: Time string in HH:MM format (e.g., '15:30')
            
        Returns:
            tuple: (hour, minute)
        """
        try:
            parts = time_str.split(':')
            if len(parts) == 2:
                return (int(parts[0]), int(parts[1]))
        except (ValueError, AttributeError):
            pass
        return (15, 30)  # Default to 15:30

    def set_config(self, key: str, value: Any) -> None:
        """
        Set a configuration value programmatically.

        Args:
            key: Configuration key
            value: Configuration value
        """
        self._config_data[key] = value

    def get_logging_settings(self) -> Dict[str, Any]:
        """
        Get logging configuration settings.
        
        Returns:
            Dict with logging settings (level, format, max_bytes, backup_count, date_format)
        """
        # Get log level from config or default to DEBUG
        log_level_str = self.get_setting('log_level', 'DEBUG')
        log_level_map = {
            'DEBUG': logging.DEBUG,
            'INFO': logging.INFO,
            'WARNING': logging.WARNING,
            'ERROR': logging.ERROR,
            'CRITICAL': logging.CRITICAL
        }
        log_level = log_level_map.get(log_level_str.upper(), logging.DEBUG)
        
        return {
            'level': log_level,
            'format': '%(asctime)s - %(name)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s',
            'date_format': '%Y-%m-%d %H:%M:%S',
            'max_bytes': 10 * 1024 * 1024,  # 10MB
            'backup_count': 5
        }

    def get_log_file_path(self, name: str = "app") -> str:
        """
        Get log file path for a logger.
        
        Args:
            name: Logger name
            
        Returns:
            str: Full path to log file
        """
        logs_dir = os.path.join(os.getcwd(), 'logs')
        os.makedirs(logs_dir, exist_ok=True)
        return os.path.join(logs_dir, f'{name}.log')
