import pandas as pd
from typing import Optional, Dict, Any


class InstrumentExpiryFetcher:
    """Utility class to fetch instrument records by expiry index from NSE FO data."""
    
    def __init__(self, data):
        """Initialize with DataFrame or array-like data."""
        self.expiry_start_date = 7
        self.expiry_date = 8
        self.strike_price = 15
        self.option = 16
        self.symbol = 9
        self.symbol_info = 1
        self.spot = 13

        if isinstance(data, pd.DataFrame):
            self.df = data.copy()
            self.df['expiry_start_date'] = pd.to_datetime(self.df[self.expiry_start_date])
            self.df['expiry_date'] = pd.to_datetime(self.df[self.expiry_date])
            self.df['strike_price'] = self.df[self.strike_price].astype(float)
            self.df['option'] = self.df[self.option].astype(str)
            self.df['symbol'] = self.df[self.symbol].astype(str)
            self.df['spot'] = self.df[self.spot].astype(str)
        else:
            # Convert array or array-like to DataFrame
            self.df = pd.DataFrame(data)
        
    
    def get_futures_by_expiry_index(self, spot_name: str, expiry_index: int) -> Optional[Dict[str, Any]]:
        """
        Get futures record by expiry index.
        
        Args:
            spot_name: Name of the underlying spot (e.g., 'NIFTY')
            expiry_index: 0 for current expiry, 1 for next, etc.
        
        Returns:
            Dict with instrument data or None if not found
        """
        # Filter for futures of the spot
        futures = self.df[
            (self.df['spot'] == spot_name) & 
            (self.df['symbol'].str.contains('FUT'))
        ].copy()
        
        # Sort by expiry date
        futures = futures.sort_values('expiry_date')
        
        if expiry_index < len(futures):
            record = futures.iloc[expiry_index]
            return record.to_dict()
        
        return None
    
    def get_options_by_expiry_index(self, spot_name: str, expiry_index: int, 
                                   option_type: str, strike_price: Optional[float] = None) -> Optional[Dict[str, Any]]:
        """
        Get options record by expiry index.
        
        Args:
            spot_name: Name of the underlying spot (e.g., 'NIFTY')
            expiry_index: 0 for current expiry, 1 for next, etc.
            option_type: 'CE' for call, 'PE' for put
            strike_price: Specific strike price, if None returns first available
        
        Returns:
            Dict with instrument data or None if not found
        """
        # Filter for options of the spot and type
        options = self.df[
            (self.df['spot'] == spot_name) & 
            (self.df['symbol'].str.contains(option_type))
        ].copy()
        
        # Group by expiry and get unique expiries
        unique_expiries = options['expiry_date'].drop_duplicates().sort_values()
        
        if expiry_index >= len(unique_expiries):
            return None
        
        target_expiry = unique_expiries.iloc[expiry_index]
        
        # Filter for the target expiry
        expiry_options = options[options['expiry_date'] == target_expiry]
        
        if strike_price is not None:
            # Find exact strike
            strike_options = expiry_options[expiry_options['symbol'].str.contains(f'{int(strike_price)}{option_type}')]
            if not strike_options.empty:
                return strike_options.iloc[0].to_dict()
        else:
            # Return first available for this expiry
            if not expiry_options.empty:
                return expiry_options.iloc[0].to_dict()
        
        return None
    
    def get_instrument_by_expiry_index(self, spot_name: str, expiry_index: int, 
                                      instrument_type: str = 'FUT', 
                                      option_type: Optional[str] = None, 
                                      strike_price: Optional[float] = None) -> Optional[Dict[str, Any]]:
        """
        Get instrument record by expiry index.
        
        Args:
            spot_name: Name of the underlying spot (e.g., 'NIFTY')
            expiry_index: 0 for current expiry, 1 for next, etc.
            instrument_type: 'FUT' for futures, 'OPT' for options
            option_type: 'CE' or 'PE' if instrument_type is 'OPT'
            strike_price: Strike price for options
        
        Returns:
            Dict with instrument data or None if not found
        """
        if instrument_type == 'FUT':
            return self.get_futures_by_expiry_index(spot_name, expiry_index)
        elif instrument_type == 'OPT' and option_type:
            return self.get_options_by_expiry_index(spot_name, expiry_index, option_type, strike_price)
        else:
            return None