import os
import requests
import pandas as pd
from datetime import datetime

class DhanMaster:
    """
    Utility to download, cache, and query the Dhan scrip master file.
    """

    BASE_URL = "https://images.dhan.co/api-data/api-scrip-master.csv"

    def __init__(self, base_url = BASE_URL, data_dir: str = "dhan_master"):
        self.base_url = base_url
        self.data_dir = data_dir
        os.makedirs(self.data_dir, exist_ok=True)
        self._cache = {}  # {date_str: DataFrame}

    def _file_path(self, date: str) -> str:
        """Return file path for a given date (YYYY-MM-DD)."""
        return os.path.join(self.data_dir, f"master_{date}.csv")

    def _download(self, date: str) -> str:
        """Download the master CSV for given date if not already saved."""
        file_path = self._file_path(date)
        if not os.path.exists(file_path):
            print(f"Downloading master file for {date}...")
            response = requests.get(self.BASE_URL)
            response.raise_for_status()
            with open(file_path, "wb") as f:
                f.write(response.content)
        return file_path

    def _load(self, date: str) -> pd.DataFrame:
        """Load master CSV into cache (if not already cached)."""
        if date not in self._cache:
            file_path = self._download(date)
            df = pd.read_csv(file_path)
            self._cache[date] = df
        return self._cache[date]

    def get_record(self, filters: dict, date: str | None = None) -> dict | None:
        """
        Fetch the full record as a dictionary for given filter conditions.

        Args:
            filters (dict): {column_name: value} to filter on
            date (str, optional): Date in YYYY-MM-DD. Defaults to today.

        Returns:
            dict | None: Full record as {column: value}, or None if not found
        """
        if date is None:
            date = datetime.today().strftime("%Y-%m-%d")

        df = self._load(date)

        filtered = df.copy()
        for col, val in filters.items():
            if col not in df.columns:
                raise ValueError(f"Column '{col}' not found in master file")
            filtered = filtered[filtered[col].astype(str).str.upper() == str(val).upper()]

        if not filtered.empty:
            return filtered.iloc[0].to_dict()
        return None

    def refresh(self, date: str | None = None):
        """
        Force refresh/reload for a given date (default: today).
        """
        if date is None:
            date = datetime.today().strftime("%Y-%m-%d")
        file_path = self._download(date)
        df = pd.read_csv(file_path)
        self._cache[date] = df


# Example usage
if __name__ == "__main__":
    master = DhanMaster()

    # Example: filter by trading symbol + series
    record = master.get_record({"SEM_TRADING_SYMBOL": "RELIANCE", "SEM_SERIES": "EQ"})
    print(record)

    # Example: filter by ISIN
    record = master.get_record({"SEM_ISIN": "INE002A01018"})
    print(record)
