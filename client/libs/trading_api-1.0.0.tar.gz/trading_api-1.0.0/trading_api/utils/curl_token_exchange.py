"""
Curl-based token exchange utility for Fyers API.
"""

import subprocess
import json
import hashlib
from typing import Optional


def exchange_auth_code_with_curl(auth_code: str, app_id: str, app_secret: str, use_hash: bool = True) -> Optional[str]:
    """
    Exchange authorization code for access token using curl command.

    Args:
        auth_code: Authorization code from OAuth callback
        app_id: Fyers app ID
        app_secret: Fyers app secret
        use_hash: Whether to SHA-256 hash the "app_id:app_secret" combination for appIdHash

    Returns:
        Access token string if successful, None otherwise
    """
    try:
        if use_hash:
            # Fyers API requires SHA-256 hash of "app_id:app_secret"
            hash_input = f"{app_id}:{app_secret}"
            app_id_hash = hashlib.sha256(hash_input.encode()).hexdigest()
            print(f"[DEBUG] Using SHA-256 hash of 'app_id:app_secret': {app_id_hash}")
        else:
            app_id_hash = app_id
            print(f"[DEBUG] Using app_id as-is: {app_id_hash}")

        # Curl command for token generation
        curl_command = [
            "curl", 
            "--location",
            "--request", "POST",
            "https://api-t1.fyers.in/api/v3/validate-authcode",  # Correct endpoint for token generation
            "--header", "Content-Type: application/json",
            "--ssl-no-revoke",  # Bypass SSL revocation check on Windows
            "--data-raw", json.dumps({
                "grant_type": "authorization_code",
                "appIdHash": app_id_hash,
                "code": auth_code
            })
        ]

        print(f"[INFO] Exchanging auth code for access token...")
        print(f"[DEBUG] Using app_id: {app_id}")

        # Run curl command
        result = subprocess.run(
            curl_command,
            capture_output=True,
            text=True,
            timeout=60
        )

        if result.returncode != 0:
            print(f"[FAIL] Curl command failed with exit code {result.returncode}")
            print(f"[DEBUG] Error: {result.stderr}")
            return None

        print(f"[DEBUG] Raw response: {result.stdout}")
        print(f"[DEBUG] Raw stderr: {result.stderr}")

        # Parse JSON response
        try:
            response_data = json.loads(result.stdout)
            if 'access_token' in response_data:
                access_token = response_data['access_token']
                print(f"[OK] Access token obtained: {access_token[:20]}...")
                return access_token
            else:
                print(f"[FAIL] No access_token in response: {response_data}")
                return None
        except json.JSONDecodeError:
            # Check if it's an HTML error page
            if '<html>' in result.stdout.lower():
                print(f"[FAIL] Server returned HTML error page (likely 503 or maintenance): {result.stdout.strip()}")
            else:
                print(f"[FAIL] Failed to parse JSON response: {result.stdout}")
            return None

    except subprocess.TimeoutExpired:
        print("[FAIL] Request timed out")
        return None
    except Exception as e:
        print(f"[FAIL] Token exchange error: {e}")
        return None


def test_token_exchange(auth_code: str, app_id: str, app_secret: str) -> Optional[str]:
    """
    Test token exchange with both appIdHash formats.
    Primary: SHA-256 hash of "app_id:app_secret" (Fyers API standard)
    Fallback: app_id as-is

    Args:
        auth_code: Authorization code from OAuth callback
        app_id: Fyers app ID
        app_secret: Fyers app secret

    Returns:
        Access token if successful, None otherwise
    """
    print("Testing with SHA-256 hash of 'app_id:app_secret' (Fyers API standard):")
    token1 = exchange_auth_code_with_curl(auth_code, app_id, app_secret, use_hash=True)

    if token1:
        return token1

    print("\nTesting with app_id as-is (fallback):")
    token2 = exchange_auth_code_with_curl(auth_code, app_id, app_secret, use_hash=False)

    return token2


if __name__ == "__main__":
    # Simple test
    print("Testing curl token exchange utility...")
    print("Fyers API appIdHash = SHA-256('app_id:app_secret')")
    print("Example: SHA-256('VBYFHBIOSI-100:28J3QQV0AV')")
    import hashlib
    example_hash = hashlib.sha256("VBYFHBIOSI-100:28J3QQV0AV".encode()).hexdigest()
    print(f"Result: {example_hash}")
    print()
    
    result = exchange_auth_code_with_curl("test_auth_code", "VBYFHBIOSI-100", "28J3QQV0AV")
    print(f"Test completed. Result: {result}")