"""
Fyers WebSocket Manager for auto-reconnection and idle timeout monitoring.
"""

import threading
import time
import json
from datetime import datetime, time as dt_time, timezone, timedelta
from typing import Any, Callable, Dict, List, Optional, Set, Union

from .logger_manager import LoggerManager

from . import nse_market_status
from .config import Config
from .retry_manager import (
    should_continue_retry_until_cutoff
)

try:
    from fyers_apiv3.FyersWebsocket import data_ws
    from fyers_apiv3.FyersWebsocket.tbt_ws import FyersTbtSocket, SubscriptionModes
    FYERS_AVAILABLE = True
except ImportError:
    FYERS_AVAILABLE = False

logger = LoggerManager.setup_logging("fyers_ws_manager")

# ===============================
# WEBSOCKET CONFIG
# ===============================               # seconds - maximum retry delay
IST = timezone(timedelta(hours=5, minutes=30))


class FyersWSManager:
    """Manager for Fyers WebSocket connections with auto-reconnect and idle monitoring."""
    
    def __init__(self, access_token: str, log_path: str = "logs/", refresh_callback: Optional[Callable[[], Optional[str]]] = None):
        """Initialize WebSocket manager.
        
        Args:
            access_token: Fyers API access token
            log_path: Path for log files
            refresh_callback: Optional callback to refresh access token, should return new token or None
        """
        self.access_token = access_token
        self.log_path = log_path
        self.refresh_callback = refresh_callback
        
        # Load all configurations
        self._load_config()
        
        self.invalid_symbols: Set[str] = set()
        # Depth WebSocket (TbtSocket)
        self.depth_ws: Optional[FyersTbtSocket] = None
        self.depth_subscriptions: Dict[str, Callable] = {}
        self.depth_symbols: Set[str] = set()
        self.depth_ws_thread: Optional[threading.Thread] = None
        self.depth_last_message_time = time.time()
        self.depth_retry_delay = self.base_retry_delay
        self.depth_lock = threading.Lock()
        self.depth_reconnecting = False
        self.depth_channel = '1'
        self.depth_mode = SubscriptionModes.DEPTH if FYERS_AVAILABLE else None
        
        # Price WebSocket (DataSocket)
        self.price_ws: Optional[data_ws.FyersDataSocket] = None
        self.price_subscriptions: Dict[str, Callable] = {}
        self.price_ws_thread: Optional[threading.Thread] = None
        self.price_last_message_time = time.time()
        self.price_retry_delay = self.base_retry_delay
        self.price_lock = threading.Lock()
        self.price_reconnecting = False  
        self.invalid_symbols = set()        
        # Watchdog
        self.watchdog_thread: Optional[threading.Thread] = None
        self.watchdog_running = False
    
    def _load_config(self):
        """Load all configuration settings from config.xml."""
        config = Config()
        config.load_from_xml()
        
        # Load market timing
        market_open_hour, market_open_minute = Config.parse_time(
            config.get_setting('market_open_time', '09:15')
        )
        market_close_hour, market_close_minute = Config.parse_time(
            config.get_setting('market_close_time', '15:30')
        )
        cutoff_hour, cutoff_minute = Config.parse_time(
            config.get_setting('cutoff_time', '15:40')
        )
        self.market_open_time = dt_time(market_open_hour, market_open_minute)
        self.market_close_time = dt_time(market_close_hour, market_close_minute)
        self.cutoff_time = dt_time(cutoff_hour, cutoff_minute)
        
        # Load retry configurations
        self.web_socket_idle_timeout = int(config.get_setting('web_socket_idle_timeout', '30'))
        self.critical_period_timeout = int(config.get_setting('critical_period_timeout', '30'))
        self.message_timeout = int(config.get_setting('message_timeout', '120'))
        self.check_interval = int(config.get_setting('check_interval', '5'))
        self.base_retry_delay = int(config.get_setting('base_retry_delay', '2'))
        self.max_retry_delay = int(config.get_setting('max_retry_delay', '60'))
        self.persistent_retry_interval = int(config.get_setting('persistent_retry_interval', '1'))
        self.initial_retry_delays = [int(x.strip()) for x in config.get_setting('initial_retry_delays', '1,2,4').split(',')]
        self.test_mode = config.get_setting('test_mode', 'false').lower() == 'true'
        self.offline_market_idle_time = int(config.get_setting('offline_market_idle_time', '30'))
        logger.info("Configuration loaded successfully, test_mode=%s", self.test_mode)
    
    def refresh_access_token(self) -> bool:
        """Refresh access token using callback if available."""
        if self.refresh_callback:
            new_token = self.refresh_callback()
            if new_token:
                logger.info("Access token refreshed successfully")
                self.access_token = new_token
                return True
            else:
                logger.warning("Failed to refresh access token")
                return False
        return False
    
    
    def get_market_status(self) -> Dict[str, Any]:
        """Get NSE market status (no authentication required)."""
        try:
            return nse_market_status.get_market_status()
        except Exception as e:
            return {
                'error': str(e),
                'equity': {'is_open': False, 'message': 'Unable to fetch market status'},
                'derivatives': {'is_open': False, 'message': 'Unable to fetch market status'}
            }
    
    def is_market_open_time(self) -> bool:
        """Check if current time is within market hours (including cutoff time for retries)."""
        try:
            if self.test_mode == True:
                logger.info("Test mode active ? Bypassing market hours check")
                return True
            market_status = self.get_market_status()
            logger.info(f"Market status: {market_status}")
            if 'error' not in market_status:
                equity = market_status['equity']
                if equity.get('is_open', False):
                    logger.info("Market is open according to NSE status")
                    return True
                else:
                    logger.info("Market is closed according to NSE status")
                    return False                
                now = datetime.now(IST).time()
                return self.market_open_time <= now <= self.cutoff_time
        except Exception as e:
            logger.warning(f"Error checking market hours: {e}")
            return True  # Default to True if check fails
    
    def is_critical_market_period(self) -> bool:
        """Check if current time is within critical market open period (9:13 AM - 9:17 AM IST).
        Only applies on non-holiday trading days.
        """
        try:
            # Check if today is a holiday
            today = datetime.now(IST)
            if nse_market_status.is_holiday(today, "CM"):
                logger.debug(f"Today is a holiday ? Critical period check skipped")
                return False
            
            # Check if current time is in critical period
            now = today.time()
            is_critical = dt_time(9, 13) <= now <= dt_time(9, 17)
            
            if is_critical:
                logger.debug(f"Current time {now.strftime('%H:%M:%S')} is in critical period (9:13-9:17)")
            
            return is_critical
        except Exception as e:
            logger.warning(f"Error checking critical period: {e}")
            return False
    
    def get_effective_timeout(self) -> int:
        """Get the effective idle timeout based on current time period."""
        if self.is_critical_market_period():
            logger.debug(f"Critical market period active ? Using {self.critical_period_timeout}s timeout")
            return self.critical_period_timeout
        return self.web_socket_idle_timeout

    def should_continue_retrying(self) -> bool:
        """Check if retry should continue based on cutoff time and market open status."""
        if self.test_mode == True:
            logger.info("Test mode active ? Bypassing should_continue_retrying")
            return True
        return should_continue_retry_until_cutoff() and self.is_market_open_time()

    def get_price_valid_symbols(self) -> List[str]:
        """Get list of valid price symbols (not in invalid_symbols set)."""
        return [sym for sym in self.price_subscriptions.keys() if sym not in self.invalid_symbols]
    
    def get_depth_valid_symbols(self) -> List[str]:
        """Get list of valid depth symbols (not in invalid_symbols set)."""
        return [sym for sym in self.depth_symbols if sym not in self.invalid_symbols]


    # ========== Depth WebSocket Methods ==========
    def subscribe_to_depth(self, symbol: str, callback: Callable) -> Union[bool, str]:
        """Subscribe to real-time depth updates."""
        try:
            if not FYERS_AVAILABLE:
                return "fyers-apiv3 library not available"
            
            self.depth_symbols.add(symbol)
            self.depth_subscriptions[symbol] = callback
            
            if not self.depth_ws:
                self._start_depth_ws()
            else:
                # Re-subscribe with updated symbols
                valid_symbols = self.get_depth_valid_symbols()
                self.depth_ws.subscribe(
                    symbol_tickers=valid_symbols,
                    channelNo=self.depth_channel,
                    mode=self.depth_mode
                )
                self.depth_ws.switchChannel(
                    resume_channels={self.depth_channel},
                    pause_channels=set()
                )
            
            self._start_watchdog()
            return True
        except Exception as e:
            logger.error(f"Error subscribing to depth: {e}")
            return f"Error subscribing to depth: {e}"
    
    def unsubscribe_from_depth(self, symbol: str) -> Union[bool, str]:
        """Unsubscribe from depth updates."""
        try:
            self.depth_symbols.discard(symbol)
            self.depth_subscriptions.pop(symbol, None)
            
            if self.depth_ws and self.depth_symbols:
                valid_symbols = self.get_depth_valid_symbols()
                self.depth_ws.subscribe(
                    symbol_tickers=valid_symbols,
                    channelNo=self.depth_channel,
                    mode=self.depth_mode
                )
                self.depth_ws.switchChannel(
                    resume_channels={self.depth_channel},
                    pause_channels=set()
                )
            elif self.depth_ws and not self.depth_symbols:
                self._stop_depth_ws()
            
            return True
        except Exception as e:
            logger.error(f"Error unsubscribing from depth: {e}")
            return f"Error unsubscribing from depth: {e}"
    
    def _start_depth_ws(self) -> None:
        """Start depth WebSocket connection."""
        try:
            if not self.depth_ws:
                self.depth_ws = FyersTbtSocket(
                    access_token=self.access_token,
                    write_to_file=False,
                    log_path=self.log_path,
                    on_open=self._on_depth_open,
                    on_close=self._on_depth_close,
                    on_error=self._on_depth_error,
                    on_depth_update=self._on_depth_update,
                    on_error_message=self._on_depth_error_message
                )
            self.depth_ws.connect()
            self.depth_ws_thread = threading.Thread(target=self.depth_ws.keep_running)
            self.depth_ws_thread.daemon = True
            self.depth_ws_thread.start()
            logger.info("[DEPTH_START] Depth WebSocket started successfully")
        except Exception as e:
            logger.error(f"[DEPTH_START_ERROR] Error starting depth WebSocket: {e}", exc_info=True)
            # Clean up on failure
            try:
                if self.depth_ws:
                    self.depth_ws = None
                if self.depth_ws_thread:
                    self.depth_ws_thread = None
            except:
                pass
            raise
    
    def _stop_depth_ws(self) -> None:
        """Stop depth WebSocket connection."""
        try:
            if self.depth_ws:
                try:
                    if hasattr(self.depth_ws, 'close'):
                        self.depth_ws.close()
                except Exception as e:
                    logger.warning(f"[DEPTH_CLOSE_ERROR] Error closing depth WebSocket: {e}")
                finally:
                    self.depth_ws = None
            
            if self.depth_ws_thread:
                try:
                    self.depth_ws_thread.join(timeout=1)
                except Exception as e:
                    logger.warning(f"[DEPTH_THREAD_ERROR] Error joining depth thread: {e}")
                finally:
                    self.depth_ws_thread = None
            
            logger.info("[DEPTH_STOP] Depth WebSocket stopped")
        except Exception as e:
            logger.error(f"[DEPTH_STOP_ERROR] Error stopping depth WebSocket: {e}", exc_info=True)
    
    def _restart_depth_ws(self) -> None:
        """Restart depth WebSocket with persistent retry until 3:40 PM."""
        # Only lock to check if restart is needed and mark as in-progress
        with self.depth_lock:
            if not self.is_market_open_time():
                logger.info("Market closed - Skipping depth WebSocket reconnect")
                return
            
            if not self.get_depth_valid_symbols():
                logger.info("No valid depth subscriptions → Skipping reconnect")
                return
            
            # Check if already reconnecting
            if self.depth_reconnecting:
                logger.info("Depth WebSocket reconnection already in progress")
                return
            
            self.depth_reconnecting = True
        
        # Release lock before starting long-running retry process
        try:
            def _attempt_reconnect() -> Optional[bool]:
                """Attempt to reconnect depth WebSocket."""
                try:
                    if not self.refresh_access_token():
                        logger.warning("Token refresh failed, proceeding with current token")
                    
                    logger.info(f"[DEPTH_RECONNECT] Attempting reconnect (delay: {self.depth_retry_delay}s)...")
                    self._stop_depth_ws()
                    time.sleep(self.depth_retry_delay)
                    
                    try:
                        self._start_depth_ws()
                        logger.info("[DEPTH_RECONNECT] Depth WebSocket reconnected successfully")
                        self.depth_retry_delay = self.base_retry_delay  # Reset backoff on success
                        return True
                    except Exception as e:
                        logger.warning(f"[DEPTH_RECONNECT] Failed to start: {e}")
                        self.depth_retry_delay = min(self.depth_retry_delay * 2, self.max_retry_delay)
                        return None
                except Exception as e:
                    logger.error(f"[DEPTH_RECONNECT] Reconnect attempt error: {e}")
                    return None
            
            # Try initial reconnect attempts (3 times with backoff)
            for attempt in range(3):
                result = _attempt_reconnect()
                if result:
                    return
                if attempt < 2:
                    wait_time = self.initial_retry_delays[attempt] if attempt < len(self.initial_retry_delays) else self.initial_retry_delays[-1]
                    logger.info(f"[DEPTH_RECONNECT] Waiting {wait_time}s before next attempt...")
                    time.sleep(wait_time)
            
            # If initial attempts failed, enter persistent retry until 3:40 PM
            logger.warning("[DEPTH_RECONNECT] Initial attempts exhausted. Entering persistent retry mode until 3:40 PM...")
            persistent_attempt = 0
            
            while self.should_continue_retrying():
                persistent_attempt += 1
                current_time = datetime.now().strftime("%H:%M:%S")
                logger.info(f"[DEPTH_RECONNECT_PERSISTENT] Attempt {persistent_attempt} at {current_time}")
                
                result = _attempt_reconnect()
                if result:
                    logger.info(f"[DEPTH_RECONNECT_PERSISTENT] SUCCESS on attempt {persistent_attempt}")
                    return
                
                # Check again before sleeping
                if self.should_continue_retrying():
                    logger.warning(f"[DEPTH_RECONNECT_PERSISTENT] Attempt {persistent_attempt} failed, retrying in 1s...")
                    time.sleep(1)
                else:
                    break
            
            current_time = datetime.now().strftime("%H:%M:%S")
            logger.error(f"[DEPTH_RECONNECT_PERSISTENT] FAILED at {current_time}. Cutoff (3:40 PM) reached. Total attempts: {3 + persistent_attempt}")
        finally:
            with self.depth_lock:
                self.depth_reconnecting = False
    
    # Depth WebSocket Callbacks
    def _on_depth_open(self) -> None:
        """Callback for depth WebSocket open."""
        try:
            logger.info("Depth WebSocket opened")
            self.depth_last_message_time = time.time()
            
            if self.depth_symbols:
                try:
                    valid_symbols = self.get_depth_valid_symbols()
                    self.depth_ws.subscribe(
                        symbol_tickers=valid_symbols,
                        channelNo=self.depth_channel,
                        mode=self.depth_mode
                    )
                    self.depth_ws.switchChannel(
                        resume_channels={self.depth_channel},
                        pause_channels=set()
                    )
                    logger.info(f"Re-subscribed depth symbols: {valid_symbols}")
                except Exception as e:
                    logger.error(f"[DEPTH_RESUBSCRIBE_ERROR] Error re-subscribing depth symbols: {e}", exc_info=True)
                    # Trigger reconnect on subscription failure
                    self._restart_depth_ws()
        except Exception as e:
            logger.error(f"[DEPTH_OPEN_ERROR] Runtime error in depth open callback: {e}", exc_info=True)
            self._restart_depth_ws()
    
    def _on_depth_close(self, message: str) -> None:
        """Callback for depth WebSocket close."""
        logger.info(f"Depth WebSocket closed: {message}")
        self._restart_depth_ws()
    
    def _on_depth_error(self, message: str) -> None:
        """Callback for depth WebSocket error."""
        try:
            logger.error(f"[DEPTH_WS_ERROR] Depth WebSocket error: {message}")
            
            # Try to parse as JSON for structured errors
            try:
                error_dict = json.loads(message)
                if isinstance(error_dict, dict) and 'invalid_symbols' in error_dict:
                    invalid_symbols = error_dict['invalid_symbols']
                    # Update price_invalid_symbols set with new invalid symbols
                    new_invalids = set(invalid_symbols) - self.invalid_symbols
                    if new_invalids:
                        self.invalid_symbols.update(new_invalids)
                        logger.warning(f"[price_invalid_symbols] Added invalid symbols: {new_invalids}")
            except json.JSONDecodeError:
                pass  # Not a JSON error, continue with pattern matching
            
            # Log common error patterns
            if "getaddrinfo failed" in str(message):
                logger.warning("[DEPTH_DNS_ERROR] DNS resolution failed")
            elif "Connection" in str(message) or "refused" in str(message):
                logger.warning("[DEPTH_CONNECTION_ERROR] Connection issue detected")
            elif "timeout" in str(message).lower():
                logger.warning("[DEPTH_TIMEOUT_ERROR] Timeout detected")
            self._restart_depth_ws()
        except Exception as e:
            logger.error(f"[DEPTH_ERROR_HANDLER_ERROR] Error in error handler: {e}", exc_info=True)
            self._restart_depth_ws()
    
    def _on_depth_update(self, ticker: str, message: Dict[str, Any]) -> None:
        """Callback for depth updates."""
        try:
            self.depth_last_message_time = time.time()
            self.depth_retry_delay = self.base_retry_delay  # Reset backoff on success
            
            if not isinstance(ticker, str) or not ticker:
                logger.warning(f"[DEPTH_INVALID_TICKER] Invalid ticker type or value: {ticker}")
                return
            
            if ticker in self.depth_subscriptions:
                try:
                    if ticker in self.invalid_symbols:
                        logger.error(f"[INVALID_SYMBOL] Received update for previously invalid symbol: {ticker}")
                        logger.error(f"[INVALID_SYMBOL] SKIP subscription for: {ticker}")
                        pass  # Skip processing for invalid symbols
                    
                    callback = self.depth_subscriptions[ticker]
                    callback(ticker, message)
                except Exception as e:
                    logger.error(f"[DEPTH_CALLBACK_ERROR] Error in depth callback for {ticker}: {e}", exc_info=True)
                    # Don't reconnect on callback error, just log it
            else:
                logger.debug(f"[DEPTH_UPDATE] Received update for unsubscribed ticker: {ticker}")
        except Exception as e:
            logger.error(f"[DEPTH_UPDATE_ERROR] Runtime error processing depth update: {e}", exc_info=True)
            # Trigger reconnection on processing errors
            self._restart_depth_ws()
    
    def _on_depth_error_message(self, message: str) -> None:
        """Callback for depth error messages."""
        try:
            logger.error(f"[DEPTH_ERROR_MSG] Depth error message: {message}")
            # Trigger reconnection on error messages
            self._restart_depth_ws()
        except Exception as e:
            logger.error(f"[DEPTH_ERROR_MSG_HANDLER] Error in error message handler: {e}", exc_info=True)
    
    # ========== Price WebSocket Methods ==========
    def subscribe_to_price(self, symbols: Union[str, List[str]], callback: Callable) -> Union[bool, str]:
        """Subscribe to real-time price updates for one or more symbols."""
        try:
            if not FYERS_AVAILABLE:
                return "fyers-apiv3 library not available"
            
            # Ensure symbols is a list
            if isinstance(symbols, str):
                symbols = [symbols]
            
            for symbol in symbols:
                self.price_subscriptions[symbol] = callback
            
            if not self.price_ws:
                error = self._start_price_ws()
                if error:
                    return error
            else:
                # Re-subscribe with updated symbols
                symbols_list = self.get_price_valid_symbols()
                self.price_ws.subscribe(symbols=symbols_list, data_type="SymbolUpdate")
            
            self._start_watchdog()
            return True
        except Exception as e:
            logger.error(f"Error subscribing to price: {e}")
            return f"Error subscribing to price: {e}"
    
    def unsubscribe_from_price(self, symbol: str) -> Union[bool, str]:
        """Unsubscribe from price updates."""
        try:
            self.price_subscriptions.pop(symbol, None)
            
            if self.price_ws and self.price_subscriptions:
                symbols_list = self.get_price_valid_symbols()
                self.price_ws.subscribe(symbols=symbols_list, data_type="SymbolUpdate")
            elif self.price_ws and not self.get_price_valid_symbols():
                self._stop_price_ws()
            
            return True
        except Exception as e:
            logger.error(f"Error unsubscribing from price: {e}")
            return f"Error unsubscribing from price: {e}"
    
    def _start_price_ws(self) -> Optional[str]:
        """Start price WebSocket connection."""
        try:
            if not self.price_ws:
                self.price_ws = data_ws.FyersDataSocket(
                    access_token=self.access_token,
                    log_path=self.log_path,
                    litemode=False,
                    write_to_file=False,
                    reconnect=False,  # Disable auto-reconnect to handle manually
                    on_message=self._on_price_message,
                    on_error=self._on_price_error,
                    on_close=self._on_price_close,
                    on_connect=self._on_price_connect
                )
            self.price_ws.connect()
            self.price_ws_thread = threading.Thread(target=self.price_ws.keep_running)
            self.price_ws_thread.daemon = True
            self.price_ws_thread.start()
            logger.info("[PRICE_START] Price WebSocket started successfully")
            return None
        except Exception as e:
            logger.error(f"[PRICE_START_ERROR] Error starting price WebSocket: {e}", exc_info=True)
            # Clean up on failure
            try:
                if self.price_ws:
                    self.price_ws = None
                if self.price_ws_thread:
                    self.price_ws_thread = None
            except:
                pass
            return f"Error starting price WebSocket: {e}"
    
    def _stop_price_ws(self) -> None:
        """Stop price WebSocket connection."""
        try:
            if self.price_ws:
                try:
                    if hasattr(self.price_ws, 'close'):
                        self.price_ws.close()
                except Exception as e:
                    logger.warning(f"[PRICE_CLOSE_ERROR] Error closing price WebSocket: {e}")
                finally:
                    self.price_ws = None
            
            if self.price_ws_thread:
                try:
                    self.price_ws_thread.join(timeout=1)
                except Exception as e:
                    logger.warning(f"[PRICE_THREAD_ERROR] Error joining price thread: {e}")
                finally:
                    self.price_ws_thread = None
            
            logger.info("[PRICE_STOP] Price WebSocket stopped")
        except Exception as e:
            logger.error(f"[PRICE_STOP_ERROR] Error stopping price WebSocket: {e}", exc_info=True)
    
    def _restart_price_ws(self) -> None:
        """Restart price WebSocket with persistent retry until 3:40 PM."""
        logger.info("Restarting price WebSocket...")
        with self.price_lock:
            if not self.is_market_open_time():
                logger.info("Market closed - Skipping price WebSocket reconnect")
                return
            
            if not self.get_price_valid_symbols():
                logger.info("No valid price subscriptions → Skipping reconnect")
                return
            
            # Check if already reconnecting
            if self.price_reconnecting:
                logger.info("Price WebSocket reconnection already in progress")
                return
            
            self.price_reconnecting = True
        
        # Release lock before starting long-running retry process
        try:
            def _attempt_reconnect() -> Optional[bool]:
                """Attempt to reconnect price WebSocket."""
                try:
                    if not self.refresh_access_token():
                        logger.warning("Token refresh failed, proceeding with current token")                    
                   
                    self._stop_price_ws()

                    logger.info(f"[PRICE_RECONNECT] Attempting reconnect (delay: {self.price_retry_delay}s)...")
                    time.sleep(self.price_retry_delay)
                    logger.info(f"[PRICE_RECONNECT] Attempting reconnect now...")

                    result = self._start_price_ws()
                    if result:
                        logger.warning(f"[PRICE_RECONNECT] Failed to start: {result}")
                        self.price_retry_delay = min(self.price_retry_delay * 2, self.max_retry_delay)
                        return None
                    else:
                        logger.info("[PRICE_RECONNECT] Price WebSocket reconnected successfully")
                        self.price_retry_delay = self.base_retry_delay  # Reset backoff on success
                        return True
                except Exception as e:
                    logger.error(f"[PRICE_RECONNECT] Reconnect attempt error: {e}")
                    self.depth_retry_delay = min(self.depth_retry_delay * 2, self.max_retry_delay)
                    return None
            
            # Try initial reconnect attempts (3 times with backoff)
            for attempt in range(3):
                result = _attempt_reconnect()
                if result:
                    return
                if attempt < 2:
                    wait_time = 2 ** attempt
                    logger.info(f"[PRICE_RECONNECT] Waiting {wait_time}s before next attempt...")
                    time.sleep(wait_time)
            
            # If initial attempts failed, enter persistent retry until 3:40 PM
            logger.warning("[PRICE_RECONNECT] Initial attempts exhausted. Entering persistent retry mode until 3:40 PM...")
            persistent_attempt = 0
            
            while self.should_continue_retrying():
                persistent_attempt += 1
                current_time = datetime.now().strftime("%H:%M:%S")
                logger.info(f"[PRICE_RECONNECT_PERSISTENT] Attempt {persistent_attempt} at {current_time}")
                
                result = _attempt_reconnect()
                if result:
                    logger.info(f"[PRICE_RECONNECT_PERSISTENT] SUCCESS on attempt {persistent_attempt}")
                    return
                
                # Check again before sleeping
                if self.should_continue_retrying():
                    logger.warning(f"[PRICE_RECONNECT_PERSISTENT] Attempt {persistent_attempt} failed, retrying in 1s...")
                    time.sleep(1)
                else:
                    break
            
            current_time = datetime.now().strftime("%H:%M:%S")
            logger.error(f"[PRICE_RECONNECT_PERSISTENT] FAILED at {current_time}. Cutoff (3:40 PM) reached. Total attempts: {3 + persistent_attempt}")
        finally:
            with self.price_lock:
                self.price_reconnecting = False
    
    # Price WebSocket Callbacks
    def _on_price_connect(self) -> None:
        """Callback for price WebSocket connect."""
        try:
            logger.info("Price WebSocket connected")
            self.price_last_message_time = time.time()
            
            if self.price_subscriptions:
                try:
                    symbols_list = self.get_price_valid_symbols()
                    self.price_ws.subscribe(symbols=symbols_list, data_type="SymbolUpdate")
                    logger.info(f"Re-subscribed price symbols: {symbols_list}")
                except Exception as e:
                    logger.error(f"[PRICE_RESUBSCRIBE_ERROR] Error re-subscribing price symbols: {e}", exc_info=True)
                    # Trigger reconnect on subscription failure
                    self._restart_price_ws()
        except Exception as e:
            logger.error(f"[PRICE_CONNECT_ERROR] Runtime error in price connect callback: {e}", exc_info=True)
            self._restart_price_ws()
    
    def _on_price_close(self, message: str) -> None:
        """Callback for price WebSocket close."""
        logger.info(f"Price WebSocket closed: {message}")
        self._restart_price_ws()
    
    def _on_price_error(self, message: str) -> None:
        """Callback for price WebSocket error."""
        try:
            logger.error(f"[PRICE_WS_ERROR] Price WebSocket error: {message}")
            invalid_symbols = message.get('invalid_symbols', [])
            if invalid_symbols:
                logger.error(f"[PRICE_INVALID_SYMBOLS] Invalid symbols in error: {invalid_symbols}")
                new_invalids = set(invalid_symbols) - self.invalid_symbols
                if new_invalids:
                    self.invalid_symbols.update(new_invalids)
                    logger.warning(f"[PRICE_INVALID_SYMBOLS] Added invalid symbols: {new_invalids}")

            # Log common error patterns
            if "getaddrinfo failed" in str(message):
                logger.warning("[PRICE_DNS_ERROR] DNS resolution failed")
            elif "Connection" in str(message) or "refused" in str(message):
                logger.warning("[PRICE_CONNECTION_ERROR] Connection issue detected")
            elif "timeout" in str(message).lower():
                logger.warning("[PRICE_TIMEOUT_ERROR] Timeout detected")
            self._restart_price_ws()
        except Exception as e:
            logger.error(f"[PRICE_ERROR_HANDLER_ERROR] Error in error handler: {e}", exc_info=True)
            self._restart_price_ws()
    
    def _on_price_message(self, message: Dict[str, Any]) -> None:
        """Callback for price WebSocket messages."""
        try:
            self.price_last_message_time = time.time()
            self.price_retry_delay = self.base_retry_delay  # Reset backoff on success
            logger.debug(f"Price message received: {message}")
            
            # Validate message structure
            if not isinstance(message, dict):
                logger.error(f"[PRICE_INVALID_MSG] Invalid message type: {type(message)}")
                return
            
            symbol = message.get('symbol')
            if not symbol:
                logger.debug(f"[PRICE_NO_SYMBOL] Message without symbol: {message}")
                return
            
            if symbol in self.price_subscriptions:
                try:
                    if symbol in self.invalid_symbols:
                        logger.error(f"[PRICE_INVALID_SYMBOL] Received update for previously invalid symbol: {symbol}")
                        logger.error(f"[PRICE_INVALID_SYMBOL] SKIP subscription for: {symbol}")
                        pass  # Skip processing for invalid symbols
                    
                    logger.info(f"[PRICE_UPDATE] Processed price update for {symbol} {message}")
                    callback = self.price_subscriptions[symbol]
                    callback(symbol, message)                    
                except Exception as e:
                    logger.error(f"[PRICE_CALLBACK_ERROR] Error in price callback for {symbol}: {e}", exc_info=True)
                    # Don't reconnect on callback error, just log it
            else:
                logger.debug(f"[PRICE_UPDATE] Received update for unsubscribed symbol: {symbol}")
        except Exception as e:
            logger.error(f"[PRICE_MESSAGE_ERROR] Runtime error processing price message: {e}", exc_info=True)
            # Trigger reconnection on processing errors
            self._restart_price_ws()
    
    # ========== Watchdog Methods ==========
    def _start_watchdog(self) -> None:
        """Start the WebSocket idle watchdog thread."""
        if not self.watchdog_running:
            self.watchdog_running = True
            self.watchdog_thread = threading.Thread(target=self._idle_watchdog, daemon=True)
            self.watchdog_thread.start()
            logger.info("WebSocket idle watchdog started")
    
    def _idle_watchdog(self) -> None:
        """Monitor WebSocket connections for idle timeout and message timeout (2 minutes), trigger reconnect."""
        while self.watchdog_running:
            try:
                current_time = time.time()
                effective_timeout = self.get_effective_timeout()
                is_market_open_time_status = self.is_market_open_time()
                
                # Check depth WebSocket
                if self.depth_ws and self.get_depth_valid_symbols():
                    idle_time = current_time - self.depth_last_message_time
                    
                    # Check for message timeout (2 minutes)
                    if idle_time > self.message_timeout and is_market_open_time_status:
                        logger.error(f"[DEPTH_TIMEOUT] No message received for {idle_time:.1f}s (timeout: {self.message_timeout}s) - Restarting connection")
                        self._restart_depth_ws()
                    # Check for idle timeout
                    elif idle_time > effective_timeout and is_market_open_time_status:
                        is_critical = self.is_critical_market_period()
                        period_info = "[CRITICAL PERIOD 9:13-9:17]" if is_critical else ""
                        logger.warning(f"{period_info} [DEPTH_IDLE] WebSocket idle for {idle_time:.1f}s (timeout: {effective_timeout}s) - Restarting")
                        self._restart_depth_ws()
                
                # Check price WebSocket
                if self.price_ws and self.get_price_valid_symbols():
                    idle_time = current_time - self.price_last_message_time
                    
                    # Check for message timeout (2 minutes)
                    if idle_time > self.message_timeout and is_market_open_time_status:
                        logger.error(f"[PRICE_TIMEOUT] No message received for {idle_time:.1f}s (timeout: {self.message_timeout}s) - Restarting connection")
                        self._restart_price_ws()
                    # Check for idle timeout
                    elif idle_time > effective_timeout and is_market_open_time_status:
                        is_critical = self.is_critical_market_period()
                        period_info = "[CRITICAL PERIOD 9:13-9:17]" if is_critical else ""
                        logger.warning(f"{period_info} [PRICE_IDLE] WebSocket idle for {idle_time:.1f}s (timeout: {effective_timeout}s) - Restarting")
                        self._restart_price_ws()
                
                sleep_time = self.check_interval if is_market_open_time_status else self.offline_market_idle_time
                time.sleep(sleep_time)
            except Exception as e:
                logger.error(f"Watchdog error: {e}")
                sleep_time = self.check_interval if is_market_open_time_status else self.offline_market_idle_time
                time.sleep(sleep_time)
    
    def stop_watchdog(self) -> None:
        """Stop the WebSocket idle watchdog thread."""
        self.watchdog_running = False
        if self.watchdog_thread:
            self.watchdog_thread.join(timeout=1)
            self.watchdog_thread = None
            logger.info("WebSocket idle watchdog stopped")
    
    def cleanup(self) -> None:
        """Cleanup all WebSocket connections and threads."""
        self.stop_watchdog()
        self._stop_depth_ws()
        self._stop_price_ws()
        logger.info("FyersWSManager cleanup complete")
