"""
Centralized Retry and Cutoff Time Management Module

This module manages all retry logic and cutoff time enforcement for the trading API.
All retry operations are logged to a dedicated retry_operations.log file for easy
tracking and monitoring of retry behavior.

Features:
- Centralized retry logic for all operations
- Separate logging to dedicated retry log file
- Cutoff time enforcement (3:40 PM IST / 15:40)
- Two-phase retry strategy (initial fast + persistent)
- Market hours awareness
- Comprehensive retry statistics
- Class-based approach for better organization
"""

import logging
import time
import xml.etree.ElementTree as ET
from datetime import datetime
from datetime import time as datetime_time
from typing import Callable, Optional, Any, Dict, List
from pathlib import Path



# ===========================
# Configuration Loader
# ===========================
def _parse_time(time_str: str, default: datetime_time = None) -> datetime_time:
    """Parse time string in HH:MM format."""
    try:
        if time_str:
            parts = time_str.strip().split(':')
            if len(parts) == 2:
                hour, minute = int(parts[0]), int(parts[1])
                return datetime_time(hour, minute)
    except (ValueError, IndexError):
        pass
    return default


def _parse_int(value_str: str, default: int = None) -> int:
    """Parse integer string safely."""
    try:
        if value_str:
            return int(value_str.strip())
    except (ValueError, TypeError):
        pass
    return default


def _parse_list_int(value_str: str, default: List[int] = None) -> List[int]:
    """Parse comma-separated integer list."""
    try:
        if value_str:
            return [int(x.strip()) for x in value_str.strip().split(',')]
    except (ValueError, TypeError):
        pass
    return default


def _load_retry_config() -> Dict[str, Any]:
    """
    Load retry configuration from config.xml file.
    
    Returns:
        Dictionary with retry configuration
    """
    config = {
        'cutoff_time': datetime_time(15, 40),
        'market_open_time': datetime_time(9, 15),
        'market_close_time': datetime_time(15, 30),
        'initial_retry_count': 3,
        'initial_retry_delays': [1, 2, 4],
        'persistent_retry_interval': 1,
        'enable_retry_logging': True,
        'logs_dir': 'logs'
    }
    
    # Try to load from config.xml
    config_paths = [
        Path('config.xml'),
        Path(__file__).parent.parent.parent / 'config.xml',
        Path.home() / 'trading_api' / 'config.xml'
    ]
    
    for config_path in config_paths:
        if config_path.exists():
            try:
                tree = ET.parse(config_path)
                root = tree.getroot()
                retry_elem = root.find('retry')
                
                if retry_elem is not None:
                    # Parse cutoff time
                    cutoff_str = retry_elem.findtext('cutoff_time')
                    if cutoff_str:
                        config['cutoff_time'] = _parse_time(
                            cutoff_str,
                            config['cutoff_time']
                        )
                    
                    # Parse market open time
                    open_str = retry_elem.findtext('market_open_time')
                    if open_str:
                        config['market_open_time'] = _parse_time(
                            open_str,
                            config['market_open_time']
                        )
                    
                    # Parse market close time
                    close_str = retry_elem.findtext('market_close_time')
                    if close_str:
                        config['market_close_time'] = _parse_time(
                            close_str,
                            config['market_close_time']
                        )
                    
                    # Parse initial retry count
                    count_str = retry_elem.findtext('initial_retry_count')
                    if count_str:
                        parsed = _parse_int(count_str)
                        if parsed:
                            config['initial_retry_count'] = parsed
                    
                    # Parse initial retry delays
                    delays_str = retry_elem.findtext('initial_retry_delays')
                    if delays_str:
                        parsed = _parse_list_int(delays_str)
                        if parsed:
                            config['initial_retry_delays'] = parsed
                    
                    # Parse persistent retry interval
                    interval_str = retry_elem.findtext('persistent_retry_interval')
                    if interval_str:
                        parsed = _parse_int(interval_str)
                        if parsed:
                            config['persistent_retry_interval'] = parsed
                    
                    # Parse enable retry logging
                    logging_str = retry_elem.findtext('enable_retry_logging')
                    if logging_str:
                        config['enable_retry_logging'] = logging_str.lower() in ['true', '1', 'yes']
                    
                    # Parse logs directory
                    logs_str = retry_elem.findtext('logs_dir')
                    if logs_str:
                        config['logs_dir'] = logs_str.strip()
                
                return config
            except Exception as e:
                # Log error but continue with defaults
                print(f"Warning: Failed to parse retry config from {config_path}: {e}")
                continue
    
    return config
class RetryOperation:
    """
    Tracks a single retry operation with centralized logging.
    
    This class tracks all aspects of a retry operation including:
    - Operation name and description
    - Attempt counts (initial and persistent)
    - Success/failure status
    - Total time elapsed
    - Errors encountered
    """
    
    def __init__(self, operation_name: str, operation_description: str = "", logger: logging.Logger = None):
        """
        Initialize a retry operation.
        
        Args:
            operation_name: Unique name for this operation (e.g., 'TOKEN_REFRESH')
            operation_description: Human-readable description
            logger: Logger instance for this operation
        """
        self.operation_name = operation_name
        self.operation_description = operation_description
        self.logger = logger
        self.start_time = datetime.now()
        self.initial_attempts = 0
        self.persistent_attempts = 0
        self.total_attempts = 0
        self.success = False
        self.error_messages: List[str] = []
        self.final_error: Optional[str] = None
    
    def log_initial_attempt(self, attempt_num: int, total: int):
        """Log an initial retry attempt."""
        self.initial_attempts = attempt_num
        if self.logger:
            self.logger.debug(
                f"[{self.operation_name}] Initial attempt {attempt_num}/{total} - "
                f"{self.operation_description}"
            )
    
    def log_initial_failure(self, attempt_num: int, error: str, retry_delay: int):
        """Log initial attempt failure."""
        self.error_messages.append(f"Initial attempt {attempt_num}: {error}")
        if self.logger:
            self.logger.warning(
                f"[{self.operation_name}] Initial attempt {attempt_num} failed: {error} "
                f"(retrying in {retry_delay}s)"
            )
    
    def log_initial_success(self, attempt_num: int):
        """Log initial attempt success."""
        elapsed = (datetime.now() - self.start_time).total_seconds()
        self.success = True
        self.total_attempts = attempt_num
        if self.logger:
            self.logger.info(
                f"[{self.operation_name}] SUCCESS on initial attempt {attempt_num} "
                f"(elapsed: {elapsed:.2f}s)"
            )
    
    def log_persistent_start(self, time_until_cutoff: float):
        """Log start of persistent retry phase."""
        if self.logger:
            self.logger.warning(
                f"[{self.operation_name}] Initial retries exhausted. "
                f"Entering persistent retry mode (until 3:40 PM). "
                f"Time remaining: {time_until_cutoff:.0f}s"
            )
    
    def log_persistent_attempt(self, attempt_num: int, time_until_cutoff: float):
        """Log a persistent retry attempt."""
        self.persistent_attempts = attempt_num
        current_time = datetime.now().strftime("%H:%M:%S")
        if self.logger:
            self.logger.debug(
                f"[{self.operation_name}] Persistent attempt {attempt_num} at {current_time} "
                f"(time to cutoff: {time_until_cutoff:.0f}s)"
            )
    
    def log_persistent_failure(self, attempt_num: int, error: str):
        """Log persistent attempt failure."""
        self.error_messages.append(f"Persistent attempt {attempt_num}: {error}")
        if self.logger:
            self.logger.debug(
                f"[{self.operation_name}] Persistent attempt {attempt_num} failed: {error}"
            )
    
    def log_persistent_success(self, attempt_num: int):
        """Log persistent attempt success."""
        elapsed = (datetime.now() - self.start_time).total_seconds()
        self.success = True
        self.total_attempts = self.initial_attempts + attempt_num
        if self.logger:
            self.logger.info(
                f"[{self.operation_name}] SUCCESS on persistent attempt {attempt_num} "
                f"(total attempts: {self.total_attempts}, elapsed: {elapsed:.2f}s)"
            )
    
    def log_failure_cutoff_reached(self):
        """Log failure due to cutoff time reached."""
        elapsed = (datetime.now() - self.start_time).total_seconds()
        current_time = datetime.now().strftime("%H:%M:%S")
        self.final_error = "Cutoff time (3:40 PM) reached"
        if self.logger:
            self.logger.error(
                f"[{self.operation_name}] FAILED - Cutoff time reached at {current_time}. "
                f"Total attempts: {self.total_attempts} (initial: {self.initial_attempts}, "
                f"persistent: {self.persistent_attempts}), elapsed: {elapsed:.2f}s"
            )
    
    def get_summary(self) -> Dict[str, Any]:
        """Get summary of this retry operation."""
        elapsed = (datetime.now() - self.start_time).total_seconds()
        return {
            "operation_name": self.operation_name,
            "description": self.operation_description,
            "success": self.success,
            "total_attempts": self.total_attempts,
            "initial_attempts": self.initial_attempts,
            "persistent_attempts": self.persistent_attempts,
            "elapsed_seconds": elapsed,
            "error_messages": self.error_messages,
            "final_error": self.final_error
        }


# ===========================
# RetryManager Class (Main)
# ===========================
class RetryManager:
    """
    Centralized retry and cutoff time management.
    
    This class manages all retry logic, cutoff times, and related operations
    for the trading API. Configuration is loaded from config.xml with fallback
    to defaults.
    
    Configuration (from config.xml <retry> section):
    - cutoff_time: When to stop retrying (default: 15:40)
    - market_open_time: Market opening time (default: 09:15)
    - market_close_time: Market closing time (default: 15:30)
    - initial_retry_count: Fast initial attempts (default: 3)
    - initial_retry_delays: Delays per attempt (default: 1,2,4)
    - persistent_retry_interval: Seconds between retries (default: 1)
    - enable_retry_logging: Enable retry logging (default: true)
    - logs_dir: Log directory (default: logs)
    
    Example:
        >>> manager = RetryManager()  # Loads config from config.xml
        >>> result = manager.retry(
        ...     operation_name="API_CALL",
        ...     operation_func=operation,
        ...     operation_description="Call API endpoint"
        ... )
    """
    
    # Load configuration from config.xml
    _config = _load_retry_config()
    
    # Class-level configuration (loaded from config.xml)
    CUTOFF_TIME = _config['cutoff_time']
    INITIAL_RETRY_COUNT = _config['initial_retry_count']
    INITIAL_RETRY_DELAYS = _config['initial_retry_delays']
    PERSISTENT_RETRY_INTERVAL = _config['persistent_retry_interval']
    MARKET_OPEN_TIME = _config['market_open_time']
    MARKET_CLOSE_TIME = _config['market_close_time']
    ENABLE_RETRY_LOGGING = _config['enable_retry_logging']
    LOGS_DIR = _config['logs_dir']
    
    # Class-level logger instance
    _logger: Optional[logging.Logger] = None
    _instance: Optional['RetryManager'] = None
    
    def __init__(self, 
                 cutoff_time: datetime_time = None,
                 initial_retry_count: int = None,
                 persistent_retry_interval: int = None,
                 logs_dir: str = None):
        """
        Initialize RetryManager with optional configuration.
        
        Configuration is loaded from config.xml, and can be overridden with
        constructor parameters.
        
        Args:
            cutoff_time: Custom cutoff time (default: from config.xml or 3:40 PM)
            initial_retry_count: Custom initial retry count (default: from config.xml or 3)
            persistent_retry_interval: Custom persistent retry interval (default: from config.xml or 1s)
            logs_dir: Directory for log files (default: from config.xml or "logs")
        """
        # Use provided values or fall back to config.xml values
        if cutoff_time:
            self.CUTOFF_TIME = cutoff_time
        if initial_retry_count:
            self.INITIAL_RETRY_COUNT = initial_retry_count
        if persistent_retry_interval:
            self.PERSISTENT_RETRY_INTERVAL = persistent_retry_interval
        
        # Set logs directory - convert to Path and ensure it's relative to cwd
        logs_dir_name = logs_dir or self.LOGS_DIR
        # Ensure logs_dir is absolute path relative to current working directory
        if not os.path.isabs(logs_dir_name):
            logs_dir_name = os.path.join(os.getcwd(), logs_dir_name)
        self.logs_dir = Path(logs_dir_name)
        
        # Create logs directory if it doesn't exist
        try:
            self.logs_dir.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            print(f"Warning: Could not create logs directory at {self.logs_dir}: {e}")
        
        # Setup logger if not already done
        if RetryManager._logger is None:
            RetryManager._logger = self._setup_retry_logger()
    
    def _setup_retry_logger(self) -> logging.Logger:
        """Setup dedicated logger for retry operations."""
        logger = logging.getLogger("RetryManager")
        
        # Only configure if not already configured
        if not logger.handlers:
            logger.setLevel(logging.DEBUG)
            
            # Check if retry logging is enabled
            if not self.ENABLE_RETRY_LOGGING:
                # Add null handler if logging disabled
                logger.addHandler(logging.NullHandler())
                return logger
            
            # Ensure logs directory exists (relative to current working directory)
            logs_path = Path(self.logs_dir)
            logs_path.mkdir(parents=True, exist_ok=True)
            
            # File handler for retry operations
            retry_log_path = logs_path / "retry_operations.log"
            
            try:
                file_handler = logging.FileHandler(str(retry_log_path), encoding='utf-8')
                file_handler.setLevel(logging.DEBUG)
                
                # Console handler
                console_handler = logging.StreamHandler()
                console_handler.setLevel(logging.DEBUG)
                
                # Formatter
                formatter = logging.Formatter(
                    '%(asctime)s - %(name)s - %(levelname)s - [%(funcName)s] %(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S'
                )
                
                file_handler.setFormatter(formatter)
                console_handler.setFormatter(formatter)
                
                logger.addHandler(file_handler)
                logger.addHandler(console_handler)
            except Exception as e:
                print(f"Warning: Failed to setup retry logger: {e}")
                logger.addHandler(logging.NullHandler())
        
        return logger
    
    @property
    def logger(self) -> logging.Logger:
        """Get the retry logger instance."""
        if RetryManager._logger is None:
            RetryManager._logger = self._setup_retry_logger()
        return RetryManager._logger
    
    # ===========================
    # Cutoff Time Management
    # ===========================
    
    def should_continue_retry(self) -> bool:
        """
        Check if current time is before the cutoff time (3:40 PM).
        
        Returns:
            bool: True if current time < 3:40 PM, False otherwise
        """
        current_time = datetime.now().time()
        should_retry = current_time < self.CUTOFF_TIME
        
        if not should_retry:
            self.logger.warning(
                f"[CUTOFF_CHECK] Cutoff time (3:40 PM / 15:40) reached. "
                f"Current time: {current_time.strftime('%H:%M:%S')}. Stopping retries."
            )
        
        return should_retry
    
    def get_time_until_cutoff(self) -> float:
        """
        Get seconds remaining until cutoff time.
        
        Returns:
            float: Seconds until 3:40 PM, negative if past cutoff
        """
        current_time = datetime.now()
        cutoff_datetime = current_time.replace(
            hour=self.CUTOFF_TIME.hour,
            minute=self.CUTOFF_TIME.minute,
            second=0,
            microsecond=0
        )
        
        # If we're past cutoff, next cutoff is tomorrow
        if current_time > cutoff_datetime:
            cutoff_datetime = cutoff_datetime.replace(day=cutoff_datetime.day + 1)
        
        time_delta = cutoff_datetime - current_time
        return time_delta.total_seconds()
    
    def is_market_hours(self) -> bool:
        """
        Check if current time is within market hours (9:15 AM - 3:30 PM IST).
        
        Returns:
            bool: True if within market hours, False otherwise
        """
        current_time = datetime.now().time()
        return self.MARKET_OPEN_TIME <= current_time <= self.MARKET_CLOSE_TIME
    
    # ===========================
    # Retry Operation Management
    # ===========================
    
    def retry(self,
              operation_name: str,
              operation_func: Callable[[], Optional[Any]],
              operation_description: str = "",
              initial_retry_count: int = None,
              persistent_retry_interval: int = None) -> Optional[Any]:
        """
        Execute operation with persistent retries until 3:40 PM cutoff time.
        
        This is the main retry method. All retry logic flows through this single function,
        ensuring consistent retry behavior across the application.
        
        Two-phase retry strategy:
        1. Initial Phase: Fast attempts with exponential backoff
        2. Persistent Phase: Retry every 1 second until 3:40 PM cutoff
        
        Args:
            operation_name: Unique identifier for operation (e.g., 'PRICE_SUBSCRIBE')
            operation_func: Callable that executes the operation
            operation_description: Human-readable description of operation
            initial_retry_count: Override initial retry count
            persistent_retry_interval: Override persistent retry interval
        
        Returns:
            Result from operation or None if all retries exhausted/cutoff reached
        
        Example:
            >>> def subscribe_prices():
            ...     return fyers_api.subscribe("NSE:SBIN-EQ", callback)
            >>> manager = RetryManager()
            >>> result = manager.retry(
            ...     "PRICE_SUBSCRIBE",
            ...     subscribe_prices,
            ...     "Subscribe to price updates"
            ... )
        """
        # Use provided values or fall back to instance/class defaults
        initial_count = initial_retry_count or self.INITIAL_RETRY_COUNT
        persistent_interval = persistent_retry_interval or self.PERSISTENT_RETRY_INTERVAL
        
        operation = RetryOperation(operation_name, operation_description, self.logger)
        
        self.logger.info(
            f"[{operation_name}] Starting retry operation: {operation_description}"
        )
        
        # Phase 1: Initial retries with exponential backoff
        for attempt in range(initial_count):
            operation.log_initial_attempt(attempt + 1, initial_count)
            
            try:
                result = operation_func()
                if result is not None:
                    operation.log_initial_success(attempt + 1)
                    return result
            except Exception as e:
                error_msg = str(e)
                operation.log_initial_failure(
                    attempt + 1,
                    error_msg,
                    self.INITIAL_RETRY_DELAYS[attempt] if attempt < len(self.INITIAL_RETRY_DELAYS) else 0
                )
            
            # Wait before next attempt (except after last initial attempt)
            if attempt < initial_count - 1:
                retry_delay = self.INITIAL_RETRY_DELAYS[attempt] if attempt < len(self.INITIAL_RETRY_DELAYS) else 1
                time.sleep(retry_delay)
        
        # Phase 2: Persistent retries until cutoff
        time_until_cutoff = self.get_time_until_cutoff()
        operation.log_persistent_start(time_until_cutoff)
        persistent_attempt = 0
        
        while self.should_continue_retry():
            persistent_attempt += 1
            time_until_cutoff = self.get_time_until_cutoff()
            operation.log_persistent_attempt(persistent_attempt, time_until_cutoff)
            
            try:
                result = operation_func()
                if result is not None:
                    operation.log_persistent_success(persistent_attempt)
                    return result
            except Exception as e:
                error_msg = str(e)
                operation.log_persistent_failure(persistent_attempt, error_msg)
            
            # Check cutoff before sleeping
            if self.should_continue_retry():
                time.sleep(persistent_interval)
            else:
                break
        
        # Cutoff reached without success
        operation.log_failure_cutoff_reached()
        
        # Log operation summary
        summary = operation.get_summary()
        self.logger.debug(f"[{operation_name}] Operation summary: {summary}")
        
        return None
    
    def get_retry_statistics(self, operation_name: str = None) -> Dict[str, Any]:
        """
        Get retry operation statistics from log file.
        
        Useful for monitoring and analysis of retry behavior.
        
        Args:
            operation_name: Filter by specific operation name, or None for all
        
        Returns:
            Dictionary with retry statistics
        """
        retry_log_path = self.logs_dir / "retry_operations.log"
        
        if not retry_log_path.exists():
            return {"status": "No retry log found", "path": str(retry_log_path)}
        
        try:
            with open(retry_log_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Basic statistics
            success_count = content.count("SUCCESS")
            failure_count = content.count("FAILED")
            
            return {
                "status": "success",
                "log_path": str(retry_log_path),
                "successful_operations": success_count,
                "failed_operations": failure_count,
                "total_operations": success_count + failure_count
            }
        except Exception as e:
            return {"status": "error", "error": str(e)}
    
    @classmethod
    def get_instance(cls) -> 'RetryManager':
        """
        Get or create singleton instance of RetryManager.
        
        Returns:
            RetryManager: Singleton instance
        """
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance
    
    @classmethod
    def reset_instance(cls):
        """Reset the singleton instance (useful for testing)."""
        cls._instance = None


# ===========================
# Module-Level Convenience Functions
# ===========================
# These functions provide backward compatibility with the old API

_default_manager: Optional[RetryManager] = None

def _get_manager() -> RetryManager:
    """Get or create the default RetryManager instance."""
    global _default_manager
    if _default_manager is None:
        _default_manager = RetryManager()
    return _default_manager

def should_continue_retry_until_cutoff() -> bool:
    """
    Module-level function for backward compatibility.
    Check if current time is before the cutoff time (3:40 PM).
    """
    return _get_manager().should_continue_retry()

def get_time_until_cutoff() -> float:
    """
    Module-level function for backward compatibility.
    Get seconds remaining until cutoff time.
    """
    return _get_manager().get_time_until_cutoff()

def is_market_hours() -> bool:
    """
    Module-level function for backward compatibility.
    Check if current time is within market hours (9:15 AM - 3:30 PM IST).
    """
    return _get_manager().is_market_hours()

def persistent_retry_until_cutoff(
    operation_name: str,
    operation_func: Callable[[], Optional[Any]],
    operation_description: str = "",
    initial_retry_count: int = None,
    persistent_retry_interval: int = None
) -> Optional[Any]:
    """
    Module-level function for backward compatibility.
    Execute operation with persistent retries until 3:40 PM cutoff time.
    """
    manager = _get_manager()
    return manager.retry(
        operation_name=operation_name,
        operation_func=operation_func,
        operation_description=operation_description,
        initial_retry_count=initial_retry_count,
        persistent_retry_interval=persistent_retry_interval
    )

def get_retry_statistics(operation_name: str = None) -> Dict[str, Any]:
    """
    Module-level function for backward compatibility.
    Get retry operation statistics from log file.
    """
    return _get_manager().get_retry_statistics(operation_name)



# ===========================
# Example Usage
# ===========================
if __name__ == "__main__":
    print("=" * 70)
    print("Retry Manager - Class-Based Implementation")
    print("=" * 70)
    
    # Example 1: Using the class directly
    print("\n1. Using RetryManager class directly:")
    manager = RetryManager()
    print(f"   Current time: {datetime.now().strftime('%H:%M:%S')}")
    print(f"   Cutoff time: {manager.CUTOFF_TIME}")
    print(f"   Should retry: {manager.should_continue_retry()}")
    print(f"   Time until cutoff: {manager.get_time_until_cutoff():.0f}s")
    print(f"   In market hours: {manager.is_market_hours()}")
    
    # Example 2: Using module-level functions (backward compatible)
    print("\n2. Using module-level functions (backward compatible):")
    print(f"   Should retry: {should_continue_retry_until_cutoff()}")
    print(f"   Time until cutoff: {get_time_until_cutoff():.0f}s")
    print(f"   In market hours: {is_market_hours()}")
    
    # Example 3: Using the retry method
    print("\n3. Testing retry method:")
    
    def test_operation():
        """Test operation that fails once then succeeds."""
        if not hasattr(test_operation, 'call_count'):
            test_operation.call_count = 0
        test_operation.call_count += 1
        
        if test_operation.call_count < 2:
            print(f"      Attempt {test_operation.call_count}: Failed")
            return None
        print(f"      Attempt {test_operation.call_count}: Success!")
        return "Operation succeeded!"
    
    result = manager.retry(
        "TEST_OPERATION",
        test_operation,
        "Test operation for retry manager"
    )
    print(f"   Result: {result}")
    
    # Example 4: Using singleton instance
    print("\n4. Using singleton instance:")
    singleton_manager = RetryManager.get_instance()
    print(f"   Same instance: {singleton_manager is manager}")
    
    # Example 5: Retry statistics
    print("\n5. Retry statistics:")
    stats = manager.get_retry_statistics()
    print(f"   {stats}")
    
    print("\n" + "=" * 70)
    print("Check logs/retry_operations.log for detailed retry logs")
    print("=" * 70)
