"""
Unified OAuth callback handler for trading APIs.
Provides a common interface for handling OAuth redirects from different brokers.
"""

import threading
from http.server import HTTPServer, BaseHTTPRequestHandler
from typing import Dict, Optional, Tuple, Callable


class BaseOAuthCallbackHandler(BaseHTTPRequestHandler):
    """Base HTTP request handler for OAuth callbacks."""
    
    callback_data: Dict[str, str] = {}
    
    def do_GET(self):
        """Handle GET request from OAuth callback."""
        try:
            extracted_data = self.extract_callback_data()
            
            if extracted_data:
                self.send_success_response()
                self.store_callback_data(extracted_data)
            else:
                self.send_error_response()
        except Exception as e:
            print(f"Callback handler error: {e}")
            self.send_error_response()
    
    def extract_callback_data(self) -> Optional[Dict[str, str]]:
        """
        Extract relevant data from callback URL.
        Override this method in subclasses for broker-specific logic.
        
        Returns:
            Dict with extracted data or None if extraction fails
        """
        data = {}
        
        if 'code=' in self.path:
            data['code'] = self.path.split('code=')[1].split('&')[0]
        
        if 'access_token=' in self.path:
            data['access_token'] = self.path.split('access_token=')[1].split('&')[0]
        
        if 'tokenId=' in self.path:
            data['tokenId'] = self.path.split('tokenId=')[1].split('&')[0]
        
        return data if data else None
    
    def store_callback_data(self, data: Dict[str, str]) -> None:
        """Store extracted callback data."""
        self.callback_data.update(data)
        for key, value in data.items():
            print(f"[OK] {key} received: {value[:20]}...")
    
    def send_success_response(self) -> None:
        """Send success HTML response."""
        self.send_response(200)
        self.send_header('Content-type', 'text/html; charset=utf-8')
        self.end_headers()
        html = '''
            <html>
                <head><title>Authorization Successful</title></head>
                <body style="font-family: Arial; text-align: center; padding: 50px;">
                    <h1>Authorization Successful</h1>
                    <p>You can now close this window and return to your application.</p>
                </body>
            </html>
        '''
        self.wfile.write(html.encode('utf-8'))
    
    def send_error_response(self) -> None:
        """Send error HTML response."""
        self.send_response(400)
        self.send_header('Content-type', 'text/html; charset=utf-8')
        self.end_headers()
        html = '''
            <html>
                <head><title>Authorization Failed</title></head>
                <body style="font-family: Arial; text-align: center; padding: 50px;">
                    <h1>Authorization Failed</h1>
                    <p>An error occurred during authorization. Please try again.</p>
                </body>
            </html>
        '''
        self.wfile.write(html.encode('utf-8'))
    
    def log_message(self, format, *args):
        """Suppress default HTTP log messages."""
        pass


class OAuthCallbackServer:
    """Unified OAuth callback server for listening to OAuth redirects."""
    
    def __init__(self, handler_class=BaseOAuthCallbackHandler, 
                 host: str = 'localhost', port: int = 8000, timeout: int = 120):
        """
        Initialize OAuth callback server.
        
        Args:
            handler_class: HTTP request handler class
            host: Server host (default: localhost)
            port: Server port (default: 8000)
            timeout: Wait timeout in seconds (default: 120)
        """
        self.handler_class = handler_class
        self.host = host
        self.port = port
        self.timeout = timeout
        self.server: Optional[HTTPServer] = None
    
    def listen_for_callback(self) -> Optional[Dict[str, str]]:
        """
        Start server and listen for OAuth callback.
        
        Returns:
            Dict with callback data or None if timeout/error
        """
        try:
            self.handler_class.callback_data = {}
            self.server = HTTPServer((self.host, self.port), self.handler_class)
            
            print(f"Listening for callback on http://{self.host}:{self.port}/...")
            
            server_thread = threading.Thread(
                target=self.server.handle_request,
                daemon=True
            )
            server_thread.start()
            server_thread.join(timeout=self.timeout)
            
            return self.handler_class.callback_data if self.handler_class.callback_data else None
        except Exception as e:
            print(f"Callback server error: {e}")
            return None
        finally:
            if self.server:
                self.server.server_close()
    
    def get_callback_url(self) -> str:
        """Get the full callback URL."""
        return f"http://{self.host}:{self.port}/callback"


class FyersOAuthCallbackHandler(BaseOAuthCallbackHandler):
    """Fyers-specific OAuth callback handler."""
    
    def extract_callback_data(self) -> Optional[Dict[str, str]]:
        """Extract Fyers-specific callback data (auth_code or access_token)."""
        data = {}
        
        if 'auth_code=' in self.path:
            data['auth_code'] = self.path.split('auth_code=')[1].split('&')[0]
        elif 'code=' in self.path:
            data['code'] = self.path.split('code=')[1].split('&')[0]
        elif 'access_token=' in self.path:
            data['access_token'] = self.path.split('access_token=')[1].split('&')[0]
        
        return data if data else None


class DhanOAuthCallbackHandler(BaseOAuthCallbackHandler):
    """Dhan-specific OAuth callback handler."""
    
    def extract_callback_data(self) -> Optional[Dict[str, str]]:
        """Extract Dhan-specific callback data (tokenId)."""
        data = {}
        
        if 'tokenId=' in self.path:
            data['tokenId'] = self.path.split('tokenId=')[1].split('&')[0]
        
        return data if data else None
