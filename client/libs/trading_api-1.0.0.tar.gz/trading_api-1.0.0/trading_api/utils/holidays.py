import requests
import pandas as pd

url = 'https://api.upstox.com/v2/market/holidays'
url_nse = 'https://www.nseindia.com/api/holiday-master?type=trading'
headers = {'Accept': 'application/json'}
headers_nse = {"User-Agent": "Mozilla/5.0"}


def get_holidays():
    response = requests.get(url_nse, headers=headers_nse)
    if response.status_code == 200:
        data = response.json()
        df = pd.DataFrame(data['CM'])
        # Convert to '%Y-%m-%d' format
        formatted_dates = []
        for date_str in df['tradingDate']:
            dt = pd.to_datetime(date_str, format='%d-%b-%Y')
            formatted_dates.append(dt.strftime('%Y-%m-%d'))
        return formatted_dates
    else:
        print("Failed to retrieve data. Status code:", response.status_code)
        return {"2025-01-26", "2025-08-15", "2025-10-02"}

if __name__ == "__main__":
    holidays = get_holidays()
    if holidays is not None:
        print(holidays)