"""
Order management interface for trading APIs.
Defines contract for order placement, modification, and cancellation.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, List


class IOrderManagement(ABC):
    """Abstract base class for order management implementations."""

    @abstractmethod
    def place_order(self, order_details: Dict[str, Any]) -> Dict[str, Any]:
        """
        Place a new order.

        Args:
            order_details: Dictionary containing order details (symbol, quantity, price, order_type, etc.)

        Returns:
            Dict: Order response containing order ID and status
        """
        pass

    @abstractmethod
    def modify_order(self, order_id: str, modification_details: Dict[str, Any]) -> Dict[str, Any]:
        """
        Modify an existing order.

        Args:
            order_id: ID of the order to modify
            modification_details: Dictionary containing fields to modify

        Returns:
            Dict: Modified order details
        """
        pass

    @abstractmethod
    def cancel_order(self, order_id: str) -> bool:
        """
        Cancel an existing order.

        Args:
            order_id: ID of the order to cancel

        Returns:
            bool: True if cancellation is successful, False otherwise
        """
        pass

    @abstractmethod
    def get_order_status(self, order_id: str) -> Dict[str, Any]:
        """
        Get the status of an order.

        Args:
            order_id: ID of the order

        Returns:
            Dict: Order status and details
        """
        pass

    @abstractmethod
    def get_all_orders(self) -> List[Dict[str, Any]]:
        """
        Get all orders for the current session.

        Returns:
            List: List of order dictionaries
        """
        pass
