"""
Fund management interface for trading APIs.
Defines contract for managing account balance and funds.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any


class IFundManagement(ABC):
    """Abstract base class for fund management implementations."""

    @abstractmethod
    def get_balance(self) -> Dict[str, Any]:
        """
        Get account balance and fund details.

        Returns:
            Dict: Balance information (available_balance, used_margin, free_margin, etc.)
        """
        pass

    @abstractmethod
    def get_holdings(self) -> Dict[str, Any]:
        """
        Get current holdings/positions.

        Returns:
            Dict: Holdings information for all instruments
        """
        pass

    @abstractmethod
    def get_positions(self) -> Dict[str, Any]:
        """
        Get current open positions.

        Returns:
            Dict: Position information for all open trades
        """
        pass

    @abstractmethod
    def get_margin_requirement(self, symbol: str, quantity: int) -> Dict[str, Any]:
        """
        Get margin requirement for a specific order.

        Args:
            symbol: Trading symbol
            quantity: Number of units

        Returns:
            Dict: Margin requirement details
        """
        pass
