"""
Authentication interface for trading APIs.
Defines contract for implementing authentication mechanisms.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, List, Union


class IAuthentication(ABC):
    """Abstract base class for authentication implementations."""

    @abstractmethod
    def authenticate(self, credentials: Dict[str, Any]) -> List[Union[str, Any]]:
        """
        Authenticate with the trading API.

        Args:
            credentials: Dictionary containing authentication credentials

        Returns:
            List: ["success", apiclient] if successful, ["error", errormessage] if failed
        """
        pass

    @abstractmethod
    def get_token(self) -> str:
        """
        Get the current authentication token.

        Returns:
            str: Authentication token
        """
        pass

    @abstractmethod
    def refresh_token(self) -> bool:
        """
        Refresh the authentication token.

        Returns:
            bool: True if token refresh is successful, False otherwise
        """
        pass

    @abstractmethod
    def is_authenticated(self) -> bool:
        """
        Check if the current session is authenticated.

        Returns:
            bool: True if authenticated, False otherwise
        """
        pass
