"""
Interfaces module for trading API.
Contains abstract interfaces for authentication, order management, fund management, and price watching.
"""

from .authentication import IAuthentication
from .order_management import IOrderManagement
from .fund_management import IFundManagement
from .price_watcher import IPriceWatcher

__all__ = [
    'IAuthentication',
    'IOrderManagement',
    'IFundManagement',
    'IPriceWatcher',
]
