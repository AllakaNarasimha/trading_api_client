"""
Price watcher interface for trading APIs.
Defines contract for monitoring and retrieving price data.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, List, Callable, Union


class IPriceWatcher(ABC):
    """Abstract base class for price watching implementations."""

    @abstractmethod
    def get_price(self, symbol: str) -> Dict[str, Any]:
        """
        Get current price for a symbol.

        Args:
            symbol: Trading symbol

        Returns:
            Dict: Price information (ltp, bid, ask, volume, etc.)
        """
        pass

    @abstractmethod
    def get_quotes(self, symbols: List[str]) -> Dict[str, Dict[str, Any]]:
        """
        Get quotes for multiple symbols.

        Args:
            symbols: List of trading symbols

        Returns:
            Dict: Quote information for each symbol
        """
        pass

    @abstractmethod
    def subscribe_to_price(self, symbol: Union[str, List[str]], callback: Callable) -> Union[bool, str]:
        """
        Subscribe to real-time LTP price updates for a symbol.

        Args:
            symbol: Trading symbol
            callback: Function to call when LTP price updates (callback(symbol, message))

        Returns:
            Union[bool, str]: True if subscription is successful, error string otherwise
        """
        pass

    @abstractmethod
    def unsubscribe_from_price(self, symbol: str) -> Union[bool, str]:
        """
        Unsubscribe from LTP price updates for a symbol.

        Args:
            symbol: Trading symbol

        Returns:
            Union[bool, str]: True if unsubscription is successful, error string otherwise
        """
        pass

    @abstractmethod
    def subscribe_to_depth(self, symbol: str, callback: Callable) -> Union[bool, str]:
        """
        Subscribe to real-time depth (order book) updates for a symbol.

        Args:
            symbol: Trading symbol
            callback: Function to call when depth updates (callback(symbol, depth_object))

        Returns:
            Union[bool, str]: True if subscription is successful, error string otherwise
        """
        pass

    @abstractmethod
    def unsubscribe_from_depth(self, symbol: str) -> Union[bool, str]:
        """
        Unsubscribe from depth updates for a symbol.

        Args:
            symbol: Trading symbol

        Returns:
            Union[bool, str]: True if unsubscription is successful, error string otherwise
        """
        pass

    @abstractmethod
    def get_historical_data(self, symbol: str, resolution: str, date_format: str, period_start: int, period_end: int, cont_flag: str = "1") -> Union[List[List[Any]], str]:
        """
        Get historical price data for a symbol.

        Args:
            symbol: Trading symbol
            resolution: Time resolution (1, 5, 15 for minutes; 1H, 1D for hours/days)
            date_format: Date format (0 for epoch timestamp, 1 for YYYY-MM-DD)
            period_start: Start period as Unix timestamp
            period_end: End period as Unix timestamp
            cont_flag: Continuation flag (1 for continue, 0 for stop)

        Returns:
            Union[List, str]: List of OHLCV data as [timestamp, open, high, low, close, volume] or error message string
        """
        pass

    @abstractmethod
    def get_option_chain(self, symbol: str, strikecount: int = 1, timestamp: str = "") -> Dict[str, Any]:
        """
        Get option chain data for a symbol.

        Args:
            symbol: Trading symbol (e.g., "NSE:TCS-EQ")
            strikecount: Number of strikes to fetch on either side of ATM (default: 1)
            timestamp: Specific timestamp for option chain data (optional, defaults to current)

        Returns:
            Dict: Option chain data containing:
                - code: Response status code
                - data: Dictionary with:
                    - callOi: Total call open interest
                    - putOi: Total put open interest
                    - expiryData: List of expiry dates
                    - indiavixData: India VIX data
                    - optionsChain: List of option contracts with CE/PE data
                - message: Response message
                - s: Status ("ok" or "error")
        """
        pass

    @abstractmethod
    def get_market_status(self) -> Dict[str, Any]:
        """
        Get NSE market status (no authentication required).

        Returns:
            Dict: Market status containing:
                - equity: Status for equity market
                - derivatives: Status for derivatives market
                - timestamp: Current timestamp
                - timezone: IST (UTC+5:30)
        """
        pass

    @abstractmethod
    def get_trading_holidays(self, market_type: str = "CM") -> List[str]:
        """
        Get NSE trading holidays (no authentication required).

        Args:
            market_type: "CM" for Equity, "FO" for Derivatives, "ALL" for both

        Returns:
            List: Trading holiday dates in YYYY-MM-DD format
        """
        pass

    @abstractmethod
    def get_trading_hours(self, market_type: str = "equity") -> Dict[str, Dict[str, str]]:
        """
        Get NSE trading hours (no authentication required).

        Args:
            market_type: "equity" or "derivatives"

        Returns:
            Dict: Trading sessions with their timings
        """
        pass

    @abstractmethod
    def is_market_open(self, market_type: str = "equity") -> Dict[str, Any]:
        """
        Check if NSE market is currently open (no authentication required).

        Args:
            market_type: "equity" or "derivatives"

        Returns:
            Dict: Market status with is_open flag, session, and message
        """
        pass
