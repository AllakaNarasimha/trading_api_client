"""
Implementations module for trading API.
Contains concrete implementations for various trading platforms.
"""

from .authentication import AuthenticationImpl
from .dhan_api import DhanAPI

# Optional import for FyersAPI - only available if fyers-apiv3 is installed
try:
    from .fyers_api import FyersAPI
    __all__ = ['AuthenticationImpl', 'DhanAPI', 'FyersAPI']
except ImportError:
    # fyers-apiv3 not installed, FyersAPI will not be available
    __all__ = ['AuthenticationImpl', 'DhanAPI']
from .fyers_api import FyersAPI

__all__ = [
    'AuthenticationImpl',
    'DhanAPI',
    'FyersAPI',
]
