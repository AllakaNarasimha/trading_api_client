"""
Allow trading_api package to be run as: python -m trading_api
"""

from trading_api.main import main

if __name__ == '__main__':
    main()
