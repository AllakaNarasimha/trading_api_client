"""
Trading API - A unified interface for multiple trading platforms.

This package provides a unified API for interacting with multiple trading platforms
such as Dhan and Fyers through a consistent interface.

Example:
    from trading_api.implementations import DhanAPI
    from trading_api.utils import Config

    api = DhanAPI()
    api.authenticate(Config.get_dhan_config())
    order = api.place_order({'symbol': 'INFY', 'quantity': 1})
"""

__version__ = '1.0.0'
__author__ = 'Your Name'

from . import ssl_config

from .interfaces import (
    IAuthentication,
    IOrderManagement,
    IFundManagement,
    IPriceWatcher,
)
from .implementations import (
    AuthenticationImpl,
    DhanAPI,
    FyersAPI,
)
from .utils import Config

__all__ = [
    'IAuthentication',
    'IOrderManagement',
    'IFundManagement',
    'IPriceWatcher',
    'AuthenticationImpl',
    'DhanAPI',
    'FyersAPI',
    'Config',
]
